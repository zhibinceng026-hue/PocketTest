# 第三方说明

本项目自身采用 MIT。各依赖保持原许可；安装时应保留其 node_modules 内的 LICENSE/NOTICE。

接入目录 `bridge/agents/catalog.json` 与手机内同名数据是从 [Agent Client Protocol Registry](https://github.com/agentclientprotocol/registry) 的项目元数据整理的摘要，记录来源地址、项目名称、许可字段与启动参数（2026-10-31）。原仓库使用 Apache-2.0；本项目未修改或分发这些智能体的实现。目录许可字段来自其登记资料，不替代对应项目当前许可证。

React、React Native、Expo、Lucide、react-native-svg 和 qrcode 等依赖在各自许可下使用。RustDesk 仅以 URL scheme 调用已安装的客户端，未捆绑或修改其二进制。Codex、Claude、Copilot、Cursor 等名称归各自权利人所有，接入信息不表示获得其背书。

App 免费开源不代表第三方模型调用、智能体订阅或 Apple 开发者服务均免费。没有在本工程中嵌入第三方 API key、账户或签名凭据。

可选服务器安装脚本从 Caddy 官方发布页下载并校验 Caddy 2.11.7，许可为 Apache-2.0；许可及依赖说明见其官方发布包和源码仓库。Windows 端调用系统 OpenSSH 客户端，不捆绑 OpenSSH 二进制。SSH、Caddy 与操作系统软件包按各自许可证使用。
