import React, {useEffect, useMemo, useRef} from 'react';
import {Animated, Keyboard, PanResponder, Platform, StyleSheet, type ViewStyle} from 'react-native';

export function SwipeBack({enabled, onBack, children}: {enabled: boolean; onBack: () => void; children: React.ReactNode}) {
  const position = useRef(new Animated.Value(0)).current;
  const startX = useRef(0);
  const latest = useRef({enabled, onBack});
  latest.current = {enabled, onBack};
  const reset = () => Animated.spring(position, {toValue: 0, useNativeDriver: true, bounciness: 0}).start();
  const pan = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => false,
    onStartShouldSetPanResponderCapture: event => {startX.current=event.nativeEvent.pageX;return false;},
    // Start near the left edge so text selection and horizontally scrolling code keep working.
    onMoveShouldSetPanResponderCapture: (_, g) => latest.current.enabled && g.numberActiveTouches === 1 && startX.current <= 44 && g.dx > 16 && g.dx > Math.abs(g.dy) * 1.7,
    onPanResponderMove: (_, g) => position.setValue(Math.min(160, Math.max(0, g.dx))),
    onPanResponderRelease: (_, g) => {
      if (latest.current.enabled && g.dx >= 80 && g.dx > Math.abs(g.dy) * 1.7) {
        Keyboard.dismiss();
        latest.current.onBack();
      }
      reset();
    },
    onPanResponderTerminate: reset,
    onPanResponderTerminationRequest: () => false,
  }), [position]);
  useEffect(() => {if (!enabled) position.setValue(0);}, [enabled, position]);
  const webTouchStyle=Platform.OS==='web'?({touchAction:'pan-y'} as unknown as ViewStyle):undefined;
  return <Animated.View style={[styles.container,webTouchStyle,{transform: [{translateX: position}]}]} {...pan.panHandlers}>{children}</Animated.View>;
}
const styles = StyleSheet.create({container: {flex: 1, minHeight: 0}});
