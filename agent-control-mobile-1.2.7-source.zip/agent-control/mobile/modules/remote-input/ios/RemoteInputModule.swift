import ExpoModulesCore
import GameController
import UIKit

public class RemoteInputModule: Module {
  private var enabled = false
  private var observers: [NSObjectProtocol] = []
  private var keyboard: GCKeyboardInput?
  private var mice: [GCMouseInput] = []

  public func definition() -> ModuleDefinition {
    Name("AgentRemoteInput")
    Events("onInput")
    AsyncFunction("setEnabled") { (value: Bool) in
      self.disable()
      if value {
        self.enabled = true
        self.attach()
        let center = NotificationCenter.default
        for name in [Notification.Name.GCKeyboardDidConnect, .GCKeyboardDidDisconnect, .GCMouseDidConnect, .GCMouseDidDisconnect] {
          self.observers.append(center.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
            self?.emit(["type": "releaseAll"])
            self?.detach()
            self?.attach()
          })
        }
        self.observers.append(center.addObserver(forName: UIApplication.willResignActiveNotification, object: nil, queue: .main) { [weak self] _ in self?.disable() })
      }
    }.runOnQueue(.main)
    OnDestroy {
      DispatchQueue.main.async { self.disable() }
    }
  }

  private func emit(_ data: [String: Any]) {
    DispatchQueue.main.async { [weak self] in
      guard let self = self, self.enabled else { return }
      self.sendEvent("onInput", data)
    }
  }
  private func attach() {
    guard enabled else { return }
    keyboard = GCKeyboard.coalesced?.keyboardInput
    keyboard?.keyChangedHandler = { [weak self] _, _, code, pressed in
      self?.emit(["type": pressed ? "keyDown" : "keyUp", "keyCode": code.rawValue])
    }
    for mouse in GCMouse.mice() {
      guard let input = mouse.mouseInput else { continue }
      mice.append(input)
      input.mouseMovedHandler = { [weak self] _, x, y in self?.emit(["type": "mouseMove", "dx": x, "dy": -y]) }
      input.leftButton.pressedChangedHandler = { [weak self] _, _, down in self?.emit(["type": "mouseButton", "button": "left", "down": down]) }
      input.rightButton?.pressedChangedHandler = { [weak self] _, _, down in self?.emit(["type": "mouseButton", "button": "right", "down": down]) }
      input.middleButton?.pressedChangedHandler = { [weak self] _, _, down in self?.emit(["type": "mouseButton", "button": "middle", "down": down]) }
      input.scroll.valueChangedHandler = { [weak self] _, _, y in
        if y != 0 { self?.emit(["type": "scroll", "delta": Int(max(-1200, min(1200, y * 120)))]) }
      }
    }
  }
  private func detach() {
    keyboard?.keyChangedHandler = nil
    keyboard = nil
    for input in mice {
      input.mouseMovedHandler = nil
      input.leftButton.pressedChangedHandler = nil
      input.rightButton?.pressedChangedHandler = nil
      input.middleButton?.pressedChangedHandler = nil
      input.scroll.valueChangedHandler = nil
    }
    mice.removeAll()
  }
  private func disable() {
    if enabled { sendEvent("onInput", ["type": "releaseAll"]) }
    enabled = false
    detach()
    for observer in observers { NotificationCenter.default.removeObserver(observer) }
    observers.removeAll()
  }
}
