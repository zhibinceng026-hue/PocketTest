import {Platform} from 'react-native';
import {requireOptionalNativeModule} from 'expo';
export type HardwareInput={type:'keyDown'|'keyUp';keyCode:number}|{type:'mouseMove';dx:number;dy:number}|{type:'mouseButton';button:'left'|'right'|'middle';down:boolean}|{type:'scroll';delta:number}|{type:'releaseAll'};
type HardwareModule={setEnabled:(enabled:boolean)=>Promise<void>;addListener:(name:string,listener:(input:HardwareInput)=>void)=>{remove:()=>void}};
const native=Platform.OS==='ios'?requireOptionalNativeModule<HardwareModule>('AgentRemoteInput'):null;
export const hardwareInputAvailable=!!native;
export function captureHardwareInput(listener:(input:HardwareInput)=>void){
 if(!native)return()=>{};
 const sub=native.addListener('onInput',listener);void native.setEnabled(true).catch(()=>listener({type:'releaseAll'}));
 return()=>{void native.setEnabled(false).catch(()=>{});sub.remove();listener({type:'releaseAll'});};
}
