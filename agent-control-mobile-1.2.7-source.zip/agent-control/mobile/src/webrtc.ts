// Browser preview and web builds use the browser's native WebRTC engine.
export const RTCPeerConnection=(globalThis as any).RTCPeerConnection;
