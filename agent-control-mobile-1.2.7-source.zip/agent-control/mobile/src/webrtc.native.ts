export const {RTCPeerConnection}=require('react-native-webrtc');
