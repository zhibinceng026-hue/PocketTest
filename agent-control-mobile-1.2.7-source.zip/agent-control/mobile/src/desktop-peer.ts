import {request} from './api';
import {RTCPeerConnection} from './webrtc';
import type {Profile} from './types';
type Stats={fps:number;latency:number;bytes:number;route:string};
export async function connectDesktopPeer(profile:Profile,sessionId:string,quality:string,signal:AbortSignal,onStream:(stream:any)=>void,onReady:(value:boolean)=>void,onStats:(stats:Stats)=>void){
 const config=await request<{available:boolean;iceServers:any[]}>(profile,`/api/desktop/rtc/config?session=${encodeURIComponent(sessionId)}`,{signal,timeoutMs:3000});
 if(!config.available||!RTCPeerConnection)return null;
 const pc=new RTCPeerConnection({iceServers:config.iceServers}),pending=new Map<number,{resolve:()=>void;reject:(e:Error)=>void;timer:ReturnType<typeof setTimeout>}>();let sequence=0,closed=false,statsTimer:ReturnType<typeof setInterval>|undefined,reading=false,lastFrames=0,lastAt=Date.now();
 const channel=pc.createDataChannel('agent-control',{ordered:true});
 function close(sendClose=true){if(closed)return;closed=true;clearInterval(statsTimer);channel.close();pc.close();onReady(false);for(const job of pending.values()){clearTimeout(job.timer);job.reject(new Error('视频控制通道已断开。'));}pending.clear();if(sendClose)void request(profile,'/api/desktop/rtc/close',{method:'POST',body:{sessionId},timeoutMs:2000}).catch(()=>{});}
 signal.addEventListener('abort',()=>close(),{once:true});
 function send(type:string,input?:unknown):Promise<void>{if(closed||channel.readyState!=='open')return Promise.reject(new Error('视频控制通道尚未就绪。'));const id=++sequence;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(new Error('控制操作确认超时，请检查画面，避免重复操作。'));},2500);pending.set(id,{resolve,reject,timer});try{channel.send(JSON.stringify({id,type,input}));}catch(e){clearTimeout(timer);pending.delete(id);reject(e);}});}
 channel.onmessage=(event:any)=>{try{const msg=JSON.parse(event.data),job=pending.get(msg.id);if(!job)return;clearTimeout(job.timer);pending.delete(msg.id);msg.ok?job.resolve():job.reject(new Error(msg.error||'电脑未接受操作。'));}catch{}};
 pc.ontrack=(event:any)=>{if(!closed&&event.streams?.[0])onStream(event.streams[0]);};
 pc.onconnectionstatechange=()=>{if(['failed','closed','disconnected'].includes(pc.connectionState))close();};
 try{
  pc.addTransceiver('video',{direction:'recvonly'});await pc.setLocalDescription(await pc.createOffer());
  if(pc.iceGatheringState!=='complete')await new Promise<void>(resolve=>{const timer=setTimeout(resolve,6000);const listener=()=>{if(pc.iceGatheringState==='complete'){clearTimeout(timer);pc.removeEventListener('icegatheringstatechange',listener);resolve();}};pc.addEventListener('icegatheringstatechange',listener);});
  if(signal.aborted)throw new Error('连接已取消');
  const answer=await request<{type:string;sdp:string}>(profile,'/api/desktop/rtc/offer',{method:'POST',body:{sessionId,sdp:pc.localDescription.sdp,quality},signal,timeoutMs:16000});await pc.setRemoteDescription(answer);
  statsTimer=setInterval(()=>{if(reading||closed)return;reading=true;void(async()=>{try{const stats=await pc.getStats();let bytes=0,frames=0,pair:any;const map=new Map<string,any>();stats.forEach((row:any)=>map.set(row.id,row));for(const row of map.values()){if(row.type==='inbound-rtp'&&(row.kind==='video'||row.mediaType==='video')){bytes+=row.bytesReceived||0;frames+=row.framesDecoded||0;}if(row.type==='transport'&&row.selectedCandidatePairId)pair=map.get(row.selectedCandidatePairId);}if(!pair)pair=[...map.values()].find(r=>r.type==='candidate-pair'&&r.state==='succeeded'&&r.nominated);const now=Date.now(),route=pair?(map.get(pair.localCandidateId)?.candidateType==='relay'||map.get(pair.remoteCandidateId)?.candidateType==='relay'?'TURN 中转':'P2P 直连'):'视频连接';onStats({fps:Math.max(0,Math.round((frames-lastFrames)*10000/Math.max(1,now-lastAt))/10),latency:Math.round((pair?.currentRoundTripTime||0)*1000),bytes,route});lastFrames=frames;lastAt=now;if(frames>0)onReady(true);if(channel.readyState==='open')void send('ping').catch(()=>{});}catch{close();}finally{reading=false;}})();},1000);
  return {send:(input:unknown)=>send('input',input),close,get connected(){return !closed&&channel.readyState==='open';}};
 }catch(e){close();throw e;}
}
