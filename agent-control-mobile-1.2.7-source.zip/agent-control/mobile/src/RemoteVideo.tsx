import React from 'react';
export function RemoteVideo({stream}:{stream:any}){return React.createElement('video',{autoPlay:true,playsInline:true,muted:true,ref:(node:any)=>{if(node&&node.srcObject!==stream){node.srcObject=stream;void node.play().catch(()=>{});}},style:{position:'relative',width:'100%',height:'100%',objectFit:'contain',pointerEvents:'none'}});}
