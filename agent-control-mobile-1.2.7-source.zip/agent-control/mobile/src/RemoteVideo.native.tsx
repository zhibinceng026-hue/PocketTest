import React from 'react';
const {RTCView}=require('react-native-webrtc');
export function RemoteVideo({stream}:{stream:any}){return <RTCView streamURL={stream.toURL()} objectFit="contain" style={{width:'100%',height:'100%'}}/>;}
