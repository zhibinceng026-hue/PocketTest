import React from 'react';
const {RTCView}=require('react-native-webrtc');
export function RemoteVideo({stream}:{stream:any}){return <RTCView streamURL={stream.toURL()} objectFit="contain" style={{position:'absolute',top:0,right:0,bottom:0,left:0}}/>;}
