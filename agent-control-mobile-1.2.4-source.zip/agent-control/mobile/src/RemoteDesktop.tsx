import React,{useEffect,useRef,useState} from 'react';
import {ActivityIndicator,AppState,Image,KeyboardAvoidingView,Modal,Platform,Pressable,ScrollView,StyleSheet,Text,TextInput,View,useWindowDimensions} from 'react-native';
import {SafeAreaProvider,SafeAreaView} from 'react-native-safe-area-context';
import {ArrowLeft,MousePointer2,Monitor,RefreshCw,Send} from 'lucide-react-native';
import {StatusBar} from 'expo-status-bar';
import {request} from './api';
import {friendlyError} from './errors';
import {colors as c} from './theme';
import type {Profile} from './types';

type Frame={image:string;width:number;height:number;cursorX:number;cursorY:number};
type Mode='click'|'rightClick'|'doubleClick'|'drag';
const modes:{id:Mode;label:string}[]=[{id:'click',label:'点击'},{id:'rightClick',label:'右键'},{id:'doubleClick',label:'双击'},{id:'drag',label:'拖动'}];
function Button({label,onPress,disabled=false}:{label:string;onPress:()=>void;disabled?:boolean}){return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} disabled={disabled} style={[s.button,disabled&&{opacity:.35}]}><Text style={s.buttonText}>{label}</Text></Pressable>;}

export function RemoteDesktop({profile,name,onClose}:{profile:Profile;name:string;onClose:()=>void}){
  const [fullScreen,setFullScreen]=useState(false),[toolsOpen,setToolsOpen]=useState(true),[pointerMode,setPointerMode]=useState(false);
  const [view,setView]=useState({zoom:1,x:0,y:0}),[pointer,setPointer]=useState({x:.5,y:.5});
  const viewRef=useRef(view);viewRef.current=view;const gesture=useRef<any>(null);
  const {width,height}=useWindowDimensions();const landscape=width>height;
  const [frame,setFrame]=useState<Frame|null>(null),[error,setError]=useState(''),[connecting,setConnecting]=useState(true),[control,setControl]=useState(false),[mode,setMode]=useState<Mode>('click'),[text,setText]=useState(''),[sending,setSending]=useState(false),[revision,setRevision]=useState(0),[active,setActive]=useState(AppState.currentState==='active');
  const session=useRef<string|null>(null),busy=useRef(false),surface=useRef({width:0,height:0}),start=useRef<{x:number;y:number}|null>(null),mounted=useRef(true);
  useEffect(()=>{const sub=AppState.addEventListener('change',state=>setActive(state==='active'));return ()=>sub.remove();},[]);
  useEffect(()=>()=>{mounted.current=false;},[]);
  useEffect(()=>{
    let alive=true,timer:ReturnType<typeof setTimeout>|undefined;const abort=new AbortController();let owned:string|null=null;
    setFrame(null);setControl(false);setError('');setConnecting(active);
    function update(value:Frame){if(!value||!Number.isInteger(value.width)||!Number.isInteger(value.height)||value.width<1||value.width>1280||value.height<1||value.height>800||typeof value.image!=='string'||value.image.length>3000000)throw new Error('电脑返回的桌面画面无效，请重新连接。');if(alive)setFrame(value);}
    async function poll(){if(!alive||!owned)return;try{update(await request(profile,`/api/desktop/frame?session=${encodeURIComponent(owned)}`,{signal:abort.signal}));if(alive){setError('');timer=setTimeout(()=>void poll(),500);}}catch(e){if(alive){setFrame(null);setControl(false);setError(friendlyError(e));}}}
    if(active)void (async()=>{try{
      const value=await request<Frame&{sessionId:string}>(profile,'/api/desktop/session',{method:'POST',body:{confirm:'VIEW'},signal:abort.signal});owned=value.sessionId;
      if(!alive){void request(profile,'/api/desktop/session',{method:'DELETE',body:{sessionId:owned}}).catch(()=>{});return;}
      session.current=owned;update(value);setConnecting(false);timer=setTimeout(()=>void poll(),500);
    }catch(e){if(alive){setConnecting(false);setError(friendlyError(e));}}})();
    return ()=>{alive=false;if(timer)clearTimeout(timer);abort.abort();session.current=null;if(owned)void request(profile,'/api/desktop/session',{method:'DELETE',body:{sessionId:owned}}).catch(()=>{});};
  },[profile.url,profile.token,revision,active]);
  async function input(value:unknown){
    const id=session.current;if(!control||!id||busy.current||!frame||!active)return;
    busy.current=true;setSending(true);setError('');
    try{await request(profile,'/api/desktop/input',{method:'POST',body:{sessionId:id,input:value}});}
    catch(e){if(mounted.current)setError(friendlyError(e));throw e;}
    finally{busy.current=false;if(mounted.current)setSending(false);}
  }
  function point(x:number,y:number){if(!frame)return null;const box=surface.current,v=viewRef.current;x=(x-box.width/2-v.x)/v.zoom+box.width/2;y=(y-box.height/2-v.y)/v.zoom+box.height/2;const scale=Math.min(box.width/frame.width,box.height/frame.height),w=frame.width*scale,h=frame.height*scale;const px=(x-(box.width-w)/2)/w,py=(y-(box.height-h)/2)/h;return px>=0&&px<=1&&py>=0&&py<=1?{x:px,y:py}:null;}
  function begin(e:any){const t=e.nativeEvent.touches;if(!t.length)return;const a=t[0],b=t[1];gesture.current={px:a.pageX,py:a.pageY,view:{...viewRef.current},pointer:{...pointer},distance:b?Math.hypot(a.pageX-b.pageX,a.pageY-b.pageY):0,moved:false,multi:!!b};start.current=point(e.nativeEvent.locationX,e.nativeEvent.locationY);}
  function move(e:any){const g=gesture.current,t=e.nativeEvent.touches;if(!g||!t.length)return;const a=t[0],b=t[1],dx=a.pageX-g.px,dy=a.pageY-g.py;if(b){g.multi=true;const d=Math.hypot(a.pageX-b.pageX,a.pageY-b.pageY);if(!g.distance){g.distance=d;g.view={...viewRef.current};}const zoom=Math.max(1,Math.min(4,g.view.zoom*d/Math.max(1,g.distance)));setView({zoom,x:g.view.x,y:g.view.y});return;}if(Math.abs(dx)+Math.abs(dy)>5)g.moved=true;if(pointerMode&&control){setPointer({x:Math.max(0,Math.min(1,g.pointer.x+dx/surface.current.width/viewRef.current.zoom)),y:Math.max(0,Math.min(1,g.pointer.y+dy/surface.current.height/viewRef.current.zoom))});}else if(!control&&viewRef.current.zoom>1){const v=g.view;setView({...v,x:Math.max(-width*(v.zoom-1)/2,Math.min(width*(v.zoom-1)/2,v.x+dx)),y:Math.max(-height*(v.zoom-1)/2,Math.min(height*(v.zoom-1)/2,v.y+dy))});}}
  function release(x:number,y:number){const g=gesture.current;gesture.current=null;const from=start.current;start.current=null;if(!control||g?.multi)return;const to=pointerMode?pointer:point(x,y);if(!from||!to)return;if(mode==='drag'){void input({type:'drag',...(pointerMode?g.pointer:from),to}).catch(()=>{});return;}if(!g?.moved)void input({type:mode,...to}).catch(()=>{});}
  async function sendText(){if(!text.trim())return;const value=text;try{await input({type:'text',text:value});if(mounted.current)setText(current=>current===value?'':current);}catch{}}
  const enabled=!!frame&&active&&!connecting;
  const box=surface.current,fit=frame?Math.min(box.width/frame.width,box.height/frame.height):1;
  const cursorLeft=frame?(box.width-frame.width*fit)/2+pointer.x*frame.width*fit:0,cursorTop=frame?(box.height-frame.height*fit)/2+pointer.y*frame.height*fit:0;
  return <Modal visible animationType="slide" presentationStyle="fullScreen" supportedOrientations={['portrait','portrait-upside-down','landscape-left','landscape-right']} onRequestClose={onClose}><SafeAreaProvider><SafeAreaView style={s.safe}><StatusBar hidden={fullScreen}/><KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
    {!fullScreen&&<View style={s.header}><Pressable accessibilityRole="button" accessibilityLabel="断开并返回" onPress={onClose} hitSlop={12} style={s.back}><ArrowLeft color={c.text} size={22}/></Pressable><View style={{flex:1}}><Text style={s.title}>{name}</Text><Text style={s.caption}>{connecting?'正在连接桌面…':frame?'内置远程桌面 · 已连接':active?'桌面未连接':'已暂停共享'}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="重新连接桌面" onPress={()=>setRevision(v=>v+1)} disabled={connecting} style={s.back}><RefreshCw color={c.green} size={21}/></Pressable></View>}
    {!!error&&<View style={s.error}><Text accessibilityRole="alert" style={s.errorText}>{error}</Text></View>}
    <View accessibilityLabel="远程电脑画面" style={s.screen} onLayout={e=>{surface.current=e.nativeEvent.layout;}} onStartShouldSetResponder={()=>enabled} onMoveShouldSetResponder={()=>enabled} onResponderGrant={begin} onResponderMove={move} onResponderRelease={e=>release(e.nativeEvent.locationX,e.nativeEvent.locationY)} onResponderTerminate={()=>{start.current=null;}}>
      {frame?<View pointerEvents="none" style={{width:'100%',height:'100%',transform:[{translateX:view.x},{translateY:view.y},{scale:view.zoom}]}}><Image style={{width:'100%',height:'100%'}} resizeMode="contain" source={{uri:`data:image/jpeg;base64,${frame.image}`}} accessibilityLabel="Windows 桌面"/>{pointerMode&&<View style={{position:'absolute',left:cursorLeft,top:cursorTop}}><MousePointer2 size={22} color={c.green}/></View>}</View>:<View style={{alignItems:'center',gap:16,padding:24}}>{connecting?<ActivityIndicator color={c.green} size="large"/>:<Monitor color={c.muted} size={44}/>}<Text style={[s.caption,{textAlign:'center'}]}>{connecting?'正在读取 Windows 画面':active?'电脑需保持登录并解锁。可点击右上角重连。':'返回前台后重新连接。'}</Text></View>}
    </View>
    {toolsOpen&&<ScrollView style={[{flexGrow:0,maxHeight:landscape?Math.max(100,height*.6):360},fullScreen&&{position:'absolute',bottom:8,right:8,width:Math.min(340,width-24),backgroundColor:'#111A22EE',borderRadius:18}]} contentContainerStyle={s.tools} keyboardShouldPersistTaps="handled"><View style={[s.row,{flexWrap:'wrap'}]}><Button label={fullScreen?'退出全屏':'全屏'} onPress={()=>{setFullScreen(v=>!v);setToolsOpen(false);}}/><Button label="收起工具栏" onPress={()=>setToolsOpen(false)}/><Button label={pointerMode?'鼠标指针':'直接触屏'} onPress={()=>setPointerMode(v=>!v)}/><Button label="重置缩放" onPress={()=>setView({zoom:1,x:0,y:0})}/><Button label="显示桌面" disabled={!control} onPress={()=>void input({type:'key',key:'showDesktop'}).catch(()=>{})}/></View><View style={s.row}><MousePointer2 size={17} color={control?c.green:c.muted}/><Text style={[s.caption,{flex:1}]}>{control?'触摸画面操作电脑':'查看模式'}</Text><Button label={control?'切回仅查看':'开启触摸控制'} disabled={!enabled} onPress={()=>setControl(v=>!v)}/></View>
      {control&&<><View style={s.row}>{modes.map(item=><Pressable accessibilityRole="button" key={item.id} accessibilityLabel={item.label} onPress={()=>setMode(item.id)} style={[s.button,{flex:1},mode===item.id&&{backgroundColor:'#2B4230'}]}><Text style={[s.buttonText,mode===item.id&&{color:c.green}]}>{item.label}</Text></Pressable>)}</View><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:7}}>{[{label:'向上滚动',input:{type:'scroll',delta:360}},{label:'向下滚动',input:{type:'scroll',delta:-360}},...['enter','escape','tab','backspace','copy','paste','selectAll','altTab'].map((key,i)=>({label:['回车','Esc','Tab','退格','复制','粘贴','全选','切换窗口'][i]!,input:{type:'key',key}}))].map(item=><Button key={item.label} label={item.label} disabled={sending||!enabled} onPress={()=>void input(item.input).catch(()=>{})}/>)}</ScrollView><View style={s.composer}><TextInput accessibilityLabel="输入到远程电脑" style={s.input} placeholder="先点击电脑中的输入框，再输入文字…" placeholderTextColor={c.muted} value={text} onChangeText={setText} maxLength={1000} multiline/><Pressable accessibilityRole="button" accessibilityLabel="发送文字到电脑" onPress={()=>void sendText()} disabled={sending||!text.trim()||!enabled} style={[s.send,(sending||!text.trim()||!enabled)&&{opacity:.4}]}><Send size={20} color={c.bg}/></Pressable></View></>}
      <Text style={s.hint}>轻量画面刷新 · 主屏幕 · 不含声音 · 退出即断开</Text>
    </ScrollView>}
    {!toolsOpen&&<View style={{position:'absolute',top:8,right:12,flexDirection:'row',gap:8}}><Button label="工具" onPress={()=>setToolsOpen(true)}/>{fullScreen&&<Button label="退出全屏" onPress={()=>setFullScreen(false)}/>}<Button label="断开" onPress={onClose}/></View>}
  </KeyboardAvoidingView></SafeAreaView></SafeAreaProvider></Modal>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:c.bg},header:{height:70,paddingHorizontal:16,flexDirection:'row',alignItems:'center',gap:10},back:{width:44,height:44,alignItems:'center',justifyContent:'center'},title:{fontSize:16,color:c.text,fontWeight:'600'},caption:{fontSize:11,color:c.muted,lineHeight:19},screen:{flex:1,minHeight:100,overflow:'hidden',backgroundColor:'#050808',justifyContent:'center',alignItems:'center'},error:{marginHorizontal:16,marginBottom:10,padding:12,borderRadius:12,backgroundColor:'#321F22'},errorText:{fontSize:12,lineHeight:20,color:c.red},tools:{padding:14,gap:10,borderTopWidth:1,borderTopColor:c.line},row:{flexDirection:'row',alignItems:'center',gap:7},button:{minHeight:44,paddingHorizontal:11,borderRadius:11,alignItems:'center',justifyContent:'center',backgroundColor:'#1B2530'},buttonText:{fontSize:11,color:c.text},composer:{flexDirection:'row',gap:10,alignItems:'center',padding:8,borderRadius:14,backgroundColor:'#17212B'},input:{flex:1,minHeight:44,maxHeight:90,color:c.text,fontSize:13,padding:8},send:{width:44,height:44,backgroundColor:c.green,borderRadius:12,alignItems:'center',justifyContent:'center'},hint:{fontSize:10,color:c.muted,textAlign:'center'}});
