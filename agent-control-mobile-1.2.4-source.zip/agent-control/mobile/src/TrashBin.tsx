import React,{useEffect,useState} from 'react';
import {Modal,View,Text,Pressable,ScrollView} from 'react-native';
import {SafeAreaProvider,SafeAreaView} from 'react-native-safe-area-context';
import {request} from './api';
import {friendlyError} from './errors';
import {colors as c} from './theme';
import type {Profile} from './types';
export function TrashBin({profile,onClose,onRestore}:{profile:Profile;onClose:()=>void;onRestore:()=>void}){
 const [rows,setRows]=useState<any[]>([]),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 async function load(){setBusy(true);setError('');try{setRows((await request(profile,'/api/trash')).threads);}catch(e){setError(friendlyError(e));}finally{setBusy(false);}}
 useEffect(()=>{void load();},[profile.url,profile.token]);
 async function restore(row:any){setBusy(true);setError('');try{await request(profile,'/api/trash/restore',{method:'POST',body:{agentId:row.agentId,threadId:row.threadId}});setRows(prev=>prev.filter(r=>r!==row));onRestore();}catch(e){setError(friendlyError(e));}finally{setBusy(false);}}
 return <Modal visible animationType="slide" onRequestClose={onClose}><SafeAreaProvider><SafeAreaView style={{flex:1,backgroundColor:c.bg,padding:22}}><View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><Text style={{fontSize:24,color:c.text}}>会话垃圾箱</Text><Pressable accessibilityRole="button" accessibilityLabel="关闭垃圾箱" onPress={onClose} style={{padding:16}}><Text style={{color:c.green}}>完成</Text></Pressable></View><Text style={{color:c.muted,lineHeight:22,marginVertical:16}}>会话保留 7 天。电脑服务在线时自动清理到期内容；离线时延后清理。</Text>{!!error&&<Text style={{color:c.red}}>{error}</Text>}<ScrollView>{!busy&&!rows.length&&!error&&<Text style={{color:c.muted}}>垃圾箱为空</Text>}{rows.map(row=><View key={row.agentId+row.threadId} style={{backgroundColor:c.surface,padding:18,borderRadius:16,marginBottom:12,gap:10}}><Text style={{color:c.text,fontSize:16}}>{row.name}</Text><Text style={{color:c.muted}}>{row.agentId} · 剩余 {row.remainingDays} 天</Text><Text style={{color:c.muted}}>{new Date(row.deletedAt).toLocaleString()}</Text><Pressable accessibilityRole="button" accessibilityLabel={'恢复会话 '+row.name} disabled={busy||row.remainingDays===0} onPress={()=>void restore(row)} style={{paddingVertical:14}}><Text style={{color:c.green}}>{row.remainingDays?'恢复会话':'已到期，待清理'}</Text></Pressable></View>)}</ScrollView><Pressable accessibilityRole="button" disabled={busy} onPress={()=>void load()} style={{padding:16}}><Text style={{color:c.green}}>{busy?'正在处理…':'刷新垃圾箱'}</Text></Pressable></SafeAreaView></SafeAreaProvider></Modal>;
}
