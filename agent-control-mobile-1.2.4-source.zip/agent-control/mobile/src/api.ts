import type {Profile} from './types';
export function validateBase(value:string) {
  const url=new URL(value.trim());
  if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw new Error('请填写完整的电脑端 http(s) 地址，不要包含令牌或查询参数。');
  if(url.protocol==='http:') {
    const host=url.hostname;
    if(!/^(localhost|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.\d+\.\d+)$/.test(host)&&!host.endsWith('.ts.net')&&!host.endsWith('.local'))throw new Error('公网地址须使用 HTTPS。HTTP 只用于可信局域网或私有 VPN。');
  }
  if(url.pathname!=='/'&&url.pathname!==''&&!/^\/d\/[a-f0-9-]{36}$/.test(url.pathname))throw new Error('请填写服务根地址，例如 http://192.168.1.10:48721');
  return url.origin+(url.pathname==='/'?'':url.pathname);
}
export class RequestError extends Error {constructor(message:string,public status:number,public code?:string){super(message);}}
const listeners=new Set<(profile:Profile,online:boolean)=>void>();
export function watchConnection(listener:(profile:Profile,online:boolean)=>void){listeners.add(listener);return()=>{listeners.delete(listener);};}
export async function request<T=any>(profile:Profile,path:string,options:{method?:string;body?:unknown;signal?:AbortSignal;wake?:boolean;timeoutMs?:number}={}):Promise<T> {
  const base=validateBase(options.wake&&profile.wakeUrl?profile.wakeUrl:profile.url);
  const token=options.wake&&profile.wakeToken?profile.wakeToken:profile.token;
  const abort=new AbortController();let timer:ReturnType<typeof setTimeout>|undefined;
  const cancel=()=>abort.abort();options.signal?.addEventListener('abort',cancel);if(options.signal?.aborted)abort.abort();
  try {
    return await Promise.race([ (async()=>{
    const response=await fetch(base+path,{method:options.method||'GET',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:options.body!==undefined?JSON.stringify(options.body):undefined,signal:abort.signal});
    let data;try{data=await response.json();}catch{throw new RequestError(`服务器暂时未返回有效数据 (${response.status})，请稍后重试。`,response.status);}
    if(!response.ok)throw new RequestError(data.error||`连接失败 (${response.status})`,response.status,data.code);if(path==='/api/device')for(const listener of listeners)listener(profile,true);return data as T;
    })(),new Promise<never>((_,reject)=>{timer=setTimeout(()=>{abort.abort();reject(new RequestError('连接超时',0,'CONNECTION_TIMEOUT'));},options.timeoutMs||(path.includes('/events')?30000:15000));})]);
  }catch(error){if(!options.signal?.aborted&&!options.wake&&(path==='/api/device'||!(error instanceof RequestError)||[0,401].includes(error.status)))for(const listener of listeners)listener(profile,false);throw error;}
  finally{clearTimeout(timer);options.signal?.removeEventListener('abort',cancel);}
}
