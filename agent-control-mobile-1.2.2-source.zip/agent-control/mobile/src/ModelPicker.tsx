import React,{useEffect,useState} from 'react';
import {ActivityIndicator,Modal,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import * as SecureStore from 'expo-secure-store';
import {Platform} from 'react-native';
import {request} from './api';
import type {Profile} from './types';
import {colors as c} from './theme';
type Model={id:string;model:string;displayName:string;description?:string;hidden?:boolean;supportedReasoningEfforts?:{reasoningEffort:string;description:string}[]};
export type ModelSelection={model?:string;effort?:string};
const labels:Record<string,string>={none:'无',minimal:'最低',low:'低',medium:'中',high:'高',xhigh:'更高',max:'最高',ultra:'极高'};
export function ModelPicker({profile,agentId,demo,disabled,onChange}:{profile:Profile;agentId:string;demo:boolean;disabled:boolean;onChange:(value:ModelSelection)=>void}){
  const [models,setModels]=useState<Model[]>([]),[selection,setSelection]=useState<ModelSelection>({}),[open,setOpen]=useState(false),[loading,setLoading]=useState(false),[error,setError]=useState(''),[supported,setSupported]=useState(true),[retry,setRetry]=useState(0);
  const key=profile.url+'|'+agentId;
  const storage='agent-control.model.v1.'+Array.from(key).map(ch=>ch.charCodeAt(0).toString(16)).join('');
  useEffect(()=>{let cancelled=false;setModels([]);setSelection({});onChange({});setError('');setSupported(true);
    if(demo){setLoading(false);return;}
    setLoading(true);
    void(async()=>{try{let data:Model[]=[],cursor:string|null=null;const seen=new Set();do{const page:{supported:boolean;data:Model[];nextCursor?:string|null}=await request<{supported:boolean;data:Model[];nextCursor?:string|null}>(profile,`/api/agents/${encodeURIComponent(agentId)}/models`+(cursor?'?cursor='+encodeURIComponent(cursor):''));if(cancelled)return;if(!page.supported){setSupported(false);return;}data.push(...page.data.filter(m=>!m.hidden));cursor=page.nextCursor||null;if(cursor&&seen.has(cursor))throw new Error('模型列表分页异常，请重试。');seen.add(cursor);}while(cursor);
      if(cancelled)return;setModels(data);if(Platform.OS!=='web'){try{const raw=await SecureStore.getItemAsync(storage);if(cancelled)return;if(raw){const saved=JSON.parse(raw),model=data.find(m=>m.model===saved.model);if(model){const value={model:model.model,...(model.supportedReasoningEfforts?.some(e=>e.reasoningEffort===saved.effort)?{effort:saved.effort}:{})};setSelection(value);onChange(value);}}}catch{/* Keep system default if preference is unreadable. */}}
    }catch{if(!cancelled)setError('无法读取模型，请确认电脑端已更新并连接，点击重试。');}finally{if(!cancelled)setLoading(false);}})();return()=>{cancelled=true;};
  },[key,profile.token,demo,retry]);
  function choose(value:ModelSelection){setSelection(value);onChange(value);if(Platform.OS!=='web')void SecureStore.setItemAsync(storage,JSON.stringify(value)).catch(()=>{});}
  const current=models.find(m=>m.model===selection.model);
  return <><Pressable accessibilityRole="button" accessibilityLabel="选择模型与推理强度" disabled={disabled} onPress={()=>setOpen(true)} style={s.trigger}><Text style={s.text}>{loading?'正在读取模型…':current?.displayName||'模型 · 沿用会话设置'}{selection.effort?' · '+(labels[selection.effort]||selection.effort):''} ▾</Text></Pressable>
    <Modal visible={open} transparent animationType="slide" onRequestClose={()=>setOpen(false)}><View style={s.overlay}><Pressable accessibilityLabel="关闭模型选择" style={{flex:1}} onPress={()=>setOpen(false)}/><View style={s.panel}><Text style={s.title}>模型与推理强度</Text><Text style={s.hint}>选择用于下一轮消息，正在执行时无法切换。</Text><ScrollView style={{maxHeight:420}} keyboardShouldPersistTaps="handled">
      {loading&&<ActivityIndicator color={c.green}/>}{demo&&<Text style={s.hint}>连接电脑后显示当前账号可用的模型。</Text>}{!supported&&<Text style={s.hint}>此智能体暂不支持模型选择。</Text>}{!!error&&<Pressable accessibilityRole="button" accessibilityLabel="重试读取模型" onPress={()=>setRetry(n=>n+1)}><Text style={s.error}>{error}</Text></Pressable>}
      <Pressable accessibilityRole="button" onPress={()=>choose({})} style={s.row}><Text style={s.text}>{!selection.model?'✓ ':''}沿用会话设置</Text></Pressable>
      {models.map(model=><Pressable key={model.id} accessibilityRole="button" accessibilityLabel={'选择模型 '+model.displayName} accessibilityState={{selected:selection.model===model.model}} onPress={()=>choose({model:model.model})} style={s.row}><Text style={s.text}>{selection.model===model.model?'✓ ':''}{model.displayName}</Text>{!!model.description&&<Text style={s.hint}>{model.description}</Text>}</Pressable>)}
      {current&&<><Text style={s.title}>推理强度</Text><View style={s.options}>{[{reasoningEffort:'',description:'模型默认'},...(current.supportedReasoningEfforts||[])].map(option=><Pressable key={option.reasoningEffort} accessibilityRole="button" accessibilityLabel={'推理强度 '+(labels[option.reasoningEffort]||option.reasoningEffort||'默认')} accessibilityState={{selected:(selection.effort||'')===option.reasoningEffort}} onPress={()=>choose({model:current.model,...(option.reasoningEffort?{effort:option.reasoningEffort}:{})})} style={[s.option,(selection.effort||'')===option.reasoningEffort&&s.selected]}><Text style={s.text}>{labels[option.reasoningEffort]||option.reasoningEffort||'默认'}</Text></Pressable>)}</View></>}
      </ScrollView><Pressable accessibilityRole="button" accessibilityLabel="完成模型选择" onPress={()=>setOpen(false)} style={s.row}><Text style={[s.text,{color:c.green,textAlign:'center'}]}>完成</Text></Pressable></View></View></Modal></>;
}
const s=StyleSheet.create({trigger:{paddingVertical:10,paddingHorizontal:4},text:{color:c.text,fontSize:13},overlay:{flex:1,backgroundColor:'#0008'},panel:{backgroundColor:'#17212B',padding:22,paddingBottom:34,borderTopLeftRadius:22,borderTopRightRadius:22},title:{color:c.text,fontSize:17,fontWeight:'700',marginVertical:12},hint:{color:c.muted,fontSize:12,lineHeight:19,marginVertical:5},error:{color:c.red,fontSize:13,lineHeight:20,paddingVertical:12},row:{paddingVertical:14,borderBottomWidth:1,borderBottomColor:'#34433F'},options:{flexDirection:'row',flexWrap:'wrap',gap:10,marginVertical:12},option:{padding:12,borderRadius:10,borderWidth:1,borderColor:'#34433F'},selected:{borderColor:c.green,backgroundColor:'#253624'}});
