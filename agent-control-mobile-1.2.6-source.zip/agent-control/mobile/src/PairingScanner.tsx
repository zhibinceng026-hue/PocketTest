import React,{useRef} from 'react';
import {Modal,View,Text,Pressable,StyleSheet} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {CameraView,useCameraPermissions} from 'expo-camera';
import {X,Camera} from 'lucide-react-native';
import {colors as c} from './theme';
export function PairingScanner({visible,onClose,onScan,purpose='pairing'}:{purpose?:'pairing'|'wake';visible:boolean;onClose:()=>void;onScan:(text:string)=>void}){
 const [permission,request]=useCameraPermissions();const scanned=useRef(false);
 return <Modal visible={visible} animationType="slide" onShow={()=>{scanned.current=false;}} onRequestClose={onClose}><SafeAreaView style={s.safe}><View style={s.header}><Text style={s.title}>{purpose==='wake'?'扫描唤醒配置码':'扫描电脑配对码'}</Text><Pressable accessibilityLabel="关闭扫码" onPress={onClose}><X color={c.text} size={24}/></Pressable></View><Text style={s.note}>{purpose==='wake'?'在电脑“电源与桌面 → 网络唤醒配置”中打开“手机扫码继续”。':'在电脑“连接与配对”中打开二维码。配对码包含访问令牌，请勿分享。'}</Text>{visible&&permission?.granted?<View style={s.frame}><CameraView style={{flex:1}} facing="back" barcodeScannerSettings={{barcodeTypes:['qr']}} onBarcodeScanned={event=>{if(scanned.current)return;scanned.current=true;onScan(event.data);}}/></View>:<View style={s.ask}><Camera color={c.green} size={46}/><Text style={s.note}>仅在此页面使用相机识别二维码。</Text><Pressable style={s.button} onPress={()=>void request()}><Text style={{color:c.bg}}>允许使用相机</Text></Pressable></View>}<Text style={s.note}>{purpose==='wake'?'扫描后读取已配对电脑的唤醒检测结果，不会自动让电脑睡眠。':'识别后核对地址，点击“保存并连接电脑”。智能体账户仍在电脑登录。'}</Text></SafeAreaView></Modal>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:c.bg,padding:24},header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingVertical:20},title:{fontSize:23,color:c.text,fontWeight:'600'},note:{fontSize:12,lineHeight:23,color:c.muted,marginVertical:15},frame:{height:360,overflow:'hidden',borderRadius:24,borderWidth:1,borderColor:c.green,marginVertical:20},ask:{height:360,alignItems:'center',justifyContent:'center'},button:{backgroundColor:c.green,padding:16,borderRadius:14}});
