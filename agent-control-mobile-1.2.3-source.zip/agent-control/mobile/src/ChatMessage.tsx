import React,{useState} from 'react';
import {ActivityIndicator,Image,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {Check,ChevronDown,ChevronRight,Command,ImagePlus,Terminal} from 'lucide-react-native';
import {colors as c} from './theme';
import type {Item,Profile,Turn} from './types';
import {friendlyError,diagnosticText} from './errors';
import {markdownFileLinks} from './file-links';

function CodeBlock({language,code}:{language:string;code:string}){
  const [expanded,setExpanded]=useState(false);
  return <View style={s.detail}><Pressable accessibilityRole="button" accessibilityState={{expanded}} accessibilityLabel={expanded?'收起代码':'展开代码'} onPress={()=>setExpanded(!expanded)} style={s.row}><Terminal size={15} color={c.green}/><Text style={s.meta}>代码{language?' · '+language:''} · {code.split('\n').length} 行</Text>{expanded?<ChevronDown size={16} color={c.muted}/>:<ChevronRight size={16} color={c.muted}/>}</Pressable>{expanded&&<ScrollView horizontal style={{marginTop:12,maxHeight:320}} nestedScrollEnabled><ScrollView nestedScrollEnabled><Text selectable style={s.code}>{code}</Text></ScrollView></ScrollView>}</View>;
}
function AssistantText({text}:{text:string}){
  const parts:React.ReactNode[]=[];const pattern=/```([^\n`]*)\n([\s\S]*?)```/g;let from=0,match;
  while((match=pattern.exec(text))){if(match.index>from)parts.push(<Text selectable key={'text-'+from} style={s.text}>{text.slice(from,match.index).trim()}</Text>);parts.push(<CodeBlock key={'code-'+match.index} language={(match[1]||'').trim()} code={(match[2]||'').trimEnd()}/>);from=pattern.lastIndex;}
  const rest=text.slice(from);const pending=rest.indexOf('```');
  if(pending>=0){if(pending)parts.push(<Text selectable key="tail" style={s.text}>{rest.slice(0,pending)}</Text>);const block=rest.slice(pending+3);const newline=block.indexOf('\n');parts.push(<CodeBlock key="stream-code" language={newline<0?'':block.slice(0,newline)} code={newline<0?block:block.slice(newline+1)}/>);}else if(rest.trim())parts.push(<Text selectable key="tail" style={s.text}>{rest.trim()}</Text>);
  return <>{parts}</>;
}
function ChatMessage({item,agentName,profile}:{item:Item;agentName:string;profile:Profile}){
  if(item.type==='userMessage'){
    const text=item.content?.filter(x=>x.type==='text').map(x=>x.text).join('\n')||item.text;
    const images=item.content?.filter(x=>['image','localImage'].includes(x.type))||[];
    return <View style={s.user}>{!!text&&<Text selectable style={s.text}>{text}</Text>}{images.map((image,index)=>image.attachmentId?<Image key={index} accessibilityLabel="已发送的图片" source={{uri:`${profile.url}/api/attachments/${image.attachmentId}`,headers:{Authorization:`Bearer ${profile.token}`}}} style={s.image} resizeMode="contain"/>:<View key={index} style={s.row}><ImagePlus size={20} color={c.green}/><Text style={s.meta}>图片附件（来自电脑）</Text></View>)}</View>;
  }
  return <View style={{gap:12}}><View style={s.row}><Command size={17} color={c.green}/><Text style={s.name}>{agentName}</Text></View><AssistantText text={item.text||'正在生成…'}/></View>;
}
function ExecutionDetails({items,running}:{items:Item[];running:boolean}){
  const [expanded,setExpanded]=useState(false);
  const failed=items.some(item=>item.status==='failed');
  const label=failed?'部分步骤失败':running?'正在处理':'处理完成';
  return <View style={s.detail}><Pressable accessibilityRole="button" accessibilityLabel="执行详情" accessibilityState={{expanded}} onPress={()=>setExpanded(!expanded)} style={s.row}>{running?<ActivityIndicator size="small" color={c.green}/>:<Check size={16} color={failed?c.red:c.green}/>}<View style={{flex:1,gap:5}}><Text style={s.name}>{label} · {items.length} 个步骤</Text><Text style={s.meta}>{expanded?'再次点击收起':'点击查看命令、日志和文件变更'}</Text></View>{expanded?<ChevronDown size={17} color={c.muted}/>:<ChevronRight size={17} color={c.muted}/>}</Pressable>{expanded&&<ScrollView style={{maxHeight:400,marginTop:14}} nestedScrollEnabled>{items.map(item=><View key={item.id} style={s.step}><Text style={s.name}>{item.type==='commandExecution'?'执行命令':item.type==='fileChange'?'文件变更':item.type==='plan'?'执行计划':item.title||'处理步骤'} · {item.status==='completed'?'完成':item.status==='failed'?'失败':running?'进行中':'已记录'}</Text><Text selectable style={s.code}>{[item.command,item.aggregatedOutput,item.output,item.input===undefined?'':typeof item.input==='string'?item.input:JSON.stringify(item.input,null,2),...(item.changes||[]).map(change=>change.path+'\n'+(change.diff||'')),...(item.entries||[]).map(entry=>(entry.status==='completed'?'✓ ':'○ ')+entry.content)].filter(Boolean).join('\n\n').slice(0,12000)}</Text></View>)}</ScrollView>}</View>;
}
function TurnError({message}:{message:string}){const [expanded,setExpanded]=useState(false);return <View style={s.detail}><Text style={{color:c.red,fontSize:12,lineHeight:21}}>{friendlyError(message)}</Text><Pressable accessibilityRole="button" accessibilityState={{expanded}} onPress={()=>setExpanded(!expanded)}><Text style={[s.meta,{marginTop:10}]}>{expanded?'收起诊断详情':'查看诊断详情'}</Text></Pressable>{expanded&&<Text selectable style={s.code}>{diagnosticText(message)}</Text>}</View>;}
export function TurnMessages({turn,agentName,profile,onOpenFile}:{turn:Turn;agentName:string;profile:Profile;onOpenFile?:(path:string)=>void}){
  const steps=turn.items.filter(item=>!['userMessage','agentMessage'].includes(item.type));let detailsShown=false;
  const files=turn.items.flatMap(item=>item.type==='agentMessage'?markdownFileLinks(item.text||''):(item.changes||[]).map(change=>({label:change.path.split(/[\\/]/).pop()||change.path,target:change.path})));
  const unique=files.filter((file,index)=>files.findIndex(other=>other.target===file.target)===index);
  return <View style={{gap:20}}>{turn.items.map(item=>{
    if(['userMessage','agentMessage'].includes(item.type))return <ChatMessage key={item.id} item={item} agentName={agentName} profile={profile}/>;
    if(detailsShown)return null;detailsShown=true;return <ExecutionDetails key="execution" items={steps} running={turn.status==='inProgress'}/>;
  })}{!!unique.length&&onOpenFile&&<View style={s.detail}><Text style={s.name}>文件 · 点击查看或下载</Text>{unique.map(file=><Pressable key={file.target} accessibilityRole="button" accessibilityLabel={`打开文件 ${file.label}`} onPress={()=>onOpenFile(file.target)} style={[s.row,{paddingVertical:12}]}><Text style={[s.text,{flex:1,color:c.green}]}>{file.label}</Text><ChevronRight size={17} color={c.green}/></Pressable>)}</View>}{turn.error&&<TurnError message={turn.error.message||'执行失败，请重试。'}/>}</View>;
}
const s=StyleSheet.create({row:{flexDirection:'row',alignItems:'center',gap:9},name:{fontSize:12,fontWeight:'600',color:c.text},meta:{fontSize:11,color:c.muted,lineHeight:19},text:{color:'#D3DDE4',fontSize:14,lineHeight:26},user:{backgroundColor:'#223629',borderWidth:1,borderColor:'#344D37',borderRadius:17,borderBottomRightRadius:5,padding:16,marginLeft:26,gap:12},detail:{padding:15,borderRadius:16,backgroundColor:'#111B22',borderWidth:1,borderColor:'#26353E'},code:{fontFamily:'monospace',fontSize:11,lineHeight:20,color:'#AEBEC6',marginTop:8},step:{borderTopWidth:1,borderTopColor:'#29343C',paddingVertical:14},image:{width:'100%',height:190,borderRadius:12,backgroundColor:'#17241B'}});
