export type PipPhase='idle'|'starting'|'active'|'restoring';
export function retainVideoConnection(foreground:boolean,phase:PipPhase){return foreground||phase==='starting'||phase==='active'||phase==='restoring';}
export function nextPipPhase(state:string):PipPhase{
 if(state==='willStart')return 'starting';if(state==='didStart')return 'active';if(state==='restoreRequested')return 'restoring';return 'idle';
}
export type RemoteVideoHandle={startPip:()=>Promise<void>};
export type PipEvent={state:string;peerConnectionId?:number|null;background?:boolean;error?:{message?:string}};
