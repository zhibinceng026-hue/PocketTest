import React,{forwardRef,useImperativeHandle,useRef} from 'react';
import type {PipEvent,RemoteVideoHandle} from './pip-lifecycle';
export const RemoteVideo=forwardRef<RemoteVideoHandle,{stream:any;audio?:boolean;microphone?:boolean;nativePeerId?:number;onPip?:(event:PipEvent)=>void;onSize?:(width:number,height:number)=>void}>(function RemoteVideo({stream,audio=false,onSize,onPip},ref){
 const video=useRef<any>(null);
 useImperativeHandle(ref,()=>({async startPip(){if(!video.current?.requestPictureInPicture)throw new Error('当前浏览器不支持画中画。');await video.current.requestPictureInPicture();}}),[]);
 return React.createElement('video',{autoPlay:true,playsInline:true,muted:!audio,onEnterPictureInPicture:()=>onPip?.({state:'didStart'}),onLeavePictureInPicture:()=>onPip?.({state:'didStop'}),onLoadedMetadata:(event:any)=>onSize?.(event.currentTarget.videoWidth,event.currentTarget.videoHeight),onResize:(event:any)=>onSize?.(event.currentTarget.videoWidth,event.currentTarget.videoHeight),ref:(node:any)=>{video.current=node;if(node&&node.srcObject!==stream){node.srcObject=stream;void node.play().catch(()=>{});}},style:{position:'relative',width:'100%',height:'100%',objectFit:'contain',pointerEvents:'none'}});
});
