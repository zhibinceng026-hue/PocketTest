import type {Device,Thread,Notice,Approval,FileEntry,Turn} from './types';
export const demoDevice:Device={id:'demo',name:'Studio PC',state:'online',platform:'win32',uptime:14520,workspace:'D:\\Projects\\codex-control',codex:{connected:true,error:''},capabilities:{wake:false,sleep:false,desktop:false,push:false,previewPorts:[3000,5173]},rustdeskId:''};
export const demoThreads:Thread[]=[
  {id:'demo-1',name:'设计我的个人作品集',preview:'搭建极简作品集，优化手机端的阅读体验。',status:'active'},
  {id:'demo-2',name:'整理项目的组件结构',preview:'已完成 6 个组件的拆分，等待你确认。',status:'idle'},
  {id:'demo-3',name:'为登录流程增加测试',preview:'测试结果与修改记录已就绪。',status:'idle'},
];
export const demoTurns:Turn[]=[{id:'demo-turn',status:'inProgress',items:[
  {id:'u1',type:'userMessage',content:[{type:'text',text:'帮我设计一个极简的个人作品集。留白充足，支持手机浏览。'}]},
  {id:'a1',type:'agentMessage',text:'我会先梳理页面结构，再完成首页与项目展示。整体采用干净的字体和柔和的交互，让作品成为视觉中心。'},
  {id:'c1',type:'commandExecution',command:'检查项目结构与现有组件',aggregatedOutput:'找到 6 个可复用组件。\n开始构建页面与响应式布局。',status:'completed'},
  {id:'a2',type:'agentMessage',text:'首页布局已完成，正在调整手机端的间距。你可以随时补充想法。'},
]}];
export const demoNotices:Notice[]=[
  {id:'n1',title:'有一个操作等待确认',text:'为作品集安装所需依赖。',kind:'approval',at:Date.now()-120000},
  {id:'n2',title:'组件整理已完成',text:'6 个组件已拆分，修改记录可查看。',kind:'success',at:Date.now()-2400000},
  {id:'n3',title:'Studio PC 已连接',text:'这是示例数据。连接电脑后将显示实时状态。',kind:'info',at:Date.now()-3600000},
];
export const demoApprovals:Approval[]=[{id:'demo-approval',method:'item/commandExecution/requestApproval',threadId:'demo-1',at:Date.now(),params:{command:'npm install',reason:'安装作品集项目所需的依赖。',cwd:'D:\\Projects\\portfolio'}}];
export const demoFiles:FileEntry[]=[{name:'src',path:'src',directory:true,size:0},{name:'public',path:'public',directory:true,size:0},{name:'README.md',path:'README.md',directory:false,size:1624},{name:'package.json',path:'package.json',directory:false,size:832},{name:'App.tsx',path:'App.tsx',directory:false,size:4096}];
export const demoCode=`// 示例文件 · 不代表电脑上的真实内容\nimport React from 'react';\n\nexport default function Portfolio() {\n  return (\n    <main className="portfolio">\n      <h1>做一些有意思的事。</h1>\n      <p>Design. Build. Repeat.</p>\n    </main>\n  );\n}\n`;
