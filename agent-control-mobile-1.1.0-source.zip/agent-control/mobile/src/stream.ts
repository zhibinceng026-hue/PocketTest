import type {Item,Turn} from './types';
// Preserve in-flight data; stored turn history can lag live notifications.
export function reduceCodexEvent(turns:Turn[],message:{method:string;params?:any}):Turn[]{
  const p=message.params||{};
  if(message.method==='turn/started'&&p.turn){const turn={...p.turn,items:p.turn.items||[]};return turns.some(t=>t.id===turn.id)?turns.map(t=>t.id===turn.id?{...t,...turn}:t):[...turns,turn];}
  if(message.method==='turn/completed'&&p.turn){return turns.map(t=>t.id===p.turn.id?{...t,...p.turn,items:p.turn.items?.length?p.turn.items:t.items}:t);}
  if(['item/started','item/completed'].includes(message.method)&&p.item){return turns.map(t=>t.id===p.turnId?{...t,items:t.items.some(i=>i.id===p.item.id)?t.items.map(i=>i.id===p.item.id?{...i,...p.item}:i):[...t.items,p.item]}:t);}
  if(message.method==='item/agentMessage/delta'){return turns.map(t=>t.id===p.turnId?{...t,items:t.items.some(i=>i.id===p.itemId)?t.items.map(i=>i.id===p.itemId?{...i,text:(i.text||'')+p.delta}:i):[...t.items,{id:p.itemId,type:'agentMessage',text:p.delta}]}:t);}
  if(message.method==='item/commandExecution/outputDelta'){return turns.map(t=>t.id===p.turnId?{...t,items:t.items.map(i=>i.id===p.itemId?{...i,aggregatedOutput:(i.aggregatedOutput||'')+p.delta}:i)}:t);}
  return turns;
}
