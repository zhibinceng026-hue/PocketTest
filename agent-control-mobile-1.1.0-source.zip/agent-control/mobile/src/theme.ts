export const colors={bg:'#0A0E13',surface:'#121820',raised:'#19212B',line:'#26303B',muted:'#83919F',text:'#F2F5F7',green:'#B9F584',greenDark:'#233927',cyan:'#8DCCD2',amber:'#F0C784',red:'#EF9D9D'};
export const spacing={page:24,gap:14,radius:22};
