import React,{useRef} from 'react';
import {Modal,View,Text,Pressable,StyleSheet} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {CameraView,useCameraPermissions} from 'expo-camera';
import {X,Camera} from 'lucide-react-native';
import {colors as c} from './theme';
export function PairingScanner({visible,onClose,onScan}:{visible:boolean;onClose:()=>void;onScan:(text:string)=>void}){
 const [permission,request]=useCameraPermissions();const scanned=useRef(false);
 return <Modal visible={visible} animationType="slide" onShow={()=>{scanned.current=false;}} onRequestClose={onClose}><SafeAreaView style={s.safe}><View style={s.header}><Text style={s.title}>扫描电脑配对码</Text><Pressable accessibilityLabel="关闭扫码" onPress={onClose}><X color={c.text} size={24}/></Pressable></View><Text style={s.note}>在 Windows 打开 .local/pairing.png。配对码包含访问令牌，请勿发给他人。</Text>{visible&&permission?.granted?<View style={s.frame}><CameraView style={{flex:1}} facing="back" barcodeScannerSettings={{barcodeTypes:['qr']}} onBarcodeScanned={event=>{if(scanned.current)return;scanned.current=true;onScan(event.data);}}/></View>:<View style={s.ask}><Camera color={c.green} size={46}/><Text style={s.note}>仅在此页面使用相机识别电脑配对码。</Text><Pressable style={s.button} onPress={()=>void request()}><Text style={{color:c.bg}}>允许使用相机</Text></Pressable></View>}<Text style={s.note}>识别后先核对地址，再点击“保存并连接电脑”。智能体账户仍在电脑端登录。</Text></SafeAreaView></Modal>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:c.bg,padding:24},header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingVertical:20},title:{fontSize:23,color:c.text,fontWeight:'600'},note:{fontSize:12,lineHeight:23,color:c.muted,marginVertical:15},frame:{height:360,overflow:'hidden',borderRadius:24,borderWidth:1,borderColor:c.green,marginVertical:20},ask:{height:360,alignItems:'center',justifyContent:'center'},button:{backgroundColor:c.green,padding:16,borderRadius:14}});
