# 第三方说明

视频传输组件捆绑 steveseguin/electron 43.3.0-qp20 Windows x64 发行版（基于 Electron，源码提交 4c920bf59e513986bb78b6464d2ec7da15ac49ab；来源 https://github.com/steveseguin/electron/releases/tag/v43.3.0-qp20 ），保留发行包内 LICENSE、LICENSES.chromium.html 等许可文件。手机端采用 react-native-webrtc 155.0.1，其 WebRTC 及依赖许可随原生构建保留。屏幕视频使用 WebRTC，ICE 默认尝试 STUN 直连；TURN 服务由使用者配置，不包含第三方服务账号或固定凭据。

本项目自身采用 MIT。各依赖保持原许可；安装时应保留其 node_modules 内的 LICENSE/NOTICE。

接入目录 `bridge/agents/catalog.json` 与手机内同名数据是从 [Agent Client Protocol Registry](https://github.com/agentclientprotocol/registry) 的项目元数据整理的摘要，记录来源地址、项目名称、许可字段与启动参数（2026-10-31）。原仓库使用 Apache-2.0；本项目未修改或分发这些智能体的实现。目录许可字段来自其登记资料，不替代对应项目当前许可证。

React、React Native、Expo、Lucide、react-native-svg 和 qrcode 等依赖在各自许可下使用。RustDesk 仅以 URL scheme 调用已安装的客户端，未捆绑或修改其二进制。Codex、Claude、Copilot、Cursor 等名称归各自权利人所有，接入信息不表示获得其背书。

App 免费开源不代表第三方模型调用、智能体订阅或 Apple 开发者服务均免费。没有在本工程中嵌入第三方 API key、账户或签名凭据。

可选服务器安装脚本从 Caddy 官方发布页下载并校验 Caddy 2.11.7，许可为 Apache-2.0；许可及依赖说明见其官方发布包和源码仓库。Windows 端调用系统 OpenSSH 客户端，不捆绑 OpenSSH 二进制。SSH、Caddy 与操作系统软件包按各自许可证使用。


Windows 安装包原样捆绑 VB-Audio Software 的 VB-CABLE Driver Pack 45。VB-CABLE 为 donationware，产品、支持及捐助信息：https://vb-audio.com/Cable/ 。许可与商业部署说明：https://vb-audio.com/Services/licensing.htm 。保留原始 ZIP 内的许可和文件，本项目 MIT 许可不替代此组件许可。

手柄组件采用 ViGEmBus 1.22.0 及 ViGEmClient，随包保留各自 BSD-3-Clause / MIT 许可，来源 https://github.com/nefarius/ViGEmBus 和 https://github.com/nefarius/ViGEmClient 。
