import ExpoModulesCore
import GameController
import UIKit
import AVFAudio
import UniformTypeIdentifiers

public class RemoteInputModule: Module {
  private var enabled = false
  private var observers: [NSObjectProtocol] = []
  private var keyboard: GCKeyboardInput?
  private var mice: [GCMouseInput] = []
  private var filePicker: RemoteFilePicker?
  private var gamepadTimer: Timer?

  public func definition() -> ModuleDefinition {
    Name("AgentRemoteInput")
    Events("onInput")
    AsyncFunction("configureRemotePlayback") { (microphone: Bool) in
      let session = AVAudioSession.sharedInstance()
      if microphone { try session.setCategory(.playAndRecord, mode: .voiceChat, options: [.defaultToSpeaker, .allowBluetooth]) }
      else { try session.setCategory(.playback, mode: .default, options: []) }
      try session.setActive(true)
    }.runOnQueue(.main)
    Function("setOrientationLock") { (side: String?) in
      switch side {
      case "landscape-left": RemoteOrientationLock.mask = .landscapeLeft
      case "landscape-right": RemoteOrientationLock.mask = .landscapeRight
      case "landscape": RemoteOrientationLock.mask = .landscape
      default: RemoteOrientationLock.mask = nil
      }
      for scene in UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }) {
        for window in scene.windows {
          var controller = window.rootViewController
          while let current = controller { current.setNeedsUpdateOfSupportedInterfaceOrientations(); controller = current.presentedViewController }
        }
      }
    }.runOnQueue(.main)
    AsyncFunction("rotateScreen") { (landscape: Bool, promise: Promise) in
      guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first(where: { $0.activationState == .foregroundActive }) else {
        promise.reject("ROTATION_UNAVAILABLE", "当前没有可旋转的窗口"); return
      }
      let orientations: UIInterfaceOrientationMask = landscape ? .landscape : .portrait
      let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController
      func update(_ controller: UIViewController?) {
        guard let controller = controller else { return }
        controller.setNeedsUpdateOfSupportedInterfaceOrientations()
        controller.children.forEach { update($0) }
        update(controller.presentedViewController)
      }
      update(root)
      var finished = false
      scene.requestGeometryUpdate(.iOS(interfaceOrientations: orientations)) { error in
        guard !finished else { return }; finished = true
        promise.reject("ROTATION_FAILED", error.localizedDescription)
      }
      DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
        guard !finished else { return }; finished = true
        if scene.interfaceOrientation.isLandscape == landscape { promise.resolve(nil) }
        else { promise.reject("ROTATION_FAILED", "系统未切换屏幕方向，请检查旋转限制后重试") }
      }
    }.runOnQueue(.main)
    AsyncFunction("pickFile") { (promise: Promise) in
      guard self.filePicker == nil else { promise.reject("PICKER_BUSY", "文件选择器已打开"); return }
      let picker = RemoteFilePicker { result in
        self.filePicker = nil
        switch result {
        case .success(let value): promise.resolve(value)
        case .failure(let error): promise.reject("FILE_PICK_FAILED", error.localizedDescription)
        }
      }
      self.filePicker = picker
      picker.present()
    }.runOnQueue(.main)
    AsyncFunction("getDevices") { () -> [String: Any] in
      return ["keyboard": GCKeyboard.coalesced != nil, "mouseCount": GCMouse.mice().count, "controllerCount": GCController.controllers().count, "gamepadMapping": true]
    }.runOnQueue(.main)
    AsyncFunction("setEnabled") { (value: Bool) in
      self.disable()
      if value {
        self.enabled = true
        self.attach()
        let center = NotificationCenter.default
        for name in [Notification.Name.GCKeyboardDidConnect, .GCKeyboardDidDisconnect, .GCMouseDidConnect, .GCMouseDidDisconnect, .GCControllerDidConnect, .GCControllerDidDisconnect] {
          self.observers.append(center.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
            self?.emit(["type": "releaseAll"])
            self?.detach()
            self?.attach()
          })
        }
        self.observers.append(center.addObserver(forName: UIApplication.willResignActiveNotification, object: nil, queue: .main) { [weak self] _ in self?.disable() })
      }
    }.runOnQueue(.main)
    OnDestroy {
      DispatchQueue.main.async { self.disable() }
    }
  }

  private func emit(_ data: [String: Any]) {
    DispatchQueue.main.async { [weak self] in
      guard let self = self, self.enabled else { return }
      self.sendEvent("onInput", data)
    }
  }
  private func attach() {
    guard enabled else { return }
    gamepadTimer?.invalidate()
    gamepadTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
      guard let self = self, let pad = GCController.controllers().compactMap({ $0.extendedGamepad }).first else { return }
      let buttons: [String: Bool] = ["a": pad.buttonA.isPressed, "b": pad.buttonB.isPressed, "x": pad.buttonX.isPressed, "y": pad.buttonY.isPressed, "lb": pad.leftShoulder.isPressed, "rb": pad.rightShoulder.isPressed, "lt": pad.leftTrigger.isPressed, "rt": pad.rightTrigger.isPressed, "menu": pad.buttonMenu.isPressed, "view": pad.buttonOptions?.isPressed ?? false, "ls": pad.leftThumbstickButton?.isPressed ?? false, "rs": pad.rightThumbstickButton?.isPressed ?? false, "up": pad.dpad.up.isPressed, "down": pad.dpad.down.isPressed, "left": pad.dpad.left.isPressed, "right": pad.dpad.right.isPressed]
      self.emit(["type": "gamepadState", "axes": [pad.leftThumbstick.xAxis.value, pad.leftThumbstick.yAxis.value, pad.rightThumbstick.xAxis.value, pad.rightThumbstick.yAxis.value], "buttons": buttons, "triggers": [pad.leftTrigger.value, pad.rightTrigger.value]])
    }
    keyboard = GCKeyboard.coalesced?.keyboardInput
    keyboard?.keyChangedHandler = { [weak self] _, _, code, pressed in
      self?.emit(["type": pressed ? "keyDown" : "keyUp", "keyCode": code.rawValue])
    }
    for mouse in GCMouse.mice() {
      guard let input = mouse.mouseInput else { continue }
      mice.append(input)
      input.mouseMovedHandler = { [weak self] _, x, y in self?.emit(["type": "mouseMove", "dx": x, "dy": -y]) }
      input.leftButton.pressedChangedHandler = { [weak self] _, _, down in self?.emit(["type": "mouseButton", "button": "left", "down": down]) }
      input.rightButton?.pressedChangedHandler = { [weak self] _, _, down in self?.emit(["type": "mouseButton", "button": "right", "down": down]) }
      input.middleButton?.pressedChangedHandler = { [weak self] _, _, down in self?.emit(["type": "mouseButton", "button": "middle", "down": down]) }
      input.scroll.valueChangedHandler = { [weak self] _, _, y in
        if y != 0 { self?.emit(["type": "scroll", "delta": Int(max(-1200, min(1200, y * 120)))]) }
      }
    }
  }
  private func detach() {
    gamepadTimer?.invalidate()
    gamepadTimer = nil
    keyboard?.keyChangedHandler = nil
    keyboard = nil
    for input in mice {
      input.mouseMovedHandler = nil
      input.leftButton.pressedChangedHandler = nil
      input.rightButton?.pressedChangedHandler = nil
      input.middleButton?.pressedChangedHandler = nil
      input.scroll.valueChangedHandler = nil
    }
    mice.removeAll()
  }
  private func disable() {
    if enabled { sendEvent("onInput", ["type": "releaseAll"]) }
    enabled = false
    detach()
    for observer in observers { NotificationCenter.default.removeObserver(observer) }
    observers.removeAll()
  }
}

private final class RemoteFilePicker: NSObject, UIDocumentPickerDelegate {
  private let finish: (Result<[String: Any]?, Error>) -> Void
  init(finish: @escaping (Result<[String: Any]?, Error>) -> Void) { self.finish = finish }
  func present() {
    guard var host = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).filter({ $0.activationState == .foregroundActive }).flatMap({ $0.windows }).first(where: { $0.isKeyWindow })?.rootViewController else {
      finish(.failure(NSError(domain: "AgentControl", code: 1, userInfo: [NSLocalizedDescriptionKey: "无法打开文件选择器"]))); return
    }
    while let presented = host.presentedViewController { host = presented }
    let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
    picker.delegate = self
    picker.allowsMultipleSelection = false
    host.present(picker, animated: true)
  }
  func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish(.success(nil)) }
  func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
    guard let source = urls.first else { finish(.success(nil)); return }
    let scoped = source.startAccessingSecurityScopedResource()
    defer { if scoped { source.stopAccessingSecurityScopedResource() } }
    do {
      let size = try source.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
      guard size <= 20 * 1024 * 1024 else { throw NSError(domain: "AgentControl", code: 2, userInfo: [NSLocalizedDescriptionKey: "单个文件上传上限为 20 MB"]) }
      let target = FileManager.default.temporaryDirectory.appendingPathComponent("agent-upload-" + UUID().uuidString)
      try FileManager.default.copyItem(at: source, to: target)
      finish(.success(["uri": target.absoluteString, "name": source.lastPathComponent, "size": size]))
    } catch { finish(.failure(error)) }
  }
}
