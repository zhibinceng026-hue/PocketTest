import ExpoModulesCore
import UIKit

// App-level orientation mask. nil means the default for the device.
public final class RemoteOrientationLock: ExpoAppDelegateSubscriber {
  static var mask: UIInterfaceOrientationMask?

  public func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
    if let mask = RemoteOrientationLock.mask { return mask }
    return UIDevice.current.userInterfaceIdiom == .pad ? .all : .allButUpsideDown
  }
}
