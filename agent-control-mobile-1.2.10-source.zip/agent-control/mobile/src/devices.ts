import * as SecureStore from 'expo-secure-store';
import {Platform} from 'react-native';
import type {Profile} from './types';
const index='agent-control.devices.v1';
const memory=new Map<string,string>();
export const readDeviceValue=(key:string)=>Platform.OS==='web'?Promise.resolve(memory.get(key)||null):SecureStore.getItemAsync(key);
export const writeDeviceValue=(key:string,value:string)=>Platform.OS==='web'?(memory.set(key,value),Promise.resolve()):SecureStore.setItemAsync(key,value);
export const deviceKey=(url:string)=>'agent-control.device.'+Array.from(url).map(c=>c.charCodeAt(0).toString(16).padStart(4,'0')).join('');
export async function listDevices():Promise<Profile[]>{const keys=JSON.parse(await readDeviceValue(index)||'[]');const rows=await Promise.all(keys.map((k:string)=>readDeviceValue(k)));return rows.flatMap((raw:string|null)=>{try{return raw?[JSON.parse(raw)]:[];}catch{return [];}});}
export async function saveDevice(profile:Profile){const key=deviceKey(profile.url),keys:string[]=JSON.parse(await readDeviceValue(index)||'[]');await writeDeviceValue(key,JSON.stringify(profile));if(!keys.includes(key))await writeDeviceValue(index,JSON.stringify([...keys,key]));}
export async function forgetDevice(url:string){const key=deviceKey(url),keys:string[]=JSON.parse(await readDeviceValue(index)||'[]');await writeDeviceValue(index,JSON.stringify(keys.filter(k=>k!==key)));if(Platform.OS==='web'){memory.delete(key);memory.delete(key+'.view');}else{await SecureStore.deleteItemAsync(key);await SecureStore.deleteItemAsync(key+'.view');}}
