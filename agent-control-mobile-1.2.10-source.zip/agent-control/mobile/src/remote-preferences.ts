import {deviceKey,readDeviceValue,writeDeviceValue} from './devices';
export type QualityMode='auto'|'high'|'ultra'|'original'|'custom';
export type RemotePreferences={quality:'smooth'|'balanced'|'hd';qualityMode:QualityMode;bitrate?:number;frameRate:number;colorMode:'normal'|'trueColor';tabletTouch:boolean;lockOnEnd:boolean;microphone:boolean;gamepad:boolean;nativeGamepad:boolean;selectedDisplay:string;pointerMode:boolean;virtualMouse:boolean;showMouseButtons:boolean;smartMouse:boolean;avoidCutouts:boolean;showDataUsage:boolean;autoHideMs:number;fullScreen:boolean;control:boolean;pipEnabled:boolean;audio:boolean;localMute:boolean;hardwareMapping:boolean;peripheralRedirect:boolean;keyPreset:'standard'|'mac'|'escape'};
export const defaultRemotePreferences:RemotePreferences={quality:'balanced',qualityMode:'auto',bitrate:undefined,frameRate:30,colorMode:'normal',tabletTouch:false,lockOnEnd:false,microphone:false,gamepad:true,nativeGamepad:false,selectedDisplay:'',pointerMode:false,virtualMouse:false,showMouseButtons:false,smartMouse:false,avoidCutouts:false,showDataUsage:true,autoHideMs:3500,fullScreen:false,control:true,pipEnabled:true,audio:true,localMute:true,hardwareMapping:true,peripheralRedirect:true,keyPreset:'mac'};
const cache=new Map<string,RemotePreferences>(),writes=new Map<string,Promise<void>>();
export function normalizeRemotePreferences(value:unknown):RemotePreferences{
 const input=value&&typeof value==='object'?value as Record<string,any>:{};
 const result={...defaultRemotePreferences};
 for(const key of ['tabletTouch','lockOnEnd','microphone','gamepad','nativeGamepad','pointerMode','virtualMouse','showMouseButtons','smartMouse','avoidCutouts','showDataUsage','fullScreen','control','pipEnabled','audio','localMute','hardwareMapping','peripheralRedirect'] as const)if(typeof input[key]==='boolean')result[key]=input[key];
 if(['smooth','balanced','hd'].includes(input.quality))result.quality=input.quality;
 if(['auto','high','ultra','original','custom'].includes(input.qualityMode))result.qualityMode=input.qualityMode;
 if([30,60,90,144].includes(input.frameRate))result.frameRate=input.frameRate;
 if(input.colorMode==='normal'||input.colorMode==='trueColor')result.colorMode=input.colorMode;
 if(Number.isInteger(input.bitrate)&&input.bitrate>=500000&&input.bitrate<=500000000)result.bitrate=input.bitrate;
 if(result.qualityMode==='auto')result.bitrate=undefined;
 if([0,3000,3500,5000].includes(input.autoHideMs))result.autoHideMs=input.autoHideMs;
 if(['standard','mac','escape'].includes(input.keyPreset))result.keyPreset=input.keyPreset;
 if(typeof input.selectedDisplay==='string'&&input.selectedDisplay.length<=256)result.selectedDisplay=input.selectedDisplay;
 if(result.nativeGamepad)result.gamepad=false;
 if(result.colorMode==='trueColor'){result.audio=false;result.localMute=false;}
 if(result.localMute)result.audio=true;
 return result;
}
export async function loadRemotePreferences(url:string){
 const key=deviceKey(url)+'.remote';const existing=cache.get(key);if(existing)return normalizeRemotePreferences(existing);
 let saved:unknown;try{const raw=await readDeviceValue(key);if(raw)saved=JSON.parse(raw);}catch{}
 if(saved&&typeof saved==='object'&&(saved as any).schema!==2){const previous=saved as any;if(previous.qualityMode==='original'&&previous.bitrate===30000000){previous.quality='balanced';previous.qualityMode='auto';delete previous.bitrate;}previous.colorMode='normal';}
 const value=cache.get(key)||normalizeRemotePreferences(saved);cache.set(key,value);return normalizeRemotePreferences(value);
}
export function saveRemotePreferences(url:string,value:RemotePreferences){
 const key=deviceKey(url)+'.remote',clean=normalizeRemotePreferences(value);cache.set(key,clean);
 const next=(writes.get(key)||Promise.resolve()).catch(()=>{}).then(()=>writeDeviceValue(key,JSON.stringify({...clean,schema:2})));
 writes.set(key,next);void next.then(()=>{if(writes.get(key)===next)writes.delete(key);},()=>{});return next;
}
