// Precision at low speed, bounded acceleration at high speed. Inputs are pixel
// deltas and elapsed milliseconds; no application detection is implied.
export function smartMouseDelta(dx:number,dy:number,elapsedMs:number,enabled:boolean){
 if(!Number.isFinite(dx)||!Number.isFinite(dy))return {dx:0,dy:0};
 if(!enabled)return {dx,dy};
 const elapsed=Number.isFinite(elapsedMs)?Math.max(8,Math.min(100,elapsedMs)):16;
 const speed=Math.hypot(dx,dy)/elapsed;
 const gain=Math.max(.35,Math.min(1.8,.35+speed*.7));
 return {dx:dx*gain,dy:dy*gain};
}
