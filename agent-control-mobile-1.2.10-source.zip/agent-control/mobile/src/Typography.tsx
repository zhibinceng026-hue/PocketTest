import React from 'react';
import {Platform,Text as NativeText,type TextProps} from 'react-native';
// Use native system typography on the phone and an explicit sans-serif stack
// in Windows previews, rather than the ambiguous CSS family "System".
export function Text(props:TextProps){return <NativeText {...props} style={[{fontFamily:Platform.OS==='web'?'"Segoe UI", "Microsoft YaHei UI", "Microsoft YaHei", sans-serif':'System'},props.style]}/>;}
