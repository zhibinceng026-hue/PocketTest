import React,{useRef,useState} from 'react';
import {View} from 'react-native';
import {colors as c} from './theme';
export function BitrateSlider({value,onChange}:{value:number;onChange:(value:number)=>void}){
 const [width,setWidth]=useState(1),[draft,setDraft]=useState<number|null>(null);const origin=useRef(0),latest=useRef(value);
 const commit=()=>{onChange(latest.current);setDraft(null);};
 const update=(pageX:number)=>{const next=Math.round((.5+Math.max(0,Math.min(1,(pageX-origin.current)/width))*499.5)*1000000);latest.current=next;setDraft(next);};
 const ratio=((draft??value)/1000000-.5)/499.5;
 return <View accessibilityRole="adjustable" accessibilityLabel="自定义码率" accessibilityValue={{min:.5,max:500,now:(draft??value)/1000000,text:((draft??value)/1000000).toFixed(1)+' Mbps'}} accessibilityActions={[{name:'increment'},{name:'decrement'}]} onAccessibilityAction={event=>onChange(Math.max(500000,Math.min(500000000,value+(event.nativeEvent.actionName==='increment'?5000000:-5000000))))} onLayout={event=>setWidth(Math.max(1,event.nativeEvent.layout.width))} onStartShouldSetResponder={()=>true} onMoveShouldSetResponder={()=>true} onResponderGrant={event=>{origin.current=event.nativeEvent.pageX-event.nativeEvent.locationX;update(event.nativeEvent.pageX);}} onResponderMove={event=>update(event.nativeEvent.pageX)} onResponderRelease={commit} onResponderTerminate={()=>setDraft(null)} style={{height:40,justifyContent:'center',marginHorizontal:12}}>
  <View pointerEvents="none" style={{height:6,borderRadius:3,backgroundColor:c.line}}><View style={{height:6,width:Math.max(0,Math.min(width,ratio*width)),borderRadius:3,backgroundColor:c.green}}/></View>
  <View pointerEvents="none" style={{position:'absolute',left:Math.max(0,Math.min(width-24,ratio*(width-24))),width:24,height:24,borderRadius:12,backgroundColor:'#FFFFFF',borderWidth:2,borderColor:c.green}}/>
 </View>;
}
