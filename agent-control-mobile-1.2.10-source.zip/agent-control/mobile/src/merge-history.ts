import type {Turn} from './types';
export function mergeTurnHistory(previous:Turn[],incoming:Turn[]):Turn[]{
  const updates=new Map(incoming.map(turn=>[turn.id,turn]));
  const result=previous.map(old=>{
    const stored=updates.get(old.id);if(!stored)return old;updates.delete(old.id);
    if(old.status==='completed'&&stored.status==='inProgress')return old;
    if(stored.status!=='inProgress'){const words=(item:any)=>(item.content?.filter((part:any)=>part.type==='text').map((part:any)=>part.text||'').join('\n')||item.text||'').trim();const kept=old.items.filter(item=>item.type==='userMessage'&&!stored.items.some(next=>next.id===item.id||(next.type==='userMessage'&&words(next)===words(item))));return kept.length?{...stored,items:[...kept,...stored.items]}:stored;}
    const items=old.items.map(item=>{const next=stored.items.find(x=>x.id===item.id);if(!next)return item;return {...item,...next,...((item.text||'').length>(next.text||'').length?{text:item.text}:{}),...((item.aggregatedOutput||'').length>(next.aggregatedOutput||'').length?{aggregatedOutput:item.aggregatedOutput}:{})};});
    for(const item of stored.items)if(!items.some(x=>x.id===item.id))items.push(item);
    return {...old,...stored,items};
  });
  return [...result,...updates.values()];
}
