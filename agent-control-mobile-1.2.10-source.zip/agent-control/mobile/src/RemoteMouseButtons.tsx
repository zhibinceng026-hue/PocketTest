import React,{useEffect,useRef} from 'react';
import {Pressable,View} from 'react-native';
import {Mouse,ChevronUp,ChevronDown,Dot} from 'lucide-react-native';
import {colors as c} from './theme';

export function RemoteMouseButtons({input,point,scale,rightInset=0}:{input:(value:any)=>Promise<unknown>;point:()=>{x:number;y:number};scale:number;rightInset?:number}){
 const held=useRef(new Set<string>()),drag=useRef({y:0,at:0});
 const latest=useRef({input,point});latest.current={input,point};
 useEffect(()=>{const timer=setInterval(()=>{if(held.current.size)void latest.current.input({type:'inputHeartbeat'}).catch(()=>{});},1000);return()=>{clearInterval(timer);if(held.current.size)void latest.current.input({type:'releaseAll'}).catch(()=>{});};},[]);
 function button(name:string,down:boolean){down?held.current.add(name):held.current.delete(name);void input({type:'mouseButton',button:name,down,...point()}).catch(()=>{});}
 function wheel(delta:number){void input({type:'scroll',delta}).catch(()=>{});}
 const size=52*scale;
 return <View pointerEvents="box-none" style={{position:'absolute',top:0,left:0,right:0,bottom:0}}>
   {(['left','right'] as const).map((name,i)=><Pressable key={name} accessibilityRole="button" accessibilityLabel={i?'独立鼠标右键':'独立鼠标左键'} onPress={()=>{}} onPressIn={()=>button(name,true)} onPressOut={()=>button(name,false)} style={{position:'absolute',left:'50%',marginLeft:(i?38:-90)*scale,bottom:22*scale,width:size,height:size,borderRadius:size/2,backgroundColor:'#12182088',alignItems:'center',justifyContent:'center'}}><View><Mouse size={31*scale} color={c.text} fill={c.raised} strokeWidth={1.4}/><View style={{position:'absolute',top:4*scale,left:(i?17:8)*scale,width:6*scale,height:8*scale,borderRadius:2,backgroundColor:c.green}}/></View></Pressable>)}
   <View accessibilityLabel="鼠标滚轮滑动条" onStartShouldSetResponder={()=>true} onResponderGrant={e=>{drag.current={y:e.nativeEvent.pageY,at:Date.now()};}} onResponderMove={e=>{const dy=e.nativeEvent.pageY-drag.current.y,now=Date.now();if(Math.abs(dy)>7&&now-drag.current.at>45){wheel(dy>0?-120:120);drag.current={y:e.nativeEvent.pageY,at:now};}}} onResponderTerminationRequest={()=>false} style={{position:'absolute',right:rightInset+18*scale,top:'32%',height:156*scale,width:28*scale,borderRadius:15*scale,backgroundColor:'#12182088',alignItems:'center',justifyContent:'center'}}>
    <View style={{backgroundColor:c.raised,borderColor:c.line,borderWidth:1,borderRadius:12*scale}}>
     <Pressable accessibilityRole="button" accessibilityLabel="滚轮向上" onPress={()=>wheel(120)} style={{padding:4*scale}}><ChevronUp size={18*scale} color={c.green}/></Pressable>
     <Pressable accessibilityRole="button" accessibilityLabel="鼠标中键" onPress={()=>{}} onPressIn={()=>button('middle',true)} onPressOut={()=>button('middle',false)} style={{padding:4*scale}}><Dot size={18*scale} color={c.green}/></Pressable>
     <Pressable accessibilityRole="button" accessibilityLabel="滚轮向下" onPress={()=>wheel(-120)} style={{padding:4*scale}}><ChevronDown size={18*scale} color={c.green}/></Pressable>
    </View>
   </View>
 </View>;
}
