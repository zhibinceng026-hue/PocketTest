import type {DraftImage,Turn} from './types';

export type LocalEcho={id:string;key:string;text:string;images:DraftImage[];knownItems:string[];accepted:boolean};
// Only new user items can acknowledge a send; identical historical messages cannot.
export function unconfirmedEchoes(echoes:LocalEcho[],turns:Turn[],key:string):LocalEcho[]{
  const used=new Set<string>();
  const items=turns.flatMap(turn=>turn.items).filter(item=>item.type==='userMessage');
  return echoes.filter(echo=>{
    if(echo.key!==key)return true;
    const match=items.find(item=>!used.has(item.id)&&!echo.knownItems.includes(item.id)&&
      (item.content?.filter(part=>part.type==='text').map(part=>part.text||'').join('\n')||item.text||'').trim()===echo.text.trim()&&
      (item.content?.filter(part=>['image','localImage'].includes(part.type)).length||0)===echo.images.length);
    if(!match)return true;
    used.add(match.id);return false;
  });
}
