import {Platform} from 'react-native';
import {requireOptionalNativeModule} from 'expo';
import * as FileSystem from 'expo-file-system/legacy';
import {validateBase} from './api';
import type {Profile} from './types';
type Picked={uri:string;name:string;size:number};
const native=Platform.OS==='ios'?requireOptionalNativeModule<{pickFile?:()=>Promise<Picked|null>}>('AgentRemoteInput'):null;
export async function uploadWorkspaceFile(profile:Profile,directory:string):Promise<boolean>{
 let picked:Picked|null=null,webFile:File|undefined;
 if(Platform.OS==='web'){
  webFile=await new Promise<File|undefined>(resolve=>{const input=document.createElement('input');input.type='file';input.onchange=()=>resolve(input.files?.[0]);input.addEventListener('cancel',()=>resolve(undefined),{once:true});input.click();});
  if(!webFile)return false;
  picked={uri:'',name:webFile.name,size:webFile.size};
 }else{
  if(!native?.pickFile)throw new Error('此安装版本尚未包含文件选择功能。');
  picked=await native.pickFile();if(!picked)return false;
 }
 try{
  if(picked.size>20*1024*1024)throw new Error('单个文件上传上限为 20 MB。');
  const url=validateBase(profile.url)+'/api/files/upload?path='+encodeURIComponent(directory)+'&name='+encodeURIComponent(picked.name);
  let status:number,response:string;
  if(webFile){const result=await fetch(url,{method:'POST',headers:{Authorization:'Bearer '+profile.token,'Content-Type':'application/octet-stream'},body:webFile});status=result.status;response=await result.text();}
  else {const result=await FileSystem.uploadAsync(url,picked.uri,{httpMethod:'POST',uploadType:FileSystem.FileSystemUploadType.BINARY_CONTENT,headers:{Authorization:'Bearer '+profile.token,'Content-Type':'application/octet-stream'}});status=result.status;response=result.body;}
  if(status!==201){let message=`上传失败 (${status})`;try{message=JSON.parse(response).error||message;}catch{}throw new Error(message);}
  return true;
 }finally{if(Platform.OS!=='web'&&picked.uri)await FileSystem.deleteAsync(picked.uri,{idempotent:true}).catch(()=>{});}
}
