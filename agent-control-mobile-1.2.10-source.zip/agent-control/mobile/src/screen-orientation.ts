import {Platform} from 'react-native';
import {requireOptionalNativeModule} from 'expo';
const native=Platform.OS==='ios'?requireOptionalNativeModule<{rotateScreen?:(landscape:boolean)=>Promise<void>;setOrientationLock?:(side:string|null)=>Promise<void>}>('AgentRemoteInput'):null;
// App-wide lock (build 45+). Older native builds ignore it and keep the modal-only lock.
export function setOrientationLock(side:'landscape-left'|'landscape-right'|'landscape'|null){try{void native?.setOrientationLock?.(side)?.catch(()=>{});}catch{}}
export async function rotateRemoteScreen(landscape:boolean):Promise<void>{
 if(Platform.OS==='ios'){
  if(!native?.rotateScreen)throw new Error('当前安装版本尚未包含屏幕旋转接口。');
  await native.rotateScreen(landscape);return;
 }
 if(Platform.OS==='web'){
  const orientation=screen.orientation as ScreenOrientation&{lock?:(value:string)=>Promise<void>};
  if(!orientation?.lock)throw new Error('当前浏览器不支持程序切换方向，请旋转设备。');
  await orientation.lock(landscape?'landscape':'portrait');return;
 }
 throw new Error('当前平台尚未接入屏幕旋转。');
}
