import React from 'react';
import {Pressable,View} from 'react-native';
import {ArrowDown} from 'lucide-react-native';
import {colors as c} from './theme';
export function ChatQuickActions({showBottom,onBottom}:{showBottom:boolean;onBottom:()=>void}){
 if(!showBottom)return null;
 return <View pointerEvents="box-none" style={{position:'absolute',left:0,right:0,top:-42,alignItems:'center'}}><Pressable accessibilityRole="button" accessibilityLabel="回到最新消息" onPress={onBottom} style={{width:32,height:32,borderRadius:16,borderWidth:1,borderColor:c.line,backgroundColor:c.surface,alignItems:'center',justifyContent:'center'}}><ArrowDown size={19} color={c.text}/></Pressable></View>;
}
