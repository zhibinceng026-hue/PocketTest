export const {RTCPeerConnection,RTCRtpReceiver,mediaDevices}=require('react-native-webrtc');
