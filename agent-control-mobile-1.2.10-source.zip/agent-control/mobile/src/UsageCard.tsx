import {Text} from './Typography';
import React from 'react';
import {Pressable,StyleSheet,View} from 'react-native';
import {RefreshCw} from 'lucide-react-native';
import {colors as c} from './theme';
export type UsageWindow={kind:string;usedPercent:number|null;remainingPercent:number|null;windowDurationMins:number|null;resetsAt:number|null};
export type UsageSnapshot={supported:boolean;agentId:string;updatedAt?:number;stale?:boolean;message?:string;balances?:{currency:string;total:string;granted?:string;toppedUp?:string}[];buckets?:{id:string;name:string;planType:string|null;windows:UsageWindow[]}[]};
const label=(minutes:number|null)=>minutes===null?'额度':minutes===10080?'每周':minutes>=1440?`${minutes/1440} 天`:minutes>=60?`${minutes/60} 小时`:`${minutes} 分钟`;
const percentage=(value:number|null)=>value===null?'暂无数据':`${Math.round(value)}%`;
export function UsageCard({usage,connected,onRefresh,compact=false}:{usage:UsageSnapshot|null;connected:boolean;onRefresh:()=>void;compact?:boolean}){
  const stale=!connected||usage?.stale;
  return <View style={[s.card,compact&&s.compact]}>
    <View style={s.heading}><View style={{flex:1,gap:4}}><Text style={s.title}>实时额度</Text><Text style={s.caption}>{usage?.updatedAt?`${stale?'上次数据 · ':''}${new Date(usage.updatedAt).toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'})} 更新 · 账号共享额度`:usage?usage.supported?'账户数据已读取':'此账户暂不可查询':connected?'正在读取真实账号用量':'连接电脑后读取真实账号用量'}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="刷新实时额度" onPress={onRefresh} disabled={!connected} style={s.refresh}><RefreshCw size={17} color={connected?c.green:c.muted}/></Pressable></View>
    {usage?.buckets?.map(bucket=><View key={bucket.id} style={{gap:12}}>{(usage.buckets!.length>1||!compact)&&<Text style={s.caption}>{bucket.name}{bucket.planType?' · '+bucket.planType.toUpperCase():''}</Text>}<View style={s.windows}>{bucket.windows.map(window=>{const color=window.remainingPercent===null?c.muted:window.remainingPercent<=5?c.red:window.remainingPercent<=20?c.amber:c.green;return <View key={window.kind} style={s.window}><View style={s.line}><Text style={s.label}>{label(window.windowDurationMins)}</Text><Text style={[s.remaining,{color:stale?c.muted:color}]}>剩余 {percentage(window.remainingPercent)}</Text></View><View style={s.track}>{window.usedPercent!==null&&<View style={{height:4,width:`${window.usedPercent}%`,backgroundColor:stale?c.muted:color,borderRadius:4}}/>}</View><Text style={s.caption}>已用 {percentage(window.usedPercent)}</Text>{!compact&&<Text style={s.caption}>{window.resetsAt?new Date(window.resetsAt*1000).toLocaleString('zh-CN',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})+' 重置':'重置时间暂不可用'}</Text>}</View>;})}</View></View>)}
    {usage?.balances?.map(b=><View key={b.currency} style={{gap:8}}><Text style={s.remaining}>可用余额 {b.total} {b.currency}</Text><Text style={s.caption}>赠送 {b.granted||'0'} · 充值 {b.toppedUp||'0'}</Text></View>)}
    {usage?.message&&<Text style={s.caption}>{usage.message}</Text>}
  </View>;
}
const s=StyleSheet.create({card:{marginVertical:16,padding:17,gap:14,borderRadius:20,borderWidth:1,borderColor:'#2B3B37',backgroundColor:'#101D19'},compact:{marginTop:0,marginBottom:18,padding:13,gap:10},heading:{flexDirection:'row',alignItems:'center',gap:10},title:{color:c.text,fontSize:13,fontWeight:'600'},caption:{color:c.muted,fontSize:10,lineHeight:16},refresh:{width:44,height:44,alignItems:'center',justifyContent:'center',borderRadius:12,backgroundColor:'#1C2D24'},windows:{flexDirection:'row',gap:16},window:{flex:1,gap:6},line:{gap:5},label:{color:'#B8C8BF',fontSize:11},remaining:{fontSize:16,fontWeight:'700'},track:{height:4,borderRadius:4,backgroundColor:'#2B3933',overflow:'hidden'}});
