// Reorder only codecs actually advertised by this receiver. Never invent SDP
// support; the remote sender still has to negotiate a mutually supported codec.
export function preferVideoCodecs<T extends {mimeType:string}>(codecs:T[]):T[]{
 const order=['video/h265','video/hevc','video/h264','video/av1','video/vp9','video/vp8'];
 const rank=(codec:T)=>{const index=order.indexOf(codec.mimeType.toLowerCase());return index<0?order.length:index;};
 return codecs.map((codec,index)=>({codec,index})).sort((a,b)=>rank(a.codec)-rank(b.codec)||a.index-b.index).map(row=>row.codec);
}
