// Convert chat artifact links to authorized workspace-relative paths.
export function workspaceFilePath(target:string,workspace:string,cwd?:string):string{
  let value=target.trim().replace(/^<|>$/g,'').replace(/:\d+(?::\d+)?$/,'');
  try{value=decodeURIComponent(value);}catch{throw new Error('文件链接格式无效。');}
  value=value.replaceAll('\\','/');
  const root=workspace.replaceAll('\\','/').replace(/\/$/,'');
  if(/^https?:\/\//i.test(value)||/^[a-z]+:\/\//i.test(value))throw new Error('这不是电脑工作区内的文件链接。');
  if(/^[a-z]:\//i.test(value)||value.startsWith('/')){
    if(!value.toLowerCase().startsWith(root.toLowerCase()+'/'))throw new Error('此文件不在已授权工作区内，请在电脑端调整工作目录后再查看。');
    value=value.slice(root.length+1);
  }else if(cwd){
    const base=cwd.replaceAll('\\','/').replace(/\/$/,'');
    if(base.toLowerCase()===root.toLowerCase()){}else if(base.toLowerCase().startsWith(root.toLowerCase()+'/'))value=base.slice(root.length+1)+'/'+value;
    else throw new Error('此会话的目录不在已授权工作区内。');
  }
  const parts:string[]=[];
  for(const part of value.split('/')){if(!part||part==='.')continue;if(part==='..'){if(!parts.length)throw new Error('文件超出已授权工作区。');parts.pop();}else parts.push(part);}
  if(!parts.length||parts.some(p=>/[\x00-\x1f:]/.test(p)))throw new Error('文件链接格式无效。');
  return parts.join('/');
}

export function markdownFileLinks(text:string):{label:string;target:string}[]{
  const links:{label:string;target:string}[]=[];
  const pattern=/\[([^\]\n]+)\]\(\s*(<[^>\n]+>|[^)\n]+)\s*\)/g;let match;
  while((match=pattern.exec(text))){const target=(match[2]||'').trim().replace(/^<|>$/g,'');if(/^(?:https?:|mailto:|data:|javascript:|plugin:|app:|#)/i.test(target))continue;if(!links.some(l=>l.target===target))links.push({label:match[1]||target,target});}
  return links;
}
