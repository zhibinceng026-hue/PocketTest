import {request} from './api';
import {connectDesktopPeer} from './desktop-peer';
import type {Profile} from './types';

// Keeps one paused P2P connection ready, so entering the remote desktop only has to resume video.
const KEEP_MS=60*1000;
type Sinks={stream:(s:any)=>void;ready:(v:boolean)=>void;stats:(s:any)=>void;failure:(e?:Error)=>void};
type Warm={key:string;profile:Profile;sessionId:string;frame:any;peer:any;stream:any;ready:boolean;sinks:Sinks|null;timer?:ReturnType<typeof setTimeout>};
const idle:Sinks={stream(){},ready(){},stats(){},failure(){}};
let warm:Warm|null=null,starting:Promise<void>|null=null;

function release(item:Warm,endSession:boolean){if(warm===item)warm=null;clearTimeout(item.timer);item.sinks=null;try{item.peer?.close(endSession);}catch{}if(endSession&&active?.sessionId!==item.sessionId)void request(item.profile,'/api/desktop/session',{method:'DELETE',body:{sessionId:item.sessionId},timeoutMs:5000}).catch(()=>{});}
const expire=(item:Warm)=>{clearTimeout(item.timer);item.timer=setTimeout(()=>release(item,true),KEEP_MS);};
const pause=(item:Warm,paused:boolean)=>request(item.profile,'/api/desktop/rtc/pause',{method:'POST',body:{sessionId:item.sessionId,paused},timeoutMs:5000});

function open(item:Warm,args:any[]){
 const [profile,sessionId,quality,signal,,,,...rest]=args;
 return connectDesktopPeer(profile,sessionId,quality,signal,
  s=>{item.stream=s;(item.sinks||idle).stream(s);},
  v=>{item.ready=v;if(!v&&warm===item){release(item,false);}(item.sinks||idle).ready(v);},
  s=>(item.sinks||idle).stats(s),
  rest[0],rest[1],rest[2],e=>{if(warm===item)release(item,false);(item.sinks||idle).failure(e);},...rest.slice(4)).then(peer=>{item.peer=peer;return peer;});
}

// The session a warm connection already holds; entering then needs no new session or screenshot.
export async function warmSessionWhenReady(key:string):Promise<any>{if(starting)await starting;return warmSession(key);}
export function warmSession(key:string):any{return warm&&warm.key===key&&warm.ready&&warm.peer?.connected?{sessionId:warm.sessionId,...warm.frame}:null;}

// Same arguments as connectDesktopPeer. Reuses the warm connection for this session when there is one.
export async function connectOrAdopt(profile:Profile,sessionId:string,quality:string,signal:AbortSignal,onStream:(s:any)=>void,onReady:(v:boolean)=>void,onStats:(s:any)=>void,...rest:any[]){
 const sinks:Sinks={stream:onStream,ready:onReady,stats:onStats,failure:rest[3]||idle.failure};
 const item=warm;
 if(item&&item.sessionId===sessionId&&item.ready&&item.peer?.connected){
  clearTimeout(item.timer);item.sinks=sinks;warm=null;active=item;
  await pause(item,false).catch(()=>{});
  onStream(item.stream);onReady(true);
  return item.peer;
 }
 const fresh:Warm={key:'',profile,sessionId,frame:null,peer:null,stream:null,ready:false,sinks};active=fresh;
 return open(fresh,[profile,sessionId,quality,signal,onStream,onReady,onStats,...rest]);
}
let active:Warm|null=null;

// Leaving the remote desktop: stop sending video but keep the connection for a quick return.
export function parkActive(key:string,frame:any,peer:any){const item=active;if(!item||item.peer!==peer||!item.ready||!peer?.connected)return false;active=null;if(warm)release(warm,true);item.key=key;item.frame=frame;item.sinks=null;warm=item;void peer.send({type:'releaseAll'}).catch(()=>{});void pause(item,true).catch(()=>release(item,true));expire(item);return true;}

// Opening the app: prepare a paused connection in advance. Failure is silent; entering works as usual.
export function preconnect(profile:Profile,key:string,clientId:string){if(warm||active?.peer?.connected||starting)return;starting=runPreconnect(profile,key,clientId).finally(()=>{starting=null;});}
async function runPreconnect(profile:Profile,key:string,clientId:string){
 let item:Warm|null=null;const abort=new AbortController();
 try{
  const value=await request<any>(profile,'/api/desktop/session',{method:'POST',body:{confirm:'VIEW',clientId,preconnect:true},timeoutMs:10000});
  const {sessionId,...frame}=value;item={key,profile,sessionId,frame,peer:null,stream:null,ready:false,sinks:null};const current=item;
  const ready=new Promise<void>((resolve,reject)=>{current.sinks={...idle,ready:v=>v?resolve():reject(new Error('closed'))};setTimeout(()=>reject(new Error('timeout')),15000);});
  await open(current,[profile,sessionId,'balanced',abort.signal,null,null,null,false,30,'all',undefined,undefined,false,false,false]);
  warm=current;await ready;current.sinks=null;await pause(current,true);expire(current);
 }catch{if(item)release(item,true);}
}
