import React,{forwardRef,useImperativeHandle,useRef,useEffect} from 'react';
import {configureRemotePlayback} from './hardware-input';
import type {PipEvent,RemoteVideoHandle} from './pip-lifecycle';
const {RTCView,startIOSPIP,stopIOSPIP}=require('react-native-webrtc');
export const RemoteVideo=forwardRef<RemoteVideoHandle,{stream:any;autoPip?:boolean;audio?:boolean;microphone?:boolean;nativePeerId?:number;onPip?:(event:PipEvent)=>void;onSize?:(width:number,height:number)=>void}>(function RemoteVideo({stream,autoPip=true,audio=false,microphone=false,nativePeerId,onPip,onSize},ref){
 useEffect(()=>{void configureRemotePlayback(microphone).catch(error=>console.warn('Remote playback:',error));},[stream,microphone]);
 const view=useRef<any>(null),ready=useRef(false),pending=useRef<{resolve:()=>void;reject:(error:Error)=>void;timer:ReturnType<typeof setTimeout>}|null>(null);
 useEffect(()=>{ready.current=false;return()=>{const job=pending.current;pending.current=null;if(job){clearTimeout(job.timer);job.reject(new Error('视频连接已变化，请重新打开画中画。'));}};},[stream,nativePeerId]);
 function event(value:PipEvent){
  const job=pending.current;
  if(job&&['didStart','failedToStart','didStop'].includes(value.state)){
   pending.current=null;clearTimeout(job.timer);
   if(value.state==='didStart')job.resolve();else job.reject(new Error(value.error?.message||'系统未能启动画中画。'));
  }
  onPip?.(value);
 }
 useImperativeHandle(ref,()=>({async stopPip(){if(view.current)stopIOSPIP(view);},async startPip(){
  if(!view.current||!ready.current||!Number.isSafeInteger(nativePeerId))throw new Error('视频画面尚未就绪，请稍后重试。');
  if(pending.current)throw new Error('画中画正在启动。');
  await configureRemotePlayback(microphone);
  await new Promise<void>((resolve,reject)=>{
   const timer=setTimeout(()=>{pending.current=null;reject(new Error('系统未启动画中画，请检查系统画中画设置后重试。'));},4500);
   pending.current={resolve,reject,timer};
   try{startIOSPIP(view);}catch(error){clearTimeout(timer);pending.current=null;reject(error);}
  });
 }}),[nativePeerId,microphone]);
 return <RTCView key={nativePeerId??'connecting'} ref={view} streamURL={stream.toURL()} objectFit="contain" onPipStateChange={(value:any)=>event(value.nativeEvent)} onDimensionsChange={(value:any)=>{ready.current=value.nativeEvent.width>0&&value.nativeEvent.height>0;onSize?.(value.nativeEvent.width,value.nativeEvent.height);}} style={{width:'100%',height:'100%'}}/>;
});
