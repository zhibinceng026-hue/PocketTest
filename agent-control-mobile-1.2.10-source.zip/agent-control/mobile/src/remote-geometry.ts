export type RemoteRect={left:number;top:number;width:number;height:number};
export function remoteRect(box:{width:number;height:number},frame:{width:number;height:number},bottom=false):RemoteRect{
 const fit=Math.min(box.width/frame.width,box.height/frame.height);
 const width=frame.width*fit,height=frame.height*fit;
 return {left:(box.width-width)/2,top:bottom?box.height-height:(box.height-height)/2,width,height};
}
export function remotePoint(x:number,y:number,rect:RemoteRect,view:{zoom:number;x:number;y:number}){
 if(!(rect.width>0&&rect.height>0&&view.zoom>0))return null;
 const cx=rect.left+rect.width/2,cy=rect.top+rect.height/2;
 const px=((x-cx-view.x)/view.zoom+cx-rect.left)/rect.width;
 const py=((y-cy-view.y)/view.zoom+cy-rect.top)/rect.height;
 return px>=0&&px<=1&&py>=0&&py<=1?{x:px,y:py}:null;
}
export function surfacePoint(touch:any,origin:{x:number;y:number;ready:boolean}){
 if(origin.ready&&Number.isFinite(touch.pageX)&&Number.isFinite(touch.pageY))return {x:touch.pageX-origin.x,y:touch.pageY-origin.y};
 return {x:touch.locationX,y:touch.locationY};
}
