import {loadRemotePreferences,saveRemotePreferences,type RemotePreferences,type QualityMode} from './remote-preferences';
import type {KeyPreset} from './key-mapping';
import {RemoteVirtualMouse} from './RemoteVirtualMouse';
import {TouchContacts,type TouchContact} from './touch-contacts';
import {RemoteMouseButtons} from './RemoteMouseButtons';
import {rotateRemoteScreen} from './screen-orientation';
import {smartMouseDelta} from './smart-mouse';
import {connectDesktopPeer} from './desktop-peer';
import {RemoteVideo} from './RemoteVideo';
import {nextPipPhase,retainVideoConnection,type PipPhase,type PipEvent,type RemoteVideoHandle} from './pip-lifecycle';
import {RemoteSettings} from './RemoteSettings';
import {captureHardwareInput,hardwareInputAvailable,type HardwareInput} from './hardware-input';
import {RailControls,RailKeyboard,RailDesktop,RailWindows} from './RemoteRailIcons';
import {Text} from './Typography';
import {RemoteOperations} from './RemoteOperations';
import {RemoteKeyboard} from './RemoteKeyboard';
import React,{useEffect,useRef,useState} from 'react';
import {Alert,Animated,ActivityIndicator,AppState,Image,KeyboardAvoidingView,Modal,Platform,Pressable,ScrollView,StyleSheet,TextInput,View,useWindowDimensions} from 'react-native';
import {SafeAreaProvider,SafeAreaView} from 'react-native-safe-area-context';
import {ArrowLeft,MousePointer2,Monitor,RefreshCw,Send,Keyboard,LayoutGrid,SlidersHorizontal,Maximize2,Minimize2,Mouse,X} from 'lucide-react-native';
import {StatusBar} from 'expo-status-bar';
import {request} from './api';
import {friendlyError} from './errors';
import {colors as c} from './theme';
import type {Profile} from './types';

type Frame={mime?:'image/png'|'image/jpeg';frameId?:string;unchanged?:boolean;captureMs?:number;image:string;width:number;height:number;cursorX:number;cursorY:number};
type Mode='click'|'rightClick'|'doubleClick'|'drag';
const clientIds=new Map<string,string>(),sessionOperations=new Map<string,Promise<unknown>>();
function sessionOperation<T>(key:string,action:()=>Promise<T>):Promise<T>{const next=(sessionOperations.get(key)||Promise.resolve()).catch(()=>{}).then(action);sessionOperations.set(key,next);void next.finally(()=>{if(sessionOperations.get(key)===next)sessionOperations.delete(key);}).catch(()=>{});return next;}
const modes:{id:Mode;label:string}[]=[{id:'click',label:'点击'},{id:'rightClick',label:'右键'},{id:'doubleClick',label:'双击'},{id:'drag',label:'拖动'}];
function Button({label,onPress,disabled=false}:{label:string;onPress:()=>void;disabled?:boolean}){return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} disabled={disabled} style={[s.button,disabled&&{opacity:.35}]}><Text style={s.buttonText}>{label}</Text></Pressable>;}

export function RemoteDesktop({profile,name,onClose,onSleep,onFiles,onPower}:{profile:Profile;name:string;onClose:()=>void;onSleep?:()=>void;onFiles:()=>void;onPower:(kind:'restart'|'shutdown')=>void}){
  const clientKey=profile.url+'|'+profile.token;if(!clientIds.has(clientKey))clientIds.set(clientKey,'phone-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));const clientId=clientIds.get(clientKey)!;
  const [gamepadEnabled,setGamepadEnabled]=useState(false),[nativeGamepad,setNativeGamepad]=useState(false);
  const restoredFor=useRef(''),restoreSessionOptions=useRef<RemotePreferences|null>(null);const [pipEnabled,setPipEnabled]=useState(true);
  const [preferencesReady,setPreferencesReady]=useState(false),[qualityMode,setQualityMode]=useState<QualityMode>('original');
  const [hardwareMapping,setHardwareMapping]=useState(false),[peripheralRedirect,setPeripheralRedirect]=useState(false),[keyPreset,setKeyPreset]=useState<KeyPreset>('mac');
  function changeHardwareMapping(value:boolean){if(value&&!hardwareInputAvailable){setError('当前安装版本没有原生外设接口，请更新手机端。');return;}setHardwareMapping(value);if(value)setPeripheralRedirect(true);}
  function changePeripheralRedirect(value:boolean){if(value&&!hardwareInputAvailable){setError('当前安装版本没有原生外设接口，请更新手机端。');return;}setPeripheralRedirect(value);if(value&&!nativeGamepad)setGamepadEnabled(true);}
  const [rtcStream,setRtcStream]=useState<any>(null),[rtcRoute,setRtcRoute]=useState('HTTP 截图'),[rtcVisible,setRtcVisible]=useState(false);const rtcReady=useRef(false),rtcPeer=useRef<Awaited<ReturnType<typeof connectDesktopPeer>>>(null);
  const videoView=useRef<RemoteVideoHandle>(null),pipPhase=useRef<PipPhase>('idle'),pipTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  const [connectionEnabled,setConnectionEnabled]=useState(AppState.currentState==='active'),[nativePeerId,setNativePeerId]=useState<number|undefined>(undefined);
  const nativePeerRef=useRef<number|undefined>(undefined);nativePeerRef.current=nativePeerId;
  function handlePip(event:PipEvent){
    if(event.peerConnectionId!=null&&event.peerConnectionId!==nativePeerRef.current)return;
    if(event.state==='willStop')return;
    clearTimeout(pipTimer.current);pipPhase.current=nextPipPhase(event.state);
    const foreground=AppState.currentState==='active';
    setConnectionEnabled(retainVideoConnection(foreground,pipPhase.current));
    if(event.state==='failedToStart')setError(event.error?.message||'画中画启动失败。');
    if(event.state==='restoreRequested')pipTimer.current=setTimeout(()=>{if(AppState.currentState!=='active'){pipPhase.current='idle';setConnectionEnabled(false);}},4000);
  }
  async function startPip(){
    if(!rtcReady.current||!videoView.current)return setError('画中画需要已连接的实时视频，截图模式暂不支持。');
    pipPhase.current='starting';
    clearTimeout(pipTimer.current);pipTimer.current=setTimeout(()=>{if(pipPhase.current==='starting'){pipPhase.current='idle';setConnectionEnabled(AppState.currentState==='active');setError('画中画未启动，请返回前台重试。');}},5000);
    try{await videoView.current.startPip();setToolsOpen(false);}catch(e){clearTimeout(pipTimer.current);pipPhase.current='idle';setConnectionEnabled(AppState.currentState==='active');setError(friendlyError(e));}
  }
  useEffect(()=>()=>clearTimeout(pipTimer.current),[]);
  const [forceRelay,setForceRelay]=useState(false),relayRef=useRef<'all'|'relay'>('all'),relaySwitch=useRef(false);
  async function changeRelay(value:boolean){
    if(relaySwitch.current||value===forceRelay)return;const id=session.current;if(!id)return;
    if(colorRef.current==='trueColor'){setError('中转切换仅用于实时视频，请先切回常规模式。');return;}
    relaySwitch.current=true;let interrupted=false;
    try{
      const config=await request(profile,'/api/desktop/rtc/config?session='+encodeURIComponent(id));
      if(!config.available)throw new Error('电脑端实时视频组件不可用。');
      if(value&&!config.relayAvailable)throw new Error('电脑端尚未配置 TURN 中转服务。');
      interrupted=true;pipPhase.current='idle';clearTimeout(pipTimer.current);peerEpoch.current++;rtcPeer.current?.close(false);rtcPeer.current=null;rtcReady.current=false;setRtcVisible(false);setNativePeerId(undefined);setRtcSize(null);
      await request(profile,'/api/desktop/rtc/close',{method:'POST',body:{sessionId:id}});
      relayRef.current=value?'relay':'all';setForceRelay(value);reconnectPeer.current();
    }catch(e){if(interrupted)reconnectPeer.current();setError(friendlyError(e));}finally{relaySwitch.current=false;}
  }
  const [colorMode,setColorMode]=useState<'normal'|'trueColor'>('normal');const colorRef=useRef<'normal'|'trueColor'>('normal'),captureEpoch=useRef(0),peerEpoch=useRef(0),colorSwitch=useRef(false);
  async function changeColorMode(value:'normal'|'trueColor'){
    if(value===colorRef.current||colorSwitch.current)return;const id=session.current;if(!id)return;
    colorSwitch.current=true;pipPhase.current='idle';clearTimeout(pipTimer.current);colorRef.current=value;captureEpoch.current++;peerEpoch.current++;
    rtcPeer.current?.close(false);rtcPeer.current=null;rtcReady.current=false;setRtcVisible(false);setNativePeerId(undefined);setRtcSize(null);lastFrameId.current=undefined;
    try{await request(profile,'/api/desktop/rtc/close',{method:'POST',body:{sessionId:id}});setColorMode(value);if(value==='trueColor'){relayRef.current='all';setForceRelay(false);audioRef.current=false;setAudioEnabled(false);}else reconnectPeer.current();}
    catch(e){colorRef.current='normal';setColorMode('normal');reconnectPeer.current();setError(friendlyError(e));}
    finally{colorSwitch.current=false;}
  }
  const [audioEnabled,setAudioEnabled]=useState(false);const audioRef=useRef(false);
  const [videoDiagnostics,setVideoDiagnostics]=useState<any>(null);
  const [rtcSize,setRtcSize]=useState<{width:number;height:number}|null>(null);
  function videoSize(width:number,height:number){if(Number.isInteger(width)&&Number.isInteger(height)&&width>0&&height>0&&width<=8192&&height<=8192)setRtcSize(old=>old?.width===width&&old?.height===height?old:{width,height});}
  const [avoidCutouts,setAvoidCutouts]=useState(false),[smartMouse,setSmartMouse]=useState(false);const hardwareMoveTime=useRef(0),lastPointerInputAt=useRef(0);
  const [autoHideMs,setAutoHideMs]=useState(3500);const [chrome,setChrome]=useState(true),[adaptive,setAdaptive]=useState(false),[captureMs,setCaptureMs]=useState(0);
  const chromeTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined),lastFrameId=useRef<string|undefined>(undefined),lastLatency=useRef(0),unchangedCount=useRef(0);
  function toggleChrome(){setChrome(v=>!v);setToolsOpen(false);setKeyboardOpen(false);}
  const [microphone,setMicrophone]=useState(false),microphoneRef=useRef(false);
  async function changeMicrophone(value:boolean){const id=session.current;if(!id)return;if(value&&colorRef.current!=='normal'){setError('麦克风转发需要实时视频连接。');return;}try{if(value){const config=await request(profile,'/api/desktop/rtc/config?session='+encodeURIComponent(id));if(!config.microphoneAvailable)throw new Error('请先在电脑端允许手机麦克风输入。');}rtcPeer.current?.close(false);rtcPeer.current=null;await request(profile,'/api/desktop/rtc/close',{method:'POST',body:{sessionId:id}});microphoneRef.current=value;setMicrophone(value);reconnectPeer.current();}catch(e){setError(friendlyError(e));}}
  const [localMute,setLocalMute]=useState(false),localMuteRef=useRef(false);
  async function changeLocalMute(value:boolean){
    const id=session.current;if(!id)return;
    if(value&&colorRef.current!=='normal'){setError('请切换到常规视频后启用静音运行，以继续转发声音。');return;}
    try{
      if(value){const config=await request(profile,'/api/desktop/rtc/config?session='+encodeURIComponent(id));if(!config.audioAvailable)throw new Error('请先在电脑端允许系统声音转发并重启连接服务。');}
      rtcPeer.current?.close(false);rtcPeer.current=null;await request(profile,'/api/desktop/rtc/close',{method:'POST',body:{sessionId:id}});
      if(value){audioRef.current=true;setAudioEnabled(true);}
      localMuteRef.current=value;setLocalMute(value);reconnectPeer.current();
    }catch(error){setError(friendlyError(error));}
  }

  const [privacy,setPrivacy]=useState(false);
  async function changePrivacy(enabled:boolean){if(enabled&&!rtcReady.current){setError('防窥需要已连接的实时视频。');return;}try{await request(profile,'/api/desktop/rtc/privacy',{method:'POST',body:{sessionId:session.current,enabled}});setPrivacy(enabled);}catch(e){setError(friendlyError(e));}}
  const [customBitrate,setCustomBitrate]=useState<number|undefined>(30000000),bitrateRef=useRef<number|undefined>(30000000);
  async function changeBitrate(value:number|undefined){const id=session.current;try{if(id&&rtcReady.current)await request(profile,'/api/desktop/rtc/config',{method:'POST',body:{sessionId:id,quality:qualityRef.current,frameRate:frameRateRef.current,bitrate:value}});bitrateRef.current=value;setCustomBitrate(value);setQualityMode(value===undefined?'auto':'custom');}catch(e){setError(friendlyError(e));}}
  const [frameRate,setFrameRate]=useState(30),frameRateRef=useRef(30);
  async function changeFrameRate(value:number){if(![30,60,90,144].includes(value))return;const id=session.current;try{if(id&&rtcReady.current)await request(profile,'/api/desktop/rtc/config',{method:'POST',body:{sessionId:id,quality:qualityRef.current,frameRate:value,bitrate:bitrateRef.current}});frameRateRef.current=value;setFrameRate(value);}catch(e){setError(friendlyError(e));}}
  const [quality,setQuality]=useState<'smooth'|'balanced'|'hd'>('hd'),[stats,setStats]=useState({fps:0,latency:0,bytes:0}),[panel,setPanel]=useState('操作'),[keyboardOpen,setKeyboardOpen]=useState(false);
  function changeQuality(value:'smooth'|'balanced'|'hd'){setQuality(value);qualityRef.current=value;const id=session.current;if(id&&rtcReady.current)void request(profile,'/api/desktop/rtc/config',{method:'POST',body:{sessionId:id,quality:value,frameRate:frameRateRef.current,bitrate:bitrateRef.current}}).catch(e=>setError(friendlyError(e)));}
  async function changeQualityMode(value:QualityMode){
    const preset=value==='auto'?{quality:'balanced' as const,bitrate:undefined}:value==='high'?{quality:'balanced' as const,bitrate:8000000}:value==='ultra'?{quality:'hd' as const,bitrate:14000000}:value==='original'?{quality:'hd' as const,bitrate:30000000}:{quality:'hd' as const,bitrate:customBitrate??8000000};
    try{const id=session.current;if(id&&rtcReady.current)await request(profile,'/api/desktop/rtc/config',{method:'POST',body:{sessionId:id,quality:preset.quality,frameRate:frameRateRef.current,bitrate:preset.bitrate}});qualityRef.current=preset.quality;bitrateRef.current=preset.bitrate;setQuality(preset.quality);setCustomBitrate(preset.bitrate);setQualityMode(value);}catch(error){setError(friendlyError(error));}
  }
  const telemetry=useRef({count:0,start:Date.now(),bytes:0}),qualityRef=useRef(quality);qualityRef.current=quality;
  const [fullScreen,setFullScreen]=useState(false),[toolsOpen,setToolsOpen]=useState(false),[pointerMode,setPointerMode]=useState(false);
  useEffect(()=>{if(chromeTimer.current)clearTimeout(chromeTimer.current);if(autoHideMs&&fullScreen&&chrome&&!toolsOpen&&!keyboardOpen)chromeTimer.current=setTimeout(()=>setChrome(false),autoHideMs);return()=>clearTimeout(chromeTimer.current);},[fullScreen,chrome,toolsOpen,keyboardOpen,autoHideMs]);
  const [showMouseButtons,setShowMouseButtons]=useState(false);
  const [tabletTouch,setTabletTouch]=useState(false),tabletRef=useRef(false),tabletChanging=useRef(false),touchContacts=useRef(new TouchContacts()),touchSnapshot=useRef<TouchContact[]>([]);
  const touchMovePending=useRef<any>(null);
  function clearTabletTouch(){touchContacts.current.clear();touchSnapshot.current=[];const id=session.current;if(id)void inputQueue.current.catch(()=>{}).then(()=>request(profile,'/api/desktop/input',{method:'POST',body:{sessionId:id,input:{type:'touchFrame',contacts:[]}},timeoutMs:2000})).catch(()=>{});}
  async function changeTabletTouch(value:boolean){if(tabletChanging.current||value===tabletRef.current)return;tabletChanging.current=true;try{if(value){await input({type:'touchInitialize'});setPointerMode(false);setVirtualMouse(false);}else await input({type:'touchFrame',contacts:[]});clearTimeout(holdTimer.current);gesture.current=null;touchContacts.current.clear();touchSnapshot.current=[];tabletRef.current=value;setTabletTouch(value);}catch(e){setError(friendlyError(e));}finally{tabletChanging.current=false;}}
  function tabletEvent(e:any,phase:'change'|'move'){if(!tabletRef.current||!control)return;const rect=Platform.OS==='web'?e.currentTarget?.getBoundingClientRect?.():null;const touches=Array.from(e.nativeEvent.touches||[]).map((t:any)=>({identifier:t.identifier,locationX:t.locationX??(rect?t.clientX-rect.left:NaN),locationY:t.locationY??(rect?t.clientY-rect.top:NaN)}));const contacts=touchContacts.current.snapshot(touches,point);touchSnapshot.current=contacts;void input({type:'touchFrame',contacts,phase}).catch(()=>{clearTabletTouch();tabletRef.current=false;setTabletTouch(false);});}

  const [dragging,setDragging]=useState(false);const [virtualMouse,setVirtualMouse]=useState(false);const [ripple,setRipple]=useState<{x:number;y:number}|null>(null);const rippleAnim=useRef(new Animated.Value(0)).current;
  const [,setSurfaceRevision]=useState(0);
  const pendingMoves=useRef<any>(null),moveQueued=useRef(false),inputQueue=useRef<Promise<unknown>>(Promise.resolve()),pointerRef=useRef({x:.5,y:.5}),holdTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  const [view,setView]=useState({zoom:1,x:0,y:0}),[pointer,setPointer]=useState({x:.5,y:.5});
  pointerRef.current=pointer;
  const viewRef=useRef(view);const gesture=useRef<any>(null);
  const gestureX=useRef(new Animated.Value(0)).current,gestureY=useRef(new Animated.Value(0)).current,gestureZoom=useRef(new Animated.Value(1)).current;
  useEffect(()=>{viewRef.current=view;gestureX.setValue(view.x);gestureY.setValue(view.y);gestureZoom.setValue(view.zoom);},[view]);
  function applyGestureView(value:{zoom:number;x:number;y:number}){viewRef.current=value;gestureX.setValue(value.x);gestureY.setValue(value.y);gestureZoom.setValue(value.zoom);}
  function fingerEnded(e:any){const g=gesture.current,t=e.nativeEvent.touches;if(!g||!g.multi||!t?.length)return;g.px=t[0].pageX;g.py=t[0].pageY;g.view={...viewRef.current};g.distance=0;g.cx=undefined;g.cy=undefined;g.lastX=g.px;g.lastY=g.py;}

  const {width,height}=useWindowDimensions();const landscape=width>height,railWidth=Math.round(width*.077),railScale=Math.max(.85,Math.min(1.4,width/844));
  const [screenshotFrame,setFrame]=useState<Frame|null>(null),[error,setError]=useState(''),[connecting,setConnecting]=useState(true),[control,setControl]=useState(true),[mode,setMode]=useState<Mode>('click'),[text,setText]=useState(''),[sending,setSending]=useState(false),[revision,setRevision]=useState(0),[active,setActive]=useState(AppState.currentState==='active');
  const frame=screenshotFrame&&rtcVisible&&rtcSize?{...screenshotFrame,...rtcSize}:screenshotFrame;
  const session=useRef<string|null>(null),busy=useRef(false),surface=useRef({width:0,height:0}),start=useRef<{x:number;y:number}|null>(null),mounted=useRef(true);
  const reconnectPeer=useRef<()=>void>(()=>{});
  async function changeAudio(value:boolean){if(value&&colorRef.current==='trueColor'){setError('无损图片模式不转发声音，请先切回常规视频。');return;}const id=session.current;if(!id)return;try{if(value){const config=await request(profile,'/api/desktop/rtc/config?session='+encodeURIComponent(id));if(!config.audioAvailable)throw new Error('请先在电脑端允许系统声音转发并重新启动服务。');}if(!value)rtcStream?.getAudioTracks?.().forEach((track:any)=>{track.enabled=false;});rtcPeer.current?.close(false);rtcPeer.current=null;await request(profile,'/api/desktop/rtc/close',{method:'POST',body:{sessionId:id}});audioRef.current=value;setAudioEnabled(value);if(!value){localMuteRef.current=false;setLocalMute(false);}reconnectPeer.current();}catch(e){setError(friendlyError(e));}}
  const [lockOnEnd,setLockOnEnd]=useState(false);
  async function changeEndLock(value:boolean){const id=session.current;if(!id)return;try{await request(profile,'/api/desktop/preferences',{method:'POST',body:{sessionId:id,lockOnEnd:value}});setLockOnEnd(value);}catch(e){setError(friendlyError(e));}}
  const [displays,setDisplays]=useState<any[]>([]),[selectedDisplay,setSelectedDisplay]=useState('');
  async function openDisplaySettings(){const id=session.current;if(!id)return;try{await request(profile,'/api/desktop/display/settings',{method:'POST',body:{sessionId:id}});setToolsOpen(false);}catch(e){setError(friendlyError(e));}}
  async function loadDisplays(){const id=session.current;if(!id)return;try{const result=await request(profile,'/api/desktop/displays?session='+encodeURIComponent(id));if(!Array.isArray(result.displays))throw new Error('电脑端未提供屏幕列表，请更新电脑端。');setDisplays(result.displays);setSelectedDisplay(result.selected);}catch(e){setError(friendlyError(e));}}
  useEffect(()=>{
    let cancelled=false;restoredFor.current='';setPreferencesReady(false);
    void loadRemotePreferences(profile.url).then(p=>{
      if(cancelled)return;
      setQuality(p.quality);qualityRef.current=p.quality;setQualityMode(p.qualityMode);setCustomBitrate(p.bitrate);bitrateRef.current=p.bitrate;setFrameRate(p.frameRate);frameRateRef.current=p.frameRate;
      setColorMode(p.colorMode);colorRef.current=p.colorMode;setPointerMode(p.pointerMode);setVirtualMouse(p.virtualMouse);setShowMouseButtons(p.showMouseButtons);setSmartMouse(p.smartMouse);setAvoidCutouts(p.avoidCutouts);setAutoHideMs(p.autoHideMs);setFullScreen(p.fullScreen);setControl(p.control);setView({zoom:1,x:0,y:0});
      restoreSessionOptions.current=p;setLockOnEnd(p.lockOnEnd);setSelectedDisplay(p.selectedDisplay);setGamepadEnabled(p.gamepad);setNativeGamepad(p.nativeGamepad);setMicrophone(p.microphone);microphoneRef.current=p.microphone;setPipEnabled(p.pipEnabled);setAudioEnabled(p.audio);audioRef.current=p.audio;setLocalMute(p.localMute);localMuteRef.current=p.localMute;setHardwareMapping(p.hardwareMapping);setPeripheralRedirect(p.peripheralRedirect);setKeyPreset(p.keyPreset);
      restoredFor.current=clientKey;setPreferencesReady(true);
    }).catch(()=>{if(!cancelled)setPreferencesReady(true);});return()=>{cancelled=true;};
  },[profile.url,profile.token]);
  useEffect(()=>{
    if(!preferencesReady||restoredFor.current!==clientKey)return;
    const value:RemotePreferences={tabletTouch,lockOnEnd,microphone,gamepad:gamepadEnabled,nativeGamepad,selectedDisplay,quality,qualityMode,bitrate:customBitrate,frameRate,colorMode,pointerMode,virtualMouse,showMouseButtons,smartMouse,avoidCutouts,autoHideMs,fullScreen,control,pipEnabled,audio:audioEnabled,localMute,hardwareMapping,peripheralRedirect,keyPreset};
    void saveRemotePreferences(profile.url,value).catch(()=>setError('远程设置保存失败，请检查设备存储后重试。'));
  },[preferencesReady,profile.url,tabletTouch,lockOnEnd,microphone,gamepadEnabled,nativeGamepad,selectedDisplay,quality,qualityMode,customBitrate,frameRate,colorMode,pointerMode,virtualMouse,showMouseButtons,smartMouse,avoidCutouts,autoHideMs,fullScreen,control,pipEnabled,audioEnabled,localMute,hardwareMapping,peripheralRedirect,keyPreset]);
  useEffect(()=>{if(panel==='屏幕'&&toolsOpen)void loadDisplays();},[panel,toolsOpen]);
  async function changeDisplay(screenId:string,resolution?:{width:number;height:number}){const id=session.current;if(!id)return;try{rtcPeer.current?.close(false);rtcPeer.current=null;rtcReady.current=false;setRtcVisible(false);setRtcRoute('HTTP 截图');await request(profile,'/api/desktop/display',{method:'POST',body:{sessionId:id,screenId,resolution,confirm:resolution?'CHANGE_RESOLUTION':undefined}});lastFrameId.current=undefined;setView({zoom:1,x:0,y:0});await loadDisplays();reconnectPeer.current();}catch(e){setError(friendlyError(e));}}
  useEffect(()=>{const sub=AppState.addEventListener('change',state=>{
    const foreground=state==='active';
    if(!foreground&&pipEnabled&&rtcReady.current&&pipPhase.current==='idle'){
      pipPhase.current='starting';clearTimeout(pipTimer.current);
      pipTimer.current=setTimeout(()=>{if(pipPhase.current==='starting'){pipPhase.current='idle';setConnectionEnabled(AppState.currentState==='active');}},5000);
    }
    setActive(foreground);setConnectionEnabled(retainVideoConnection(foreground,pipPhase.current));
  });return ()=>sub.remove();},[pipEnabled]);
  useEffect(()=>()=>{mounted.current=false;},[]);
  useEffect(()=>{
    let alive=true,timer:ReturnType<typeof setTimeout>|undefined,retryTimer:ReturnType<typeof setTimeout>|undefined;let retryCount=0;const abort=new AbortController();let owned:string|null=null;
    tabletRef.current=false;setTabletTouch(false);touchContacts.current.clear();touchSnapshot.current=[];setNativePeerId(undefined);rtcReady.current=false;setRtcVisible(false);setRtcStream(null);setRtcSize(null);setRtcRoute('HTTP 截图');
    telemetry.current={count:0,start:Date.now(),bytes:0};lastFrameId.current=undefined;setStats({fps:0,latency:0,bytes:0});setFrame(null);setError('');setConnecting(active);
    function update(value:Frame){if(!value||!Number.isInteger(value.width)||!Number.isInteger(value.height)||value.width<1||value.width>2560||value.height<1||value.height>1600||typeof value.image!=='string'||value.image.length>32*1024*1024||(value.mime!==undefined&&!['image/png','image/jpeg'].includes(value.mime)))throw new Error('电脑返回的桌面画面无效，请重新连接。');if(alive)setFrame(value);}
    async function poll(){if(!alive||!owned)return;if(AppState.currentState!=='active'){timer=setTimeout(()=>void poll(),1000);return;}if(rtcReady.current){timer=setTimeout(()=>void poll(),1000);return;}const began=Date.now();try{
      const mode=colorRef.current,epoch=captureEpoch.current;const effective=mode==='trueColor'?qualityRef.current:qualityRef.current==='hd'&&lastLatency.current>1500?'balanced':qualityRef.current==='balanced'&&lastLatency.current>2500?'smooth':qualityRef.current;
      const next=await request<Frame>(profile,`/api/desktop/frame?session=${encodeURIComponent(owned)}&quality=${effective}&colorMode=${mode}&since=${lastFrameId.current||''}`,{signal:abort.signal,timeoutMs:7000});
      if(epoch!==captureEpoch.current){timer=setTimeout(()=>void poll(),0);return;}if(mode==='trueColor'){if(next.mime!=='image/png')throw new Error('电脑端尚未支持无损图片模式，请更新电脑端。');setRtcRoute('HTTP 无损 PNG');}else if(!rtcReady.current)setRtcRoute('HTTP 截图');
      const elapsed=Date.now()-began;lastLatency.current=elapsed;setAdaptive(effective!==qualityRef.current);setCaptureMs(next.captureMs||0);
      if(!next.unchanged){update(next);lastFrameId.current=next.frameId;unchangedCount.current=0;}else unchangedCount.current++;
      const t=telemetry.current;t.count++;t.bytes+=JSON.stringify(next).length;const now=Date.now();
      if(alive){setControl(true);setStats({fps:Math.round(t.count*10000/Math.max(1,now-t.start))/10,latency:elapsed,bytes:t.bytes});if(now-t.start>2500){t.count=0;t.start=now;}setError('');timer=setTimeout(()=>void poll(),Math.max(60,Math.min(1000,unchangedCount.current*100),Math.max(effective==='hd'?220:140,elapsed*1.15)-elapsed));}
    }catch(e){if(alive){setControl(false);setError(friendlyError(e));if((e as any)?.status===410){setFrame(null);setConnecting(false);}else timer=setTimeout(()=>void poll(),1000);}}}


    if(connectionEnabled&&preferencesReady&&restoredFor.current===clientKey)void (async()=>{try{
      const value=await sessionOperation(clientKey,()=>request<Frame&{sessionId:string}>(profile,'/api/desktop/session',{method:'POST',body:{confirm:'VIEW',clientId},timeoutMs:10000}));owned=value.sessionId;
      if(!alive)return;
      session.current=owned;setControl(true);
      const saved=restoreSessionOptions.current;
      if(saved?.lockOnEnd)await request(profile,'/api/desktop/preferences',{method:'POST',body:{sessionId:owned,lockOnEnd:true},signal:abort.signal});
      if(saved?.selectedDisplay){const screens=await request(profile,'/api/desktop/displays?session='+encodeURIComponent(owned),{signal:abort.signal});if(screens.displays?.some((screen:any)=>screen.id===saved.selectedDisplay)&&screens.selected!==saved.selectedDisplay)await request(profile,'/api/desktop/display',{method:'POST',body:{sessionId:owned,screenId:saved.selectedDisplay},signal:abort.signal});}
      if(saved?.tabletTouch){try{await request(profile,'/api/desktop/input',{method:'POST',body:{sessionId:owned,input:{type:'touchInitialize'}},signal:abort.signal});tabletRef.current=true;setTabletTouch(true);}catch(error){if(alive)setError(friendlyError(error));}}
      if(!alive)return;
      reconnectPeer.current=()=>{clearTimeout(retryTimer);if(!owned||!alive||colorRef.current!=='normal')return;const epoch=++peerEpoch.current;void connectDesktopPeer(profile,owned,qualityRef.current,abort.signal,stream=>{if(alive&&epoch===peerEpoch.current&&colorRef.current==='normal')setRtcStream(stream);},ready=>{if(alive&&epoch===peerEpoch.current&&colorRef.current==='normal'){rtcReady.current=ready;if(ready){retryCount=0;setRtcVisible(true);}if(!ready){setPrivacy(false);setRtcSize(null);setRtcRoute('HTTP 回退');if(AppState.currentState!=='active'){pipPhase.current='idle';setConnectionEnabled(false);}}else if(owned){void request(profile,'/api/desktop/rtc/config',{method:'POST',body:{sessionId:owned,quality:qualityRef.current,frameRate:frameRateRef.current,bitrate:bitrateRef.current}}).catch(e=>{if(alive)setError(friendlyError(e));});}}},value=>{if(alive&&epoch===peerEpoch.current&&colorRef.current==='normal'){setRtcRoute(value.route);setVideoDiagnostics(value);if(typeof value.sender?.microphoneActive==='boolean')setMicrophone(value.sender.microphoneActive);if(value.sender?.audioActive===false){setAudioEnabled(false);setLocalMute(false);}const cursor=value.sender;if(Date.now()-lastPointerInputAt.current>250&&Number.isFinite(cursor?.cursorX)&&Number.isFinite(cursor?.cursorY)){const point={x:Math.max(0,Math.min(1,cursor.cursorX)),y:Math.max(0,Math.min(1,cursor.cursorY))};pointerRef.current=point;setPointer(point);}videoSize(value.frameWidth,value.frameHeight);if(rtcReady.current)setStats({...value,bytes:value.bytes+telemetry.current.bytes});}},audioRef.current,frameRateRef.current,relayRef.current,(error)=>{if(!alive||epoch!==peerEpoch.current)return;if(error){microphoneRef.current=false;setMicrophone(false);setError(friendlyError(error));}if(alive&&epoch===peerEpoch.current&&AppState.currentState==='active')retryTimer=setTimeout(()=>reconnectPeer.current(),Math.min(15000,1000*2**Math.min(retryCount++,4)));},bitrateRef.current,localMuteRef.current,microphoneRef.current).then(peer=>{if(alive&&epoch===peerEpoch.current&&colorRef.current==='normal'){rtcPeer.current=peer;setNativePeerId(peer?.nativeId);}else peer?.close(false);}).catch(e=>{if(alive&&epoch===peerEpoch.current&&colorRef.current==='normal'){setRtcRoute('HTTP 回退');if(microphoneRef.current){microphoneRef.current=false;setMicrophone(false);setError(friendlyError(e));}if(alive&&!abort.signal.aborted)retryTimer=setTimeout(()=>reconnectPeer.current(),Math.min(15000,1000*2**Math.min(retryCount++,4)));if(audioRef.current){audioRef.current=false;setAudioEnabled(false);localMuteRef.current=false;setLocalMute(false);setError(friendlyError(e));}}});};reconnectPeer.current();
      lastFrameId.current=value.frameId;unchangedCount.current=0;lastLatency.current=0;update(value);setConnecting(false);timer=setTimeout(()=>void poll(),80);
    }catch(e){if(alive){setConnecting(false);setError(friendlyError(e));}}})();
    return ()=>{alive=false;rtcPeer.current?.close();rtcPeer.current=null;rtcReady.current=false;if(timer)clearTimeout(timer);clearTimeout(retryTimer);abort.abort();if(session.current===owned)session.current=null;void sessionOperation(clientKey,async()=>{if(owned)await request(profile,'/api/desktop/session',{method:'DELETE',body:{sessionId:owned},timeoutMs:5000});}).catch(()=>{});};
  },[profile.url,profile.token,revision,connectionEnabled,preferencesReady]);
  function input(value:unknown):Promise<void>{
    const id=session.current;if(!control||!id||!frame||!active)return Promise.reject(new Error('请先连接并开启控制'));
    if(['pointerMove','pointerDown','click','rightClick','doubleClick','drag','mouseButton'].includes((value as any)?.type))lastPointerInputAt.current=Date.now();
    let touchBatch:any=null;if((value as any)?.type==='touchFrame'){if((value as any)?.phase==='move'){if(touchMovePending.current){touchMovePending.current.value=value;return Promise.resolve();}touchBatch={value};touchMovePending.current=touchBatch;}else touchMovePending.current=null;}
    if((value as any)?.type==='pointerMove'){pendingMoves.current=value;if(moveQueued.current)return Promise.resolve();moveQueued.current=true;}
    const job=inputQueue.current.catch(()=>{}).then(async()=>{if(touchBatch){value=touchBatch.value;if(touchMovePending.current===touchBatch)touchMovePending.current=null;}if((value as any)?.type==='pointerMove'){value=pendingMoves.current;pendingMoves.current=null;moveQueued.current=false;}if(session.current!==id)throw new Error('桌面会话已变化');setSending(true);try{if(rtcPeer.current?.connected)await rtcPeer.current.send(value);else await request(profile,'/api/desktop/input',{method:'POST',body:{sessionId:id,input:value},timeoutMs:5000});}catch(e){if(mounted.current)setError(friendlyError(e));throw e;}});
    inputQueue.current=job;void job.finally(()=>{if(inputQueue.current===job&&mounted.current)setSending(false);}).catch(()=>{});return job;
  }
  function feedback(x:number,y:number){setRipple({x,y});rippleAnim.setValue(0);Animated.timing(rippleAnim,{toValue:1,duration:450,useNativeDriver:true}).start(()=>setRipple(null));}
  function point(x:number,y:number){if(!frame)return null;const box=surface.current,v=viewRef.current,scale=Math.min(box.width/frame.width,box.height/frame.height),w=frame.width*scale,h=frame.height*scale,left=(box.width-w)/2,top=!landscape&&toolsOpen?box.height-h:(box.height-h)/2,cx=left+w/2,cy=top+h/2;x=(x-cx-v.x)/v.zoom+cx;y=(y-cy-v.y)/v.zoom+cy;const px=(x-left)/w,py=(y-top)/h;return px>=0&&px<=1&&py>=0&&py<=1?{x:px,y:py}:null;}
  function begin(e:any){if(tabletRef.current)return;const t=e.nativeEvent.touches;if(!t.length)return;const a=t[0],b=t[1];gesture.current={px:a.pageX,py:a.pageY,view:{...viewRef.current},pointer:{...pointer},distance:b?Math.hypot(a.pageX-b.pageX,a.pageY-b.pageY):0,moved:false,dragging:false,multi:!!b,originX:a.pageX-a.locationX,originY:a.pageY-a.locationY,edge:a.locationX<28||a.locationX>surface.current.width-28};start.current=point(e.nativeEvent.locationX,e.nativeEvent.locationY);clearTimeout(holdTimer.current);if(control&&!b&&start.current){const g=gesture.current;holdTimer.current=setTimeout(()=>{if(gesture.current===g&&!g.moved&&!g.multi){g.dragging=true;setDragging(true);void input({type:'pointerDown',...(pointerMode?pointerRef.current:start.current)}).catch(()=>{g.dragging=false;setDragging(false);});}},420);}}
  function addFinger(e:any){if(tabletRef.current)return;const g=gesture.current,t=e.nativeEvent.touches;if(!g||t.length<2||g.distance)return;clearTimeout(holdTimer.current);if(g.dragging){g.dragging=false;setDragging(false);void input({type:'pointerUp'}).catch(()=>{});}g.multi=true;g.distance=Math.hypot(t[0].pageX-t[1].pageX,t[0].pageY-t[1].pageY);g.cx=(t[0].pageX+t[1].pageX)/2;g.cy=(t[0].pageY+t[1].pageY)/2;g.view={...viewRef.current};}
  function move(e:any){if(tabletRef.current)return;const g=gesture.current,t=e.nativeEvent.touches;if(!g||!t.length)return;const a=t[0],b=t[1],dx=a.pageX-g.px,dy=a.pageY-g.py;if(fullScreen&&g.edge&&!b&&Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.5){g.multi=true;if(!g.toggled){g.toggled=true;toggleChrome();}return;}if(b){clearTimeout(holdTimer.current);if(g.dragging){g.dragging=false;void input({type:'pointerUp'}).catch(()=>{});}g.multi=true;const d=Math.hypot(a.pageX-b.pageX,a.pageY-b.pageY);const cx=(a.pageX+b.pageX)/2,cy=(a.pageY+b.pageY)/2;if(!g.distance){g.distance=d;g.view={...viewRef.current};}if(g.cx===undefined){g.cx=cx;g.cy=cy;}const zoom=Math.max(1,Math.min(4,g.view.zoom*d/Math.max(1,g.distance)));const fx=Math.max(0,((frame?.width||0)*fit*zoom-surface.current.width)/2)+(zoom>1?surface.current.width*.3:0),fy=Math.max(0,((frame?.height||0)*fit*zoom-surface.current.height)/2)+(zoom>1?surface.current.height*.3:0);applyGestureView({zoom,x:Math.max(-fx,Math.min(fx,(cx-g.originX-surface.current.width/2)-(g.cx-g.originX-surface.current.width/2-g.view.x)*(zoom/g.view.zoom))),y:Math.max(-fy,Math.min(fy,(cy-g.originY-surface.current.height/2)-(g.cy-g.originY-surface.current.height/2-g.view.y)*(zoom/g.view.zoom)))});return;}if(Math.abs(dx)+Math.abs(dy)>5){g.moved=true;clearTimeout(holdTimer.current);}if(g.dragging){const pos=pointerMode?{x:Math.max(0,Math.min(1,g.pointer.x+dx/surface.current.width)),y:Math.max(0,Math.min(1,g.pointer.y+dy/surface.current.height))}:point(a.locationX,a.locationY);if(pos)void input({type:'pointerMove',...pos}).catch(()=>{});return;}if(pointerMode&&control&&!g.multi){const now=Date.now(),delta=smartMouseDelta(a.pageX-(g.lastX??g.px),a.pageY-(g.lastY??g.py),g.lastAt?now-g.lastAt:16,smartMouse);g.lastX=a.pageX;g.lastY=a.pageY;g.lastAt=now;const next={x:Math.max(0,Math.min(1,pointerRef.current.x+delta.dx/surface.current.width/viewRef.current.zoom)),y:Math.max(0,Math.min(1,pointerRef.current.y+delta.dy/surface.current.height/viewRef.current.zoom))};pointerRef.current=next;setPointer(next);void input({type:'pointerMove',...next}).catch(()=>{});}else {const v=g.view,b=surface.current,fx=Math.max(0,((frame?.width||0)*fit*v.zoom-b.width)/2)+(v.zoom>1||!landscape?b.width*.3:0),fy=Math.max(0,((frame?.height||0)*fit*v.zoom-b.height)/2)+(v.zoom>1||!landscape?b.height*.3:0);applyGestureView({...v,x:Math.max(-fx,Math.min(fx,v.x+dx)),y:Math.max(-fy,Math.min(fy,v.y+dy))});}}
  function release(x:number,y:number){if(tabletRef.current)return;setView({...viewRef.current});clearTimeout(holdTimer.current);const g=gesture.current;if(g?.dragging){setDragging(false);gesture.current=null;start.current=null;void input({type:'pointerUp'}).catch(()=>{});return;}gesture.current=null;const from=start.current;start.current=null;if(!control||g?.multi)return;const to=pointerMode?pointerRef.current:point(x,y);if(!from||!to)return;if(mode==='drag'){void input({type:'drag',...(pointerMode?g.pointer:from),to}).catch(()=>{});return;}if(!g?.moved){if(!pointerMode&&!virtualMouse)feedback(x,y);void input({type:mode,...to}).catch(()=>{});}}
  async function sendText(){if(!text.trim())return;const value=text;try{await input({type:'text',text:value});if(mounted.current)setText(current=>current===value?'':current);}catch{}}
  const enabled=!!frame&&active&&!connecting;
  useEffect(()=>{if(!enabled||!control)return;const timer=setInterval(()=>{if(gesture.current?.dragging)void input({type:'inputHeartbeat'}).catch(()=>{});},1000);return()=>clearInterval(timer);},[enabled,control,profile.url,profile.token]);
  useEffect(()=>{if(!tabletTouch)return;if(!enabled||!control||pointerMode){clearTabletTouch();tabletRef.current=false;setTabletTouch(false);return;}const timer=setInterval(()=>{if(touchSnapshot.current.length)void input({type:'touchFrame',contacts:touchSnapshot.current,phase:'move'}).catch(()=>{});},100);return()=>clearInterval(timer);},[tabletTouch,enabled,control,pointerMode]);
  useEffect(()=>{if(tabletRef.current){clearTabletTouch();tabletRef.current=false;setTabletTouch(false);}},[width,height,selectedDisplay]);
  const changeNativeGamepad=async(value:boolean)=>{try{await input({type:value?"gamepadInitialize":"releaseAll"});setNativeGamepad(value);if(value){setGamepadEnabled(false);setPeripheralRedirect(true);}}catch(e){Alert.alert("原生 Xbox 手柄",String((e as Error).message));}};
  const hardwareHandler=useRef<(event:HardwareInput)=>void>(()=>{});
  hardwareHandler.current=event=>{
    if(event.type==='mouseMove'){
      const now=Date.now(),delta=smartMouseDelta(event.dx,event.dy,hardwareMoveTime.current?now-hardwareMoveTime.current:16,smartMouse);hardwareMoveTime.current=now;const next={x:Math.max(0,Math.min(1,pointerRef.current.x+delta.dx/Math.max(1,surface.current.width))),y:Math.max(0,Math.min(1,pointerRef.current.y+delta.dy/Math.max(1,surface.current.height)))};pointerRef.current=next;setPointer(next);setPointerMode(true);void input({type:'pointerMove',...next}).catch(()=>{});
    }else void input(event.type==='mouseButton'?{...event,...pointerRef.current}:event).catch(error=>{if(event.type==='gamepadState'){setNativeGamepad(false);setError(String((error as Error).message));}});
  };
  useEffect(()=>{
    if(!enabled||!control||keyboardOpen||toolsOpen||!hardwareInputAvailable||!peripheralRedirect)return;
    const pressed=new Set<string>();
    let cancelled=false,stop=()=>{};
    const begin=async()=>{try{if(nativeGamepad)await input({type:"gamepadInitialize"});if(cancelled)return;stop=captureHardwareInput(event=>{if(event.type==='keyDown')pressed.add('k'+event.keyCode);if(event.type==='keyUp')pressed.delete('k'+event.keyCode);if(event.type==='mouseButton'){if(event.down)pressed.add(event.button);else pressed.delete(event.button);}if(event.type==='releaseAll')pressed.clear();hardwareHandler.current(event);},gamepadEnabled,nativeGamepad,{enabled:hardwareMapping,preset:keyPreset,onError:error=>{setError(friendlyError(error));}});}catch(e){if(!cancelled){setNativeGamepad(false);setGamepadEnabled(true);setError(friendlyError(e));}}};void begin();
    const timer=setInterval(()=>{if(pressed.size)hardwareHandler.current({type:'inputHeartbeat'} as any);},1000);
    return()=>{cancelled=true;clearInterval(timer);stop();const id=session.current;if(id)void request(profile,'/api/desktop/input',{method:'POST',body:{sessionId:id,input:{type:'releaseAll'}},timeoutMs:2000}).catch(()=>{});};
  },[enabled,control,keyboardOpen,toolsOpen,gamepadEnabled,nativeGamepad,hardwareMapping,peripheralRedirect,keyPreset,profile.url,profile.token]);

  const box=surface.current,fit=frame?Math.min(box.width/frame.width,box.height/frame.height):1;
  const sideFrameWidth=landscape&&frame?Math.max(railWidth,(box.width-frame.width*fit)/2):railWidth;
  const cursorLeft=frame?pointer.x*frame.width*fit:0,cursorTop=frame?pointer.y*frame.height*fit:0;
  return <Modal visible animationType="slide" presentationStyle="fullScreen" supportedOrientations={['portrait','portrait-upside-down','landscape-left','landscape-right']} onRequestClose={onClose}><SafeAreaProvider><SafeAreaView edges={fullScreen||landscape?(avoidCutouts?['top','right','bottom','left']:[]):['top','right','bottom','left']} style={s.safe}><StatusBar hidden={fullScreen||landscape}/><KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
    {!fullScreen&&!landscape&&<View style={s.header}><Pressable accessibilityRole="button" accessibilityLabel="断开并返回" onPress={onClose} hitSlop={12} style={s.back}><ArrowLeft color={c.text} size={22}/></Pressable><View style={{flex:1}}><Text style={s.title}>{name}</Text><Text style={s.caption}>{connecting?'正在连接桌面…':frame?'内置远程桌面 · 已连接':active?'桌面未连接':'已暂停共享'}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="重新连接桌面" onPress={()=>setRevision(v=>v+1)} disabled={connecting} style={s.back}><RefreshCw color={c.green} size={21}/></Pressable></View>}
    {!!error&&(!fullScreen||chrome)&&<View style={s.error}><Text accessibilityRole="alert" style={s.errorText}>{error}</Text></View>}
    <View style={{flex:1,flexDirection:'row'}}><View accessibilityLabel="远程电脑画面" style={[s.screen,Platform.OS==='web'?({touchAction:'none'} as any):null]} onTouchStart={e=>tabletEvent(e,'change')} onTouchMove={e=>tabletEvent(e,'move')} onTouchEnd={e=>tabletEvent(e,'change')} onTouchCancel={()=>{if(tabletRef.current)clearTabletTouch();}} onLayout={e=>{surface.current=e.nativeEvent.layout;setSurfaceRevision(v=>v+1);}} onStartShouldSetResponder={()=>enabled||fullScreen} onMoveShouldSetResponder={()=>enabled||fullScreen} onResponderGrant={begin} onResponderStart={addFinger} onResponderEnd={fingerEnded} onResponderTerminationRequest={()=>false} onResponderMove={move} onResponderRelease={e=>release(e.nativeEvent.locationX,e.nativeEvent.locationY)} onResponderTerminate={()=>{if(tabletRef.current)clearTabletTouch();setDragging(false);clearTimeout(holdTimer.current);if(gesture.current?.dragging)void input({type:'pointerUp'}).catch(()=>{});gesture.current=null;start.current=null;}}>
      {frame?<Animated.View pointerEvents="none" style={{position:'absolute',width:frame.width*fit,height:frame.height*fit,left:(box.width-frame.width*fit)/2,top:!landscape&&toolsOpen?box.height-frame.height*fit:(box.height-frame.height*fit)/2,transform:[{translateX:gestureX},{translateY:gestureY},{scale:gestureZoom}]}}>{rtcVisible&&rtcStream?<RemoteVideo ref={videoView} autoPip={pipEnabled} stream={rtcStream} audio={audioEnabled} microphone={microphone} onSize={videoSize} nativePeerId={nativePeerId} onPip={handlePip}/>:<Image style={{width:'100%',height:'100%'}} resizeMode="contain" source={{uri:`data:${frame.mime||'image/jpeg'};base64,${frame.image}`}} accessibilityLabel="Windows 桌面"/>}</Animated.View>:<View style={{alignItems:'center',gap:16,padding:24}}>{connecting?<ActivityIndicator color={c.green} size="large"/>:<Monitor color={c.muted} size={44}/>}<Text style={[s.caption,{textAlign:'center'}]}>{connecting?'正在读取 Windows 画面':active?'电脑需保持登录并解锁。可点击右上角重连。':'返回前台后重新连接。'}</Text></View>}
      {!rtcReady.current&&rtcVisible&&frame?.image&&<Image source={{uri:`data:${frame.mime||'image/jpeg'};base64,${frame.image}`}} style={{position:'absolute',width:1,height:1,opacity:0}} onLoad={()=>{if(!rtcReady.current)setRtcVisible(false);}}/>}
      {ripple&&!pointerMode&&!virtualMouse&&<Animated.View pointerEvents="none" style={{position:'absolute',left:ripple.x-18,top:ripple.y-18,width:36,height:36,borderRadius:18,borderWidth:10,borderColor:'#B8BBC080',opacity:rippleAnim.interpolate({inputRange:[0,.15,1],outputRange:[0,1,0]}),transform:[{scale:rippleAnim.interpolate({inputRange:[0,1],outputRange:[.25,1.4]})}]}}/>}
      {pointerMode&&showMouseButtons&&control&&!keyboardOpen&&<RemoteMouseButtons input={input} point={()=>pointerRef.current} scale={railScale} rightInset={landscape&&chrome?railWidth:0}/>}
      {virtualMouse&&!pointerMode&&control&&<RemoteVirtualMouse width={surface.current.width} height={surface.current.height} input={input} point={()=>pointerRef.current} onClose={()=>setVirtualMouse(false)} onMove={(x,y)=>{const next=point(x,y);if(next){pointerRef.current=next;setPointer(next);void input({type:'pointerMove',...next}).catch(()=>{});}}}/>}
    </View>
    {landscape&&chrome&&!keyboardOpen&&<View pointerEvents="none" style={{position:'absolute',left:0,top:0,bottom:0,width:sideFrameWidth,backgroundColor:'#12182099',borderRightWidth:1,borderColor:c.line}}/>}
    {landscape&&chrome&&!keyboardOpen&&<View accessibilityLabel="桌面独立右侧工具栏" style={{position:'absolute',right:0,top:0,bottom:0,width:sideFrameWidth,backgroundColor:'#12182099',borderLeftWidth:1,borderColor:c.line,justifyContent:'space-around'}}>{[{label:'操作',icon:RailControls,action:()=>{setPanel('操作');setToolsOpen(v=>!v);}},{label:'键盘',icon:RailKeyboard,action:()=>{setKeyboardOpen(true);setToolsOpen(false);}},{label:'显示桌面',icon:RailDesktop,action:()=>void input({type:'key',key:'showDesktop'}).catch(()=>{})},{label:'展开所有窗口',icon:RailWindows,action:()=>void input({type:'key',key:'taskView'}).catch(()=>{})}].map(item=><Pressable key={item.label} accessibilityRole="button" accessibilityLabel={item.label} onPress={item.action} style={{alignItems:'center',gap:4*railScale,paddingVertical:6*railScale,minHeight:48*railScale,justifyContent:'center'}}><item.icon size={18*railScale} color={c.green}/><Text style={{fontSize:10*railScale,lineHeight:12.5*railScale,color:'#C5CFD8',textAlign:'center'}}>{item.label==='显示桌面'?'显示\n桌面':item.label==='展开所有窗口'?'展开所\n有窗口':item.label}</Text></Pressable>)}</View>}
    </View>
    {dragging&&<View pointerEvents="none" style={{position:'absolute',top:10,left:landscape?railWidth+10:10,paddingHorizontal:12,paddingVertical:5,borderRadius:5,backgroundColor:'#121820B3'}}><Text style={{color:c.text,fontSize:14}}>拖动</Text></View>}


    {toolsOpen&&<View style={{position:landscape?'absolute':'relative',right:landscape?sideFrameWidth:undefined,bottom:landscape?0:undefined,top:landscape?0:undefined,width:landscape?width*.337:'100%',height:landscape?undefined:height*.38,maxHeight:landscape?height:height*.38,backgroundColor:c.surface,borderWidth:1,borderColor:c.line,overflow:'hidden'}}>{panel!=='操作'&&<View style={{flexDirection:'row',alignItems:'center',padding:14,justifyContent:'space-between'}}><Pressable accessibilityLabel={panel==='网络状态'?'返回更多设置':'返回桌面操作'} onPress={()=>setPanel(panel==='网络状态'?'更多':'操作')}><ArrowLeft color={c.text} size={20}/></Pressable><Text style={s.title}>{panel}</Text><Pressable accessibilityLabel="收起工具栏" onPress={()=>setToolsOpen(false)} hitSlop={12}><X color={c.muted} size={20}/></Pressable></View>}<ScrollView contentContainerStyle={{padding:14,gap:14}} keyboardShouldPersistTaps="handled">      {panel==='操作'&&<RemoteOperations hardwareMapping={hardwareMapping} onHardwareMapping={changeHardwareMapping} tabletTouch={tabletTouch} onTabletTouch={value=>void changeTabletTouch(value)} onPip={()=>void startPip()} bytes={stats.bytes} audio={audioEnabled&&rtcVisible} onAudio={value=>void changeAudio(value)} control={control} pointer={pointerMode} virtualMouse={virtualMouse} showMouseButtons={showMouseButtons} onMouseButtons={setShowMouseButtons} onControl={()=>setControl(v=>!v)} onPointer={setPointerMode} onVirtualMouse={v=>{setVirtualMouse(v);setToolsOpen(false);}} onExit={onClose} onFull={()=>{setFullScreen(v=>!v);setToolsOpen(false);}} onRotate={()=>{void rotateRemoteScreen(!landscape).then(()=>{setToolsOpen(false);setView({zoom:1,x:0,y:0});}).catch(e=>setError(friendlyError(e)));}} onPanel={setPanel} onUnavailable={name=>Alert.alert(name,'此功能尚未接入，当前开关不会启用。')}/>}
      {panel!=='操作'&&<RemoteSettings pipEnabled={pipEnabled} onPipEnabled={value=>{setPipEnabled(value);if(!value){void videoView.current?.stopPip?.();}}} qualityMode={qualityMode} onQualityMode={value=>void changeQualityMode(value)} hardwareMapping={hardwareMapping} onHardwareMapping={changeHardwareMapping} peripheralRedirect={peripheralRedirect} onPeripheralRedirect={changePeripheralRedirect} keyPreset={keyPreset} onKeyPreset={setKeyPreset} microphone={microphone&&rtcVisible} onMicrophone={value=>void changeMicrophone(value)} localMute={localMute&&rtcVisible} onLocalMute={value=>void changeLocalMute(value)} privacy={privacy} onPrivacy={value=>void changePrivacy(value)} customBitrate={customBitrate} onBitrate={value=>void changeBitrate(value)} forceRelay={forceRelay} onRelay={value=>void changeRelay(value)} onScaleSettings={()=>void openDisplaySettings()} avoidCutouts={avoidCutouts} onAvoidCutouts={setAvoidCutouts} smartMouse={smartMouse} onSmartMouse={setSmartMouse} colorMode={colorMode} onColorMode={value=>void changeColorMode(value)} frameRate={frameRate} onFrameRate={value=>void changeFrameRate(value)} onPip={()=>void startPip()} nativeGamepad={nativeGamepad} onNativeGamepad={value=>void changeNativeGamepad(value)} gamepad={gamepadEnabled} onGamepad={value=>{if(value){setNativeGamepad(false);setPeripheralRedirect(true);}setGamepadEnabled(value);}} panel={panel} audio={audioEnabled&&rtcVisible} onAudio={value=>void changeAudio(value)} onPanel={setPanel} diagnostics={rtcVisible?videoDiagnostics:null} onPower={onPower} onFiles={onFiles} lockOnEnd={lockOnEnd} onLockOnEnd={changeEndLock} route={rtcRoute} displays={displays} selectedDisplay={selectedDisplay} onDisplay={changeDisplay} quality={quality} onQuality={changeQuality} width={frame?.width||0} height={frame?.height||0} latency={stats.latency} bytes={stats.bytes} hardware={hardwareInputAvailable} hideMs={autoHideMs} onHideMs={setAutoHideMs} onHide={()=>{setToolsOpen(false);setChrome(false);setFullScreen(true);}} onKeyboard={()=>{setKeyboardOpen(true);setToolsOpen(false);}} onSleep={onSleep} onKey={key=>void input({type:'key',key}).catch(()=>{})} onUnavailable={name=>Alert.alert(name,'此功能尚未接入，当前设置不会启用。')} onZoomReset={()=>setView({zoom:1,x:0,y:0})}/>}
    </ScrollView></View>}
    {keyboardOpen&&<RemoteKeyboard onClose={()=>setKeyboardOpen(false)} onInput={input} disabled={!control||!enabled}/>}
    {chrome&&!keyboardOpen&&!landscape&&<View style={landscape?{position:'absolute',right:6,top:8,bottom:8,width:44,borderRadius:18,backgroundColor:'#111C24EB',justifyContent:'space-evenly',alignItems:'center'}:{flexDirection:'row',justifyContent:'space-around',backgroundColor:c.surface,paddingVertical:10,borderTopWidth:1,borderTopColor:c.line}}>{[{label:'操作',icon:SlidersHorizontal,action:()=>{setPanel('操作');setToolsOpen(v=>!v);}}, {label:'键盘',icon:Keyboard,action:()=>{setKeyboardOpen(v=>!v);setToolsOpen(false);}}, {label:'显示桌面',icon:Monitor,action:()=>void input({type:'key',key:'showDesktop'}).catch(()=>{}),disabled:!control},{label:'所有窗口',icon:LayoutGrid,action:()=>void input({type:'key',key:'taskView'}).catch(()=>{}),disabled:!control},{label:fullScreen?'退出全屏':'全屏',icon:fullScreen?Minimize2:Maximize2,action:()=>{setFullScreen(v=>!v);setToolsOpen(false);}}].map(item=><Pressable key={item.label} accessibilityRole="button" accessibilityLabel={item.label} disabled={item.disabled} onPress={item.action} style={{minWidth:40,minHeight:40,gap:4,alignItems:'center',justifyContent:'center',opacity:item.disabled?0.4:1}}><item.icon color={c.green} size={19}/>{!landscape&&<Text style={{color:c.muted,fontSize:9}}>{item.label}</Text>}</Pressable>)}</View>}
    {chrome&&fullScreen&&!keyboardOpen&&<Pressable accessibilityRole="button" accessibilityLabel="断开并返回" onPress={onClose} style={{position:'absolute',left:12,bottom:landscape?12:84,padding:12,borderRadius:14,backgroundColor:'#17212BD9'}}><ArrowLeft color={c.text} size={20}/></Pressable>}

  </KeyboardAvoidingView></SafeAreaView></SafeAreaProvider></Modal>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:c.bg},header:{height:70,paddingHorizontal:16,flexDirection:'row',alignItems:'center',gap:10},back:{width:44,height:44,alignItems:'center',justifyContent:'center'},title:{fontSize:16,color:c.text,fontWeight:'600'},caption:{fontSize:11,color:c.muted,lineHeight:19},screen:{flex:1,minHeight:100,overflow:'hidden',backgroundColor:'#050808',justifyContent:'center',alignItems:'center'},error:{marginHorizontal:16,marginBottom:10,padding:12,borderRadius:12,backgroundColor:'#321F22'},errorText:{fontSize:12,lineHeight:20,color:c.red},tools:{padding:14,gap:10,borderTopWidth:1,borderTopColor:c.line},row:{flexDirection:'row',alignItems:'center',gap:7},button:{minHeight:32,paddingHorizontal:9,borderRadius:11,alignItems:'center',justifyContent:'center',backgroundColor:'#1B2530'},buttonText:{fontSize:11,color:c.text},composer:{flexDirection:'row',gap:10,alignItems:'center',padding:8,borderRadius:14,backgroundColor:'#17212B'},input:{flex:1,minHeight:34,maxHeight:48,color:c.text,fontSize:13,padding:8},send:{width:36,height:36,backgroundColor:c.green,borderRadius:12,alignItems:'center',justifyContent:'center'},hint:{fontSize:10,color:c.muted,textAlign:'center'}});


