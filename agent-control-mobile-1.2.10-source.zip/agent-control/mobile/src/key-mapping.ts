export type KeyPreset='standard'|'mac'|'escape';
export function mappedHardwareKey(code:number,enabled:boolean,preset:KeyPreset){
 if(!enabled)return code;
 if(preset==='mac'&&(code===227||code===231))return code===227?224:228;
 if(preset==='escape'&&code===57)return 41;
 return code;
}
export function createHardwareKeyMapping(enabled:boolean,preset:KeyPreset){
 const held=new Map<number,number>(),counts=new Map<number,number>();
 return {
  update(event:{type:'keyDown'|'keyUp';keyCode:number}){
   if(event.type==='keyDown'){
    if(held.has(event.keyCode))return [];
    const code=mappedHardwareKey(event.keyCode,enabled,preset),count=counts.get(code)||0;
    held.set(event.keyCode,code);counts.set(code,count+1);return count?[]:[{...event,keyCode:code}];
   }
   const code=held.get(event.keyCode);if(code===undefined)return [];
   held.delete(event.keyCode);const count=(counts.get(code)||1)-1;
   if(count){counts.set(code,count);return [];}counts.delete(code);return [{...event,keyCode:code}];
  },
  clear(){held.clear();counts.clear();}
 };
}
