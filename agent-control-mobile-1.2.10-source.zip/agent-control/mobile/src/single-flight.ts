// Share concurrent reads without caching completed history or failed requests.
export function createSingleFlight<T>(){
  const pending=new Map<string,Promise<T>>();
  return (key:string,read:()=>Promise<T>):Promise<T>=>{
    const existing=pending.get(key);if(existing)return existing;
    const result=Promise.resolve().then(read);pending.set(key,result);
    const clear=()=>{if(pending.get(key)===result)pending.delete(key);};
    void result.then(clear,clear);
    return result;
  };
}
