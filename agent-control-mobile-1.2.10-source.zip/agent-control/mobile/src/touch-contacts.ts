export type TouchContact={id:number;x:number;y:number};
// Keep native finger IDs separate from bounded Win32 contact IDs.
export class TouchContacts {
 private ids=new Map<number,number>();
 clear(){this.ids.clear();}
 snapshot(touches:readonly any[],point:(x:number,y:number)=>{x:number;y:number}|null):TouchContact[]{
  const present=new Set(touches.map(t=>t.identifier));
  const rows:TouchContact[]=[];
  for(const t of touches){if(!Number.isInteger(t.identifier))continue;const p=point(t.locationX,t.locationY);if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.y))continue;
   let id=this.ids.get(t.identifier);if(id===undefined){id=Array.from({length:10},(_,i)=>i+1).find(v=>![...this.ids.values()].includes(v));if(id===undefined)continue;this.ids.set(t.identifier,id);}
   rows.push({id,...p});
  }
  for(const id of this.ids.keys())if(!present.has(id))this.ids.delete(id);
  return rows;
 }
}
