import type {Profile,Tab,Thread} from './types';
export const PROFILE_KEY='codex-control.profile.v1';
export const VIEW_KEY='agent-control.last-view.v1';
type LastView={url:string;agentId:string;tab:Tab;thread:Thread|null;filePath:string};
export async function readLastSession(read:(key:string)=>Promise<string|null>):Promise<{profile:Profile;view:LastView|null}|null>{
  const raw=await read(PROFILE_KEY);if(!raw)return null;
  const profile:Profile=JSON.parse(raw);
  if(typeof profile.url!=='string'||typeof profile.token!=='string'||profile.token.length<32)throw new Error('保存的配对信息不完整，请重新配对。');
  let view:LastView|null=null;
  try{const rawView=await read(VIEW_KEY);if(rawView){const saved=JSON.parse(rawView);
    if(saved.url===profile.url&&saved.agentId===(profile.agentId||'codex'))view={url:saved.url,agentId:saved.agentId,tab:['home','sessions','files','activity','settings'].includes(saved.tab)?saved.tab:'home',thread:typeof saved.thread?.id==='string'?saved.thread:null,filePath:typeof saved.filePath==='string'?saved.filePath:''};
  }}catch{/* Keep valid pairing even when navigation could not be restored. */}
  return {profile,view};
}
