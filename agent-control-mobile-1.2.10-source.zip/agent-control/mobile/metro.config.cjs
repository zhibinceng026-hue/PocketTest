const {getDefaultConfig}=require('expo/metro-config');
const fs=require('node:fs'),path=require('node:path');
const config=getDefaultConfig(__dirname);
const modules=fs.realpathSync(path.join(__dirname,'node_modules'));
config.watchFolders=[...(config.watchFolders||[]),modules];
config.resolver.nodeModulesPaths=[path.join(__dirname,'node_modules'),modules];
if(config.transformer.asyncRequireModulePath)config.transformer.asyncRequireModulePath=fs.realpathSync(require.resolve(config.transformer.asyncRequireModulePath));
config.resolver.resolveRequest=(context,name,platform)=>{const result=context.resolveRequest(context,name,platform);if(result.type==='sourceFile'&&!result.filePath.includes('\0')&&fs.existsSync(result.filePath))result.filePath=fs.realpathSync(result.filePath);return result;};
module.exports=config;
