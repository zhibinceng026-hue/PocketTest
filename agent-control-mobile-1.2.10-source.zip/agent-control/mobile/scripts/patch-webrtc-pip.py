#!/usr/bin/env python3
"""Strict, offline patch for the exact npm react-native-webrtc 155.0.1 package."""
import argparse
import hashlib
import json
from pathlib import Path

BASE = {
    'ios/RCTWebRTC/DataChannelWrapper.h': '2b4b523b01fc3d59e7ac040ef54de95e3dffc1a370a67308a345431d470b434c',
    'ios/RCTWebRTC/WebRTCModule+RTCDataChannel.m': '331773504d3a7f7d8751eb167a383704392f98332f977a0c888663fcaad1b443',
    'ios/RCTWebRTC/WebRTCModule+RTCPeerConnection.h': '0a1ba437a83c14cd47d04be21c18e82483efe7000167b9d32d8184aed1e5562a',
    'package.json': 'c76c65a2c19d657465516c601748c4f78b90b48da0990eb2e6ce53d061c35014',
    'ios/RCTWebRTC/PIPController.h': '54b0d26f9aab7120fa3d524d7ce34d2ec9e415e79ff049f8c680853f9209295b',
    'ios/RCTWebRTC/PIPController.m': 'fdd5e9ad71d401e668e76b3d8514e291627548dd21f88f48eded79dae74843b8',
    'ios/RCTWebRTC/RTCVideoViewManager.m': 'acec2403fc734fe40d4f7c557156ae7aa0fe7a66408c8e64d8780d11bc265c08',
    'ios/RCTWebRTC/WebRTCModule.h': 'd1a4d0e077ac32a94bffb5f505a75849e56313ab430b80a14fe2ee51a386c0c7',
    'ios/RCTWebRTC/WebRTCModule.m': '67494a4494e58f7fd35032ef0c5925a6acd9e7ec68254f69a6147a78cb64bcd0',
    'ios/RCTWebRTC/WebRTCModule+RTCPeerConnection.m': 'ba41fa2fcac30988a6cbb856bc1b9687d3ee607517e8b936d66acc7079157700',
    'src/RTCView.ts': '6b93840bb6969398959a647286564fc5f163a408bed2e69cc1363de16da7cba1',
    'lib/typescript/RTCView.d.ts': '7191b861a35f8444a504520463b75fa33a9d76976bc8b85cb195840c70964c9f',
}

# Exact old/new pairs also act as a reversible, independently verified patch format.
EDITS = {}


def edit(file, old, new):
    EDITS.setdefault(file, []).append((old, new))


H = 'ios/RCTWebRTC/PIPController.h'
M = 'ios/RCTWebRTC/PIPController.m'
V = 'ios/RCTWebRTC/RTCVideoViewManager.m'
edit(H, '@property(nonatomic, weak) UIView *sourceView;', '''@property(nonatomic, copy) void (^onPipStateChange)(NSDictionary *event);
@property(nonatomic, assign) BOOL restoringUI;
@property(nonatomic, weak) UIView *sourceView;''')
edit(M, '- (void)togglePIP {', '''- (void)emitPipState:(NSString *)state error:(NSError *)error {
    NSAssert([NSThread isMainThread], @"PiP delegate must run on main thread");
    if (self.onPipStateChange) {
        NSMutableDictionary *event = [@{
            @"state": state,
            @"background": @([UIApplication sharedApplication].applicationState == UIApplicationStateBackground),
            @"restoringUI": @(self.restoringUI)
        } mutableCopy];
        if (error) {
            event[@"error"] = @{@"domain": error.domain, @"code": @(error.code),
                                @"message": error.localizedDescription ?: @""};
        }
        self.onPipStateChange(event);
    }
}

- (void)togglePIP {''')
# Match complete methods, never repeated NSLog statements alone.
for selector, state in [
    ('WillStart', 'willStart'), ('DidStart', 'didStart'),
    ('WillStop', 'willStop'), ('DidStop', 'didStop'),
]:
    signature = f'- (void)pictureInPictureController{selector}PictureInPicture:(AVPictureInPictureController *)pictureInPictureController {{'
    old = signature + '\n    NSLog(@"%@", NSStringFromSelector(_cmd));  // Objective-C\n}'
    reset = '    self.restoringUI = NO;\n' if state == 'willStart' else ''
    edit(M, old, signature + '\n' + reset + f'    [self emitPipState:@"{state}" error:nil];\n' + '}')
edit(M, '    NSLog(@"%@: %@", NSStringFromSelector(_cmd), [error localizedDescription]);  // Objective-C',
     '    [self emitPipState:@"failedToStart" error:error];')
edit(M, '''    restoreUserInterfaceForPictureInPictureStopWithCompletionHandler:(void (^)(BOOL restored))completionHandler {
    NSLog(@"%@", NSStringFromSelector(_cmd));  // Objective-C
}''', '''    restoreUserInterfaceForPictureInPictureStopWithCompletionHandler:(void (^)(BOOL restored))completionHandler {
    self.restoringUI = YES;
    [self emitPipState:@"restoreRequested" error:nil];
    // JS delivery is asynchronous; no native UI restoration has been performed.
    completionHandler(NO);
}''')

edit(V, '@property(nonatomic, copy) RCTDirectEventBlock onDimensionsChange;', '''@property(nonatomic, copy) RCTDirectEventBlock onPipStateChange;
@property(nonatomic, copy) NSNumber *pipPeerConnectionId;
@property(nonatomic, copy) RCTDirectEventBlock onDimensionsChange;''')
edit(V, '    if (!_pipController) {\n        _pipController = [[PIPController alloc] initWithSourceView:self];', '''    id requestedId = pipOptions[@"peerConnectionId"];
    NSNumber *peerId = nil;
    if (requestedId && requestedId != [NSNull null]) {
        if (![requestedId isKindOfClass:[NSNumber class]] ||
            CFGetTypeID((__bridge CFTypeRef)requestedId) == CFBooleanGetTypeID() ||
            !isfinite([requestedId doubleValue]) || [requestedId doubleValue] < 0 ||
            floor([requestedId doubleValue]) != [requestedId doubleValue] ||
            [requestedId doubleValue] > 9007199254740991.0) {
            RCTLogError(@"PiP peerConnectionId must be a nonnegative safe integer");
            return;
        }
        peerId = requestedId;
    }
    if (_pipController && ![_pipPeerConnectionId isEqual:peerId] && (_pipPeerConnectionId || peerId)) {
        RCTLogError(@"PiP binding is immutable: disable PiP before binding a different peer");
        return;
    }
    if (!_pipController) {
        _pipPeerConnectionId = [peerId copy];
        WebRTCModule *module = self.module;
        if (!module || !module.workerQueue) {
            RCTLogError(@"PiP requires an initialized WebRTCModule");
            return;
        }
        // Resolve exactly once, on the module queue. Never infer from a stream or enumerate peers.
        __block RTCPeerConnection *boundPeer = nil;
        __block BOOL closeIssued = NO;
        ACPipHeartbeat *heartbeat = [ACPipHeartbeat new];
        heartbeat.module = module;
        heartbeat.peerId = peerId;
        dispatch_async(module.workerQueue, ^{
            if (peerId) boundPeer = module.peerConnections[peerId];
            heartbeat.peer = boundPeer;
        });
        __weak RTCVideoView *weakView = self;
        _pipController = [[PIPController alloc] initWithSourceView:self];
        _pipController.onPipStateChange = ^(NSDictionary *event) {
            BOOL terminal = [event[@"state"] isEqual:@"didStop"] || [event[@"state"] isEqual:@"failedToStart"];
            BOOL shouldClose = terminal && [event[@"background"] boolValue] && ![event[@"restoringUI"] boolValue];
            dispatch_async(module.workerQueue, ^{
                if ([event[@"state"] isEqual:@"didStart"]) [heartbeat start];
                if ([event[@"state"] isEqual:@"willStop"] || terminal) [heartbeat stop];
                NSString *closeResult = @"notRequested";
                if (shouldClose) {
                    if (!peerId) closeResult = @"unbound";
                    else if (!boundPeer) closeResult = @"peerMissingAtBinding";
                    else if (module.peerConnections[peerId] != boundPeer) closeResult = @"bindingChanged";
                    else if (closeIssued) closeResult = @"alreadyIssued";
                    else {
                        // Same operation as WebRTCModule+RTCPeerConnection peerConnectionClose.
                        [boundPeer close];
                        closeIssued = YES;
                        closeResult = @"closeIssued";
                    }
                }
                NSMutableDictionary *payload = [event mutableCopy];
                payload[@"peerConnectionId"] = peerId ?: (id)[NSNull null];
                payload[@"nativeCloseResult"] = closeResult;
                dispatch_async(dispatch_get_main_queue(), ^{
                    RTCVideoView *view = weakView;
                    if (view.onPipStateChange) view.onPipStateChange(payload);
                });
            });
        };''')
edit(V, '#import <objc/runtime.h>', '#import <objc/runtime.h>\n#import <math.h>')
edit(V, 'RCT_EXPORT_VIEW_PROPERTY(onDimensionsChange, RCTDirectEventBlock)',
     'RCT_EXPORT_VIEW_PROPERTY(onDimensionsChange, RCTDirectEventBlock)\nRCT_EXPORT_VIEW_PROPERTY(onPipStateChange, RCTDirectEventBlock)')


# Native heartbeat: public React category / DataChannelWrapper API only.
edit(V, '#import "WebRTCModule.h"', '''#import "WebRTCModule.h"
#import "WebRTCModule+RTCPeerConnection.h"

// All mutable state and sends are confined to module.workerQueue.
@interface ACPipHeartbeat : NSObject
@property(nonatomic, weak) WebRTCModule *module;
@property(nonatomic, weak) RTCPeerConnection *peer;
@property(nonatomic, copy) NSNumber *peerId;
@property(nonatomic, strong) dispatch_source_t timer;
@property(nonatomic, strong) id observer;
- (void)stop;
- (void)start;
@end

@implementation ACPipHeartbeat
- (void)stop {
    if (self.timer) {
        dispatch_source_cancel(self.timer);
        self.timer = nil;
    }
}
- (void)start {
    [self stop];
    WebRTCModule *module = self.module;
    RTCPeerConnection *peer = self.peer;
    if (!module || !peer || module.peerConnections[self.peerId] != peer ||
        peer.connectionState != RTCPeerConnectionStateConnected) return;
    __weak ACPipHeartbeat *weakSelf = self;
    if (!self.observer) {
        self.observer = [[NSNotificationCenter defaultCenter]
            addObserverForName:@"ACPipPeerConnectionState" object:peer queue:nil
            usingBlock:^(NSNotification *note) {
                // Posted synchronously on workerQueue, including transient disconnects.
                if ([note.userInfo[@"state"] integerValue] != RTCPeerConnectionStateConnected)
                    [weakSelf stop];
            }];
    }
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, module.workerQueue);
    dispatch_source_set_timer(self.timer, dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC),
                              5 * NSEC_PER_SEC, 100 * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(self.timer, ^{
        ACPipHeartbeat *owner = weakSelf;
        if (!owner) return;
        WebRTCModule *module = owner.module;
        RTCPeerConnection *peer = owner.peer;
        if (!module || !peer || module.peerConnections[owner.peerId] != peer ||
            peer.connectionState != RTCPeerConnectionStateConnected) {
            [owner stop];
            return;
        }
        RTCDataChannel *channel = nil;
        for (DataChannelWrapper *wrapper in peer.dataChannels.allValues) {
            if (![wrapper isKindOfClass:[DataChannelWrapper class]]) { [owner stop]; return; }
            if (![wrapper.channel.label isEqualToString:@"agent-control"]) continue;
            // Fail closed for ambiguous labels or a wrapper belonging to another peer.
            if (channel || ![wrapper.pcId isEqual:owner.peerId]) { [owner stop]; return; }
            channel = wrapper.channel;
        }
        if (!channel || channel.readyState != RTCDataChannelStateOpen) { [owner stop]; return; }
        // Process-wide reserved JS-safe IDs; serialize across module instances too.
        static uint64_t nextId = 1000000000000ULL;
        NSNumber *pingId;
        @synchronized([ACPipHeartbeat class]) {
            if (nextId > 9007199254740991ULL) { [owner stop]; return; }
            pingId = @(nextId++);
        }
        NSData *data = [NSJSONSerialization dataWithJSONObject:
            @{@"id": pingId, @"type": @"ping"} options:0 error:NULL];
        if (!data || ![channel sendData:[[RTCDataBuffer alloc] initWithData:data isBinary:NO]])
            [owner stop];
    });
    dispatch_resume(self.timer);
}
- (void)dealloc {
    // The event handler and notification block hold only weak references to this owner.
    if (_timer) dispatch_source_cancel(_timer);
    if (_observer) [[NSNotificationCenter defaultCenter] removeObserver:_observer];
}
@end
''')
edit('ios/RCTWebRTC/WebRTCModule+RTCPeerConnection.m', '- (void)peerConnection:(RTCPeerConnection *)peerConnection didChangeConnectionState:(RTCPeerConnectionState)newState {\n    dispatch_async(self.workerQueue, ^{', '- (void)peerConnection:(RTCPeerConnection *)peerConnection didChangeConnectionState:(RTCPeerConnectionState)newState {\n    dispatch_async(self.workerQueue, ^{\n        [[NSNotificationCenter defaultCenter] postNotificationName:@"ACPipPeerConnectionState"\n            object:peerConnection userInfo:@{@"state": @(newState)}];')

EVENT_TYPE = '''
/** iOS native lifecycle notification. closeIssued means close() was invoked, not ICE completion. */
export interface RTCPipStateEvent {
  state: 'willStart' | 'didStart' | 'willStop' | 'didStop' | 'failedToStart' | 'restoreRequested';
  background: boolean;
  restoringUI: boolean;
  peerConnectionId: number | null;
  nativeCloseResult: 'notRequested' | 'unbound' | 'peerMissingAtBinding' | 'bindingChanged' | 'alreadyIssued' | 'closeIssued';
  error?: { domain: string; code: number; message: string };
}
'''
for file in ['src/RTCView.ts', 'lib/typescript/RTCView.d.ts']:
    edit(file, 'export interface RTCVideoViewProps extends ViewProps {',
         EVENT_TYPE + '\nexport interface RTCVideoViewProps extends ViewProps {\n  onPipStateChange?: (event: { nativeEvent: RTCPipStateEvent }) => void;')
    edit(file, 'export interface RTCIOSPIPOptions {', '''export interface RTCIOSPIPOptions {
  /** Explicit native ID; immutable until PiP is disabled/recreated. Omit for events only. */
  peerConnectionId?: number;''')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def replace_once(text, old, new, label):
    if text.count(old) != 1:
        raise ValueError(f'Context mismatch: {label}')
    return text.replace(old, new, 1)


def prepare(root):
    """Preflight every file before any write; accept only pristine or fully patched."""
    root = Path(root).resolve(strict=True)
    originals = {}
    outputs = {}
    states = set()
    for name, expected in BASE.items():
        path = root / name
        if path.is_symlink() or not path.resolve(strict=True).is_relative_to(root):
            raise ValueError(f'Package path escapes root: {name}')
        data = path.read_bytes()
        originals[name] = data
        if digest(data) == expected:
            states.add('original') if name in EDITS else None
            text = data.decode('utf-8')
        elif name in EDITS:
            text = data.decode('utf-8')
            for old, new in reversed(EDITS[name]):
                text = replace_once(text, new, old, name)
            if digest(text.encode('utf-8')) != expected:
                raise ValueError(f'Source fingerprint mismatch: {name}')
            states.add('patched')
        else:
            raise ValueError(f'Source fingerprint mismatch: {name}')
        for old, new in EDITS.get(name, []):
            text = replace_once(text, old, new, name)
        outputs[name] = text.encode('utf-8')
    if len(states) != 1:
        raise ValueError('Mixed/partial patch state; restore the complete pristine package first')
    meta = json.loads(originals['package.json'])
    if meta['name'] != 'react-native-webrtc' or meta['version'] != '155.0.1':
        raise ValueError('Expected npm react-native-webrtc 155.0.1')
    return root, originals, outputs, states.pop()


def patch(root, check=False):
    root, originals, outputs, state = prepare(root)
    changed = [name for name in EDITS if originals[name] != outputs[name]]
    if not check:
        # Roll back completed writes on ordinary I/O errors (not crash-atomic).
        attempted = []
        try:
            for name in changed:
                attempted.append(name)
                (root / name).write_bytes(outputs[name])
        except OSError:
            for name in attempted:
                (root / name).write_bytes(originals[name])
            raise
    return {'state': state, 'check': check, 'files': changed}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package_root', type=Path, help='Explicit extracted package root; no auto-discovery')
    parser.add_argument('--check', action='store_true', help='Validate and report without writing')
    args = parser.parse_args()
    try:
        print(json.dumps(patch(args.package_root, args.check), indent=2))
    except (OSError, ValueError, KeyError) as exc:
        parser.exit(1, f'PiP patch refused: {exc}\n')
