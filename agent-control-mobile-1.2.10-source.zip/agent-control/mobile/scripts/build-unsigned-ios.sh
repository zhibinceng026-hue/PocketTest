#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
export CI=1 EXPO_NO_TELEMETRY=1
mkdir -p build dist
xcodebuild -version
node --version
pnpm exec tsc --noEmit
webrtc_root=$(node -p "require('path').dirname(require.resolve('react-native-webrtc/package.json'))")
python3 scripts/patch-webrtc-pip.py "$webrtc_root"
pnpm exec expo prebuild --platform ios --no-install 2>&1 | tee build/prebuild.log
test -s modules/remote-input/ios/RemoteInputModule.swift
test -s modules/remote-input/ios/RemoteInput.podspec
pod install --project-directory=ios 2>&1 | tee build/pods.log
grep -q 'RemoteInput' ios/Podfile.lock || { echo 'Required RemoteInput native module was not linked'; exit 1; }
workspace=$(find ios -maxdepth 1 -name '*.xcworkspace' -type d -print -quit)
test -n "$workspace"
scheme="$(basename "$workspace" .xcworkspace)"
xcodebuild build -workspace "$workspace" -scheme "$scheme" \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath build/device \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= \
  2>&1 | tee build/device-build.log
app=$(find build/device/Build/Products/Release-iphoneos -maxdepth 1 -name '*.app' -type d -print -quit)
test -n "$app"
test -s "$app/main.jsbundle"
APP_NATIVE_CHECK="$app" python3 - <<'PY'
import os,plistlib
from pathlib import Path
app=Path(os.environ['APP_NATIVE_CHECK'])
info=plistlib.loads((app/'Info.plist').read_bytes())
binary=(app/info['CFBundleExecutable']).read_bytes()
for symbol in [b'AgentRemoteInput',b'RemoteInputModule',b'configureRemotePlayback']:
    assert symbol in binary, 'Required native capability missing: '+symbol.decode()
assert 'AsyncFunction("rotateScreen")' in Path('modules/remote-input/ios/RemoteInputModule.swift').read_text()
print('RemoteInput implementation and registration verified; native class and playback method present in device binary')
PY
plutil -lint "$app/Info.plist"
binary=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$app/Info.plist")
lipo -archs "$app/$binary" | grep -q arm64
test "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$app/Info.plist")" = '1.2.10'
staging=$(mktemp -d "${TMPDIR:-/tmp}/agentcontrol-ipa.XXXXXX")
trap 'rm -rf "$staging"' EXIT
mkdir -p "$staging/Payload"
ditto "$app" "$staging/Payload/$(basename "$app")"
ditto -c -k --norsrc --keepParent "$staging/Payload" dist/Agent-Control-1.2.10-unsigned.ipa
unzip -t dist/Agent-Control-1.2.10-unsigned.ipa
shasum -a 256 dist/Agent-Control-1.2.10-unsigned.ipa > dist/SHA256SUMS.txt
printf '%s\n' 'Device ARM64 Release IPA, with embedded JS bundle. User-side signing and iPhone verification remain required.' > dist/BUILD-NOTES.txt
