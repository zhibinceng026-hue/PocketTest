# 真机 IPA 1.1

当前版本为 1.1.0、build 2，包含扫码命名电脑、图片上传、折叠执行详情、中文错误说明，保留多智能体及原有模块。构建已成功：https://github.com/zhibinceng026-hue/PocketTest/actions/runs/41171950906 。签名、安装与新版真机交互仍需用户设备验收。

`scripts/build-unsigned-ios.sh` 在 macOS/Xcode 上执行：生成原生工程、安装 CocoaPods、为真机 arm64 编译 Release、验证内置 JS bundle，再生成 `dist/Agent-Control-1.1.0-unsigned.ipa` 和 SHA256。

该 IPA 用于由用户通过 iLoader/SideStore 等现有工具签名。它不是模拟器 .app，不需要开发电脑提供 Apple 证书；签名、安装、启动、扫码及权限仍需分别验收。

GitHub 工作流位于项目 `.github/workflows/build-agent-control-ios.yml`。上传到既有 PocketTest 仓库时，工作流先解压根目录的 `agent-control-mobile-1.1.0-source.zip`，手机源码展开到 `agent-control/mobile/`，使用 `agent-control-v1-*` 分支；原有 PocketTest 和 SideStore 工程不必改动。工作流使用 macos-26、Xcode 26.6（若已安装），只读仓库权限，不自动发布 Release。

本地 Mac：先安装 Node.js 24、pnpm 11.25.0、CocoaPods 和兼容 Xcode，然后在本文件所在目录执行 `pnpm install --frozen-lockfile`、`bash scripts/build-unsigned-ios.sh`。

最低 iOS 版本由当前 Expo SDK 57 原生模板决定（官方文档为 16.4+）。不能仅通过 Windows JavaScript bundle 成功来判定 IPA 已编译成功。
