import React from 'react';
import {ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View} from 'react-native';
import {ArrowUp, Plus, Square} from 'lucide-react-native';
import {colors as c} from './theme';

type Props = {
  text: string; onText: (value: string) => void; hasImages: boolean;
  sending: boolean; running: boolean; stopping: boolean; canSteer: boolean; canStop: boolean;
  onSend: () => void; onStop: () => void; onImages: () => void;
};
export function ChatComposer(p: Props) {
  const blocked = p.sending || p.stopping || (!p.text.trim() && !p.hasImages) || (p.running && !p.canSteer);
  return <>
    <View style={s.composer}>
      <Pressable accessibilityRole="button" accessibilityLabel="添加图片" disabled={p.sending} onPress={p.onImages} style={[s.add, p.sending && s.disabled]}><Plus size={24} color={c.green}/></Pressable>
      <TextInput accessibilityLabel="给当前智能体发送消息" value={p.text} onChangeText={p.onText} multiline maxLength={8000} placeholder={p.running ? '补充要求，直接插话…' : '告诉智能体下一步做什么…'} placeholderTextColor="#6B7A87" style={s.input}/>
      <View style={s.actions}>
        {p.running && p.canStop && <Pressable accessibilityRole="button" accessibilityLabel="停止当前任务" accessibilityState={{disabled:p.stopping}} onPress={p.onStop} disabled={p.stopping} style={[s.action, s.stop, p.stopping && s.disabled]}>
          {p.stopping ? <ActivityIndicator size="small" color={c.red}/> : <Square size={18} color={c.red} fill={c.red}/>}
          <Text style={[s.label, {color:c.red}]}>{p.stopping ? '停止中' : '停止'}</Text>
        </Pressable>}
        <Pressable accessibilityRole="button" accessibilityLabel={p.running ? '插话发送' : '发送消息'} accessibilityState={{disabled:blocked}} style={[s.action, s.send, blocked && s.disabled]} onPress={p.onSend} disabled={blocked}>
          {p.sending ? <ActivityIndicator size="small" color={c.bg}/> : <ArrowUp size={22} color={c.bg}/>}
          <Text style={[s.label, {color:c.bg}]}>{p.running ? '插话' : '发送'}</Text>
        </Pressable>
      </View>
    </View>
    {p.running && <Text style={s.hint}>{p.stopping ? '正在等待任务停止确认…' : p.canSteer ? '正在执行 · 可直接补充要求，无需先停止' : '此智能体暂不支持插话，请等待本轮结束或停止任务'}</Text>}
  </>;
}
const s = StyleSheet.create({
  composer:{backgroundColor:'#17212B',borderWidth:1,borderColor:'#34433F',borderRadius:18,padding:8,flexDirection:'row',alignItems:'flex-end',gap:6},
  add:{width:36,height:50,alignItems:'center',justifyContent:'center'},
  input:{color:c.text,fontSize:14,lineHeight:23,maxHeight:120,minHeight:50,flex:1,paddingTop:12,paddingBottom:10},
  actions:{flexDirection:'row',gap:6},
  action:{minWidth:48,minHeight:52,borderRadius:13,alignItems:'center',justifyContent:'center',gap:2,paddingHorizontal:7},
  send:{backgroundColor:c.green},stop:{backgroundColor:'#3A2427',borderWidth:1,borderColor:'#774049'},
  label:{fontSize:10,fontWeight:'700'},disabled:{opacity:0.4},
  hint:{color:c.muted,fontSize:11,lineHeight:18,textAlign:'center',marginTop:8},
});
