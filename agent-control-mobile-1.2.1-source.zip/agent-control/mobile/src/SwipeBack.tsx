import React,{useRef} from 'react';
import {Keyboard,Platform,StyleSheet,View,type GestureResponderEvent,type ViewStyle} from 'react-native';

// Observe edge touches without moving the page or competing for ScrollView's
// responder. This also works inside horizontal file previews and native modals.
export function SwipeBack({enabled,onBack,children}:{enabled:boolean;onBack:()=>void;children:React.ReactNode}){
  const touch=useRef<{id:string;x:number;y:number;vertical:number}|null>(null);
  const start=(e:GestureResponderEvent)=>{const points=e.nativeEvent.touches;if(!enabled||points.length!==1){touch.current=null;return;}const p=points[0];if(!p)return;touch.current=p.pageX<=44?{id:String(p.identifier),x:p.pageX,y:p.pageY,vertical:0}:null;};
  const move=(e:GestureResponderEvent)=>{const current=touch.current;if(!current)return;if(e.nativeEvent.touches.length!==1){touch.current=null;return;}const p=e.nativeEvent.touches[0];if(!p)return;current.vertical=Math.max(current.vertical,Math.abs(p.pageY-current.y));};
  const end=(e:GestureResponderEvent)=>{const current=touch.current;touch.current=null;if(!enabled||!current)return;const p=Array.from(e.nativeEvent.changedTouches).find(p=>String(p.identifier)===current.id);if(!p)return;const dx=p.pageX-current.x,dy=Math.max(Math.abs(p.pageY-current.y),current.vertical);if(dx>=80&&dx>dy*1.7){Keyboard.dismiss();onBack();}};
  const web=Platform.OS==='web'?({touchAction:'pan-y'} as unknown as ViewStyle):undefined;
  return <View style={[s.surface,web]} onTouchStart={start} onTouchMove={move} onTouchEnd={end} onTouchCancel={()=>{touch.current=null;}}>{children}</View>;
}
const s=StyleSheet.create({surface:{flex:1,minHeight:0,minWidth:0,width:'100%',alignSelf:'stretch'}});
