export function friendlyError(error:unknown):string{
  const message=error instanceof Error?error.message:String(error||'');
  if(/authentication required|claude.*(?:login|sign.?in)|not logged in/i.test(message))return 'Claude Code 尚未完成登录，请在电脑端完成 Claude 接口登录后重试。';
  if(/ACCOUNT_SIGN_IN_REQUIRED|ACCOUNT_TOKEN_INVALID/i.test(message))return 'DeepSeek 桌面账号尚未登录或登录已失效，请在电脑上的 DeepSeek Harness 重新登录。';
  if(/no API key|MISSING_CREDENTIAL|DEEPSEEK_API_KEY/i.test(message))return 'DeepSeek 当前接口缺少模型凭据。请升级电脑端，重新扫描并选择桌面账号接口。';
  if(/authentication failures|配对尝试过于频繁|PAIRING_RATE_LIMIT/i.test(message))return '配对尝试过于频繁，请核对配对令牌；这不是模型额度不足。';
  if(/401|unauthorized|invalid.*token|令牌无效/i.test(message))return '配对信息已失效，请重新扫描电脑上的配对码。';
  if(/403|permission denied|access denied|outside.*workspace|not permitted|EACCES|EPERM/i.test(message))return '当前操作没有权限，请检查电脑端授权目录或批准所需权限。';
  if(/abort|cancelled|canceled|timed?\s*out|timeout/i.test(message))return '连接超时或已中断。请确认电脑服务正在运行，并检查 Wi-Fi 或私有 VPN。';
  if(/fetch failed|failed to fetch|network request failed|could not connect|ECONNREFUSED|ENETUNREACH|EHOSTUNREACH/i.test(message))return '暂时连接不到电脑。请确认连接地址正确，电脑服务已启动，并处于同一局域网或私有 VPN。';
  if(/list_turns|unknown variant|invalid request|method not found|unsupported method/i.test(message))return '智能体接口暂不兼容，请更新电脑端后重新连接。';
  if(/too large|413|exceeds.*(?:limit|MB)/i.test(message))return '文件超过大小限制。每张图片最多 8 MB，每条消息最多 4 张。';
  if(/ENOENT|spawn.*failed|not found|could not find home|process exited|connection closed/i.test(message))return '电脑端智能体暂不可用，请检查安装路径和登录状态，再重启连接服务。';
  if(/\b429\b|rate.?limit|quota|usage limit|usageLimitExceeded/i.test(message))return '智能体请求频率或账户额度受限，请稍后重试，并查看实时额度。';
  if(/image.*(?:decode|load)|unable.*image|failed.*image/i.test(message))return '无法读取这张图片，请重新选择图片后再试。';
  if(/[\u3400-\u9fff]/.test(message))return message;
  return '操作未完成，请稍后重试。若仍失败，请重新连接电脑，并查看诊断详情。';
}
export function diagnosticText(error:unknown,token=''):string{
  let text=error instanceof Error?error.message:String(error||'');
  if(token)text=text.split(token).join('[已隐藏令牌]');
  return text.replace(/Bearer\s+[A-Za-z0-9._~-]+/gi,'Bearer [已隐藏令牌]').slice(0,12000);
}
