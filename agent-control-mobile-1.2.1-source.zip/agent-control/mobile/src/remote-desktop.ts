export const rustDeskStoreUrl='https://apps.apple.com/app/id1581225015';

export function rustDeskId(value:string|undefined){
  const id=(value||'').replace(/[\s-]/g,'');
  if(!id)throw new Error('请先保存这台 Windows 电脑的 RustDesk ID。');
  if(!/^\d{6,16}$/.test(id))throw new Error('RustDesk ID 应为 6 至 16 位数字；空格会自动去掉。');
  return id;
}

export async function launchRustDesk(value:string|undefined,linking:{canOpenURL:(url:string)=>Promise<boolean>;openURL:(url:string)=>Promise<unknown>},timeout=8000){
  const id=rustDeskId(value);
  let timer:ReturnType<typeof setTimeout>|undefined;
  try{
    await Promise.race([
      (async()=>{
        const url=`rustdesk://connection/new/${id}`;
        if(!await linking.canOpenURL(url))throw new Error('未能唤起 RustDesk。请先在 iPhone 安装 RustDesk，或直接在 RustDesk 中输入下方电脑 ID。');
        try{await linking.openURL(url);}catch{throw new Error('打开 RustDesk 失败。请复制电脑 ID，在 RustDesk 中手动连接。');}
      })(),
      new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(new Error('等待 RustDesk 响应超时。请复制电脑 ID，在 RustDesk 中手动连接。')),timeout);})
    ]);
  }finally{if(timer)clearTimeout(timer);}
}
