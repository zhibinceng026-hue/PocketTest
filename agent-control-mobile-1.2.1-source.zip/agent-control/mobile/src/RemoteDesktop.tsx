import React,{useEffect,useRef,useState} from 'react';
import {ActivityIndicator,AppState,Image,KeyboardAvoidingView,Modal,Platform,Pressable,ScrollView,StyleSheet,Text,TextInput,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {ArrowLeft,MousePointer2,Monitor,RefreshCw,Send} from 'lucide-react-native';
import {request} from './api';
import {friendlyError} from './errors';
import {colors as c} from './theme';
import type {Profile} from './types';

type Frame={image:string;width:number;height:number;cursorX:number;cursorY:number};
type Mode='click'|'rightClick'|'doubleClick'|'drag';
const modes:{id:Mode;label:string}[]=[{id:'click',label:'点击'},{id:'rightClick',label:'右键'},{id:'doubleClick',label:'双击'},{id:'drag',label:'拖动'}];
function Button({label,onPress,disabled=false}:{label:string;onPress:()=>void;disabled?:boolean}){return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} disabled={disabled} style={[s.button,disabled&&{opacity:.35}]}><Text style={s.buttonText}>{label}</Text></Pressable>;}

export function RemoteDesktop({profile,name,onClose}:{profile:Profile;name:string;onClose:()=>void}){
  const [frame,setFrame]=useState<Frame|null>(null),[error,setError]=useState(''),[connecting,setConnecting]=useState(true),[control,setControl]=useState(false),[mode,setMode]=useState<Mode>('click'),[text,setText]=useState(''),[sending,setSending]=useState(false),[revision,setRevision]=useState(0),[active,setActive]=useState(AppState.currentState==='active');
  const session=useRef<string|null>(null),busy=useRef(false),surface=useRef({width:0,height:0}),start=useRef<{x:number;y:number}|null>(null),mounted=useRef(true);
  useEffect(()=>{const sub=AppState.addEventListener('change',state=>setActive(state==='active'));return ()=>sub.remove();},[]);
  useEffect(()=>()=>{mounted.current=false;},[]);
  useEffect(()=>{
    let alive=true,timer:ReturnType<typeof setTimeout>|undefined;const abort=new AbortController();let owned:string|null=null;
    setFrame(null);setControl(false);setError('');setConnecting(active);
    function update(value:Frame){if(!value||!Number.isInteger(value.width)||!Number.isInteger(value.height)||value.width<1||value.width>1280||value.height<1||value.height>800||typeof value.image!=='string'||value.image.length>3000000)throw new Error('电脑返回的桌面画面无效，请重新连接。');if(alive)setFrame(value);}
    async function poll(){if(!alive||!owned)return;try{update(await request(profile,`/api/desktop/frame?session=${encodeURIComponent(owned)}`,{signal:abort.signal}));if(alive){setError('');timer=setTimeout(()=>void poll(),500);}}catch(e){if(alive){setFrame(null);setControl(false);setError(friendlyError(e));}}}
    if(active)void (async()=>{try{
      const value=await request<Frame&{sessionId:string}>(profile,'/api/desktop/session',{method:'POST',body:{confirm:'VIEW'},signal:abort.signal});owned=value.sessionId;
      if(!alive){void request(profile,'/api/desktop/session',{method:'DELETE',body:{sessionId:owned}}).catch(()=>{});return;}
      session.current=owned;update(value);setConnecting(false);timer=setTimeout(()=>void poll(),500);
    }catch(e){if(alive){setConnecting(false);setError(friendlyError(e));}}})();
    return ()=>{alive=false;if(timer)clearTimeout(timer);abort.abort();session.current=null;if(owned)void request(profile,'/api/desktop/session',{method:'DELETE',body:{sessionId:owned}}).catch(()=>{});};
  },[profile.url,profile.token,revision,active]);
  async function input(value:unknown){
    const id=session.current;if(!control||!id||busy.current||!frame||!active)return;
    busy.current=true;setSending(true);setError('');
    try{await request(profile,'/api/desktop/input',{method:'POST',body:{sessionId:id,input:value}});}
    catch(e){if(mounted.current)setError(friendlyError(e));throw e;}
    finally{busy.current=false;if(mounted.current)setSending(false);}
  }
  function point(x:number,y:number){if(!frame)return null;const box=surface.current,scale=Math.min(box.width/frame.width,box.height/frame.height),w=frame.width*scale,h=frame.height*scale;const px=(x-(box.width-w)/2)/w,py=(y-(box.height-h)/2)/h;return px>=0&&px<=1&&py>=0&&py<=1?{x:px,y:py}:null;}
  function release(x:number,y:number){const from=start.current;start.current=null;const to=point(x,y);if(!from||!to)return;if(mode==='drag'){void input({type:'drag',...from,to}).catch(()=>{});return;}if(Math.abs(from.x-to.x)<.03&&Math.abs(from.y-to.y)<.03)void input({type:mode,...to}).catch(()=>{});}
  async function sendText(){if(!text.trim())return;const value=text;try{await input({type:'text',text:value});if(mounted.current)setText(current=>current===value?'':current);}catch{}}
  const enabled=!!frame&&active&&!connecting;
  return <Modal visible animationType="slide" onRequestClose={onClose}><SafeAreaView style={s.safe}><KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
    <View style={s.header}><Pressable accessibilityRole="button" accessibilityLabel="断开并返回" onPress={onClose} style={s.back}><ArrowLeft color={c.text} size={22}/></Pressable><View style={{flex:1}}><Text style={s.title}>{name}</Text><Text style={s.caption}>{connecting?'正在连接桌面…':frame?'内置远程桌面 · 已连接':active?'桌面未连接':'已暂停共享'}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="重新连接桌面" onPress={()=>setRevision(v=>v+1)} disabled={connecting} style={s.back}><RefreshCw color={c.green} size={21}/></Pressable></View>
    {!!error&&<View style={s.error}><Text accessibilityRole="alert" style={s.errorText}>{error}</Text></View>}
    <View accessibilityLabel="远程电脑画面" style={s.screen} onLayout={e=>{surface.current=e.nativeEvent.layout;}} onStartShouldSetResponder={()=>control&&enabled} onResponderGrant={e=>{start.current=point(e.nativeEvent.locationX,e.nativeEvent.locationY);}} onResponderRelease={e=>release(e.nativeEvent.locationX,e.nativeEvent.locationY)} onResponderTerminate={()=>{start.current=null;}}>
      {frame?<View pointerEvents="none" style={{width:'100%',height:'100%'}}><Image style={{width:'100%',height:'100%'}} resizeMode="contain" source={{uri:`data:image/jpeg;base64,${frame.image}`}} accessibilityLabel="Windows 桌面"/></View>:<View style={{alignItems:'center',gap:16,padding:24}}>{connecting?<ActivityIndicator color={c.green} size="large"/>:<Monitor color={c.muted} size={44}/>}<Text style={[s.caption,{textAlign:'center'}]}>{connecting?'正在读取 Windows 画面':active?'电脑需保持登录并解锁。可点击右上角重连。':'返回前台后重新连接。'}</Text></View>}
    </View>
    <View style={s.tools}><View style={s.row}><MousePointer2 size={17} color={control?c.green:c.muted}/><Text style={[s.caption,{flex:1}]}>{control?'触摸画面操作电脑':'查看模式'}</Text><Button label={control?'切回仅查看':'开启触摸控制'} disabled={!enabled} onPress={()=>setControl(v=>!v)}/></View>
      {control&&<><View style={s.row}>{modes.map(item=><Pressable accessibilityRole="button" key={item.id} accessibilityLabel={item.label} onPress={()=>setMode(item.id)} style={[s.button,{flex:1},mode===item.id&&{backgroundColor:'#2B4230'}]}><Text style={[s.buttonText,mode===item.id&&{color:c.green}]}>{item.label}</Text></Pressable>)}</View><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:7}}>{[{label:'向上滚动',input:{type:'scroll',delta:360}},{label:'向下滚动',input:{type:'scroll',delta:-360}},...['enter','escape','tab','backspace','copy','paste','selectAll','altTab'].map((key,i)=>({label:['回车','Esc','Tab','退格','复制','粘贴','全选','切换窗口'][i]!,input:{type:'key',key}}))].map(item=><Button key={item.label} label={item.label} disabled={sending||!enabled} onPress={()=>void input(item.input).catch(()=>{})}/>)}</ScrollView><View style={s.composer}><TextInput accessibilityLabel="输入到远程电脑" style={s.input} placeholder="先点击电脑中的输入框，再输入文字…" placeholderTextColor={c.muted} value={text} onChangeText={setText} maxLength={1000} multiline/><Pressable accessibilityRole="button" accessibilityLabel="发送文字到电脑" onPress={()=>void sendText()} disabled={sending||!text.trim()||!enabled} style={[s.send,(sending||!text.trim()||!enabled)&&{opacity:.4}]}><Send size={20} color={c.bg}/></Pressable></View></>}
      <Text style={s.hint}>轻量画面刷新 · 主屏幕 · 不含声音 · 退出即断开</Text>
    </View>
  </KeyboardAvoidingView></SafeAreaView></Modal>;
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:c.bg},header:{height:70,paddingHorizontal:16,flexDirection:'row',alignItems:'center',gap:10},back:{width:44,height:44,alignItems:'center',justifyContent:'center'},title:{fontSize:16,color:c.text,fontWeight:'600'},caption:{fontSize:11,color:c.muted,lineHeight:19},screen:{flex:1,minHeight:100,backgroundColor:'#050808',justifyContent:'center',alignItems:'center'},error:{marginHorizontal:16,marginBottom:10,padding:12,borderRadius:12,backgroundColor:'#321F22'},errorText:{fontSize:12,lineHeight:20,color:c.red},tools:{padding:14,gap:10,borderTopWidth:1,borderTopColor:c.line},row:{flexDirection:'row',alignItems:'center',gap:7},button:{minHeight:44,paddingHorizontal:11,borderRadius:11,alignItems:'center',justifyContent:'center',backgroundColor:'#1B2530'},buttonText:{fontSize:11,color:c.text},composer:{flexDirection:'row',gap:10,alignItems:'center',padding:8,borderRadius:14,backgroundColor:'#17212B'},input:{flex:1,minHeight:44,maxHeight:90,color:c.text,fontSize:13,padding:8},send:{width:44,height:44,backgroundColor:c.green,borderRadius:12,alignItems:'center',justifyContent:'center'},hint:{fontSize:10,color:c.muted,textAlign:'center'}});
