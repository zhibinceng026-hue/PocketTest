import {Platform} from 'react-native';
import {requireOptionalNativeModule} from 'expo';
import {createGamepadMapping,type GamepadSnapshot} from './gamepad-mapping';
export type HardwareInput={type:'keyDown'|'keyUp';keyCode:number}|{type:'mouseMove';dx:number;dy:number}|{type:'mouseButton';button:'left'|'right'|'middle';down:boolean}|{type:'scroll';delta:number}|{type:'releaseAll'};
export type HardwareDevices={keyboard:boolean;mouseCount:number;controllerCount:number;gamepadMapping?:boolean};
type HardwareModule={getDevices?:()=>Promise<HardwareDevices>;setEnabled:(enabled:boolean)=>Promise<void>;addListener:(name:string,listener:(input:HardwareInput)=>void)=>{remove:()=>void}};
const native=Platform.OS==='ios'?requireOptionalNativeModule<HardwareModule>('AgentRemoteInput'):null;
export const hardwareInputAvailable=!!native;
export function captureHardwareInput(listener:(input:HardwareInput)=>void,gamepad=false){
 if(!native)return()=>{};
 const mapping=createGamepadMapping();
 const sub=native.addListener('onInput',raw=>{const event=raw as HardwareInput|({type:'gamepadState'}&GamepadSnapshot);if(event.type==='gamepadState'){if(gamepad)for(const mapped of mapping.update(event))listener(mapped);return;}if(event.type==='releaseAll')mapping.release();listener(event);});void native.setEnabled(true).catch(()=>listener({type:'releaseAll'}));
 return()=>{for(const event of mapping.release())listener(event);void native.setEnabled(false).catch(()=>{});sub.remove();listener({type:'releaseAll'});};
}

export async function readHardwareDevices():Promise<HardwareDevices|null>{return native?.getDevices?await native.getDevices():null;}
