// Browser preview and web builds use the browser's native WebRTC engine.
export const RTCRtpReceiver=(globalThis as any).RTCRtpReceiver;
export const RTCPeerConnection=(globalThis as any).RTCPeerConnection;
