import React,{forwardRef,useImperativeHandle,useRef} from 'react';
import type {PipEvent,RemoteVideoHandle} from './pip-lifecycle';
const {RTCView,startIOSPIP}=require('react-native-webrtc');
export const RemoteVideo=forwardRef<RemoteVideoHandle,{stream:any;audio?:boolean;nativePeerId?:number;onPip?:(event:PipEvent)=>void;onSize?:(width:number,height:number)=>void}>(function RemoteVideo({stream,nativePeerId,onPip,onSize},ref){
 const view=useRef<any>(null),ready=useRef(false);
 useImperativeHandle(ref,()=>({async startPip(){if(!view.current||!ready.current||!Number.isSafeInteger(nativePeerId))throw new Error('视频画面尚未就绪，请稍后重试。');startIOSPIP(view);}}),[nativePeerId]);
 return <RTCView key={nativePeerId??'connecting'} ref={view} streamURL={stream.toURL()} objectFit="contain" iosPIP={Number.isSafeInteger(nativePeerId)?{enabled:true,peerConnectionId:nativePeerId,startAutomatically:false,stopAutomatically:true}:undefined} onPipStateChange={(event:any)=>onPip?.(event.nativeEvent)} onDimensionsChange={(event:any)=>{ready.current=event.nativeEvent.width>0&&event.nativeEvent.height>0;onSize?.(event.nativeEvent.width,event.nativeEvent.height);}} style={{width:'100%',height:'100%'}}/>;
});
