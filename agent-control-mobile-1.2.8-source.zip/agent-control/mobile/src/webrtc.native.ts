export const {RTCPeerConnection,RTCRtpReceiver}=require('react-native-webrtc');
