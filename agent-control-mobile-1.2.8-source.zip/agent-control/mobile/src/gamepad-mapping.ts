export type GamepadSnapshot={axes:number[];buttons:Record<string,boolean>};
type Action={type:'keyDown'|'keyUp';keyCode:number}|{type:'mouseButton';button:'left'|'right';down:boolean}|{type:'mouseMove';dx:number;dy:number};
const keys:Record<string,number>={a:44,b:41,x:8,y:21,lb:20,rb:43,menu:40,up:82,down:81,left:80,right:79};
export function createGamepadMapping(){
 let held=new Set<string>();
 const event=(name:string,down:boolean):Action=>name==='lt'||name==='rt'?{type:'mouseButton',button:name==='rt'?'left':'right',down}:{type:down?'keyDown':'keyUp',keyCode:name.startsWith('axis:')?Number(name.slice(5)):keys[name]!};
 return {
  update(snapshot:GamepadSnapshot):Action[]{
   const axes=snapshot.axes.map(v=>Number.isFinite(v)?Math.max(-1,Math.min(1,v)):0),next=new Set<string>();
   for(const name of [...Object.keys(keys),'lt','rt'])if(snapshot.buttons[name])next.add(name);
   if((axes[0]||0)<-.3)next.add('axis:4');if((axes[0]||0)>.3)next.add('axis:7');
   if((axes[1]||0)>.3)next.add('axis:26');if((axes[1]||0)<-.3)next.add('axis:22');
   const events:Action[]=[];
   for(const name of held)if(!next.has(name))events.push(event(name,false));
   for(const name of next)if(!held.has(name))events.push(event(name,true));
   held=next;
   const move=(v:number)=>Math.abs(v||0)>.18?Math.round(Math.sign(v)*(Math.abs(v)-.18)/.82*16000)/1000:0;
   const dx=move(axes[2]||0),dy=-move(axes[3]||0);if(dx||dy)events.push({type:'mouseMove',dx,dy});
   return events;
  },
  release():Action[]{const events=[...held].map(name=>event(name,false));held.clear();return events;}
 };
}
