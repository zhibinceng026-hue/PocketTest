Pod::Spec.new do |s|
  s.name = 'RemoteInput'
  s.version = '0.1.0'
  s.summary = 'Paired remote desktop hardware input'
  s.description = 'Foreground keyboard and mouse events for Agent Control.'
  s.license = { :type => 'MIT' }
  s.author = 'Agent Control'
  s.homepage = 'https://github.com/zhibinceng026-hue/PocketTest'
  s.platforms = { :ios => '16.4' }
  s.source = { :git => '' }
  s.static_framework = true
  s.dependency 'ExpoModulesCore'
  s.frameworks = 'GameController', 'UIKit', 'UniformTypeIdentifiers'
  s.source_files = '**/*.{h,m,mm,swift}'
  s.swift_version = '5.9'
end

